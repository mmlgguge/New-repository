import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def _entity_summary(entity: Any) -> dict[str, Any]:
    return {
        "id": getattr(entity, "id", None),
        "username": getattr(entity, "username", None),
        "title": getattr(entity, "title", None),
    }


def _button_rows(event: Any) -> list[list[str]]:
    rows: list[list[str]] = []
    for row in getattr(event, "buttons", None) or []:
        rows.append([str(getattr(button, "text", "") or "") for button in row])
    return rows


def capture_message_sample(
    path: str,
    event: Any,
    chat: Any,
    sender: Any,
    recognized: bool,
) -> None:
    """保存消息和按钮结构，不保存手机号、验证码或 Session。"""
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    record = {
        "captured_at": datetime.now(timezone.utc).isoformat(),
        "message_id": getattr(event, "id", None),
        "chat": _entity_summary(chat),
        "sender": _entity_summary(sender),
        "text": event.raw_text or "",
        "buttons": _button_rows(event),
        "recognized_by_generic_parser": recognized,
    }
    with destination.open("a", encoding="utf-8") as file:
        file.write(json.dumps(record, ensure_ascii=False) + "\n")
