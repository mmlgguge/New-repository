import logging
import time
from typing import Any


class PerfTimer:
    def __init__(
        self,
        name: str,
        logger: logging.Logger,
        *,
        context: dict[str, Any] | None = None,
    ) -> None:
        self.name = name
        self.logger = logger
        self.context = context or {}
        self.started = time.perf_counter()
        self.previous = self.started

    def mark(self, stage: str, *, level: int = logging.DEBUG) -> None:
        now = time.perf_counter()
        self.logger.log(
            level,
            "perf name=%s stage=%s elapsed_ms=%.3f total_ms=%.3f context=%s",
            self.name,
            stage,
            (now - self.previous) * 1000,
            (now - self.started) * 1000,
            self.context,
        )
        self.previous = now

    def finish(self, reason: str = "", *, level: int = logging.DEBUG) -> None:
        now = time.perf_counter()
        self.logger.log(
            level,
            "perf name=%s stage=finish elapsed_ms=%.3f total_ms=%.3f reason=%s context=%s",
            self.name,
            (now - self.previous) * 1000,
            (now - self.started) * 1000,
            reason,
            self.context,
        )
        self.previous = now
