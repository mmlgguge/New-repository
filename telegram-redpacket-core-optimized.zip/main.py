import asyncio
import logging
import os
import sys
from pathlib import Path


def _restart_in_project_venv() -> None:
    venv_python = Path(__file__).resolve().parent / ".venv" / "Scripts" / "python.exe"
    if not venv_python.exists():
        return
    if Path(sys.executable).resolve() == venv_python.resolve():
        return
    os.execv(
        str(venv_python),
        [str(venv_python), str(Path(__file__).resolve()), *sys.argv[1:]],
    )


if __name__ == "__main__":
    _restart_in_project_venv()

from dotenv import load_dotenv
from telethon import TelegramClient, events
from telethon.network import ConnectionTcpFull

from redpacket_core.listener import handle_message
from redpacket_core.tasks import create_tracked_task

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)

API_ID = int(os.getenv("TG_API_ID", "0"))
API_HASH = os.getenv("TG_API_HASH", "your_api_hash_here")
SESSION_PATH = os.getenv("TG_SESSION_PATH", "data/account")

proxy_host = os.getenv("TG_PROXY_HOST", "127.0.0.1").strip()
proxy_port = int(os.getenv("TG_PROXY_PORT", "7890"))
PROXY = ("socks5", proxy_host, proxy_port) if proxy_host else None


async def main():
    client = TelegramClient(
        SESSION_PATH,
        API_ID,
        API_HASH,
        proxy=PROXY,
        connection=ConnectionTcpFull,
        timeout=60,
        auto_reconnect=True,
    )

    async def _handle_event(event):
        return await handle_message(event)

    @client.on(events.NewMessage)
    @client.on(events.MessageEdited)
    async def handler(event):
        if event.reply_markup:
            create_tracked_task(
                _handle_event(event),
                name="redpacket-handle-message",
                context={
                    "chat_id": getattr(event, "chat_id", None),
                    "message_id": getattr(event, "id", None),
                },
                on_done=lambda result: logger.info(
                    "redpacket_result reason=%s",
                    result["reason"],
                ),
            )

    try:
        await client.start()
        logger.info("listener account online session=%s", SESSION_PATH)
        await client.run_until_disconnected()
    except Exception as exc:
        logger.exception("telegram connection stopped unexpectedly: %s", exc)


if __name__ == "__main__":
    asyncio.run(main())
