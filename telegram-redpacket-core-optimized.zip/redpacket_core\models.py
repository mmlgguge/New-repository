from dataclasses import dataclass
from decimal import Decimal
from typing import Optional


@dataclass(frozen=True)
class RedPacket:
    currency: str
    amount: Decimal
    count: Optional[int] = None


@dataclass(frozen=True)
class RuleDecision:
    should_click: bool
    reason: str
    threshold: Optional[Decimal] = None
