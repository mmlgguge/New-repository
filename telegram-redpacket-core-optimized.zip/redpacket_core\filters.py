from typing import Any

from .config import AppConfig


def _candidate_ids(entity: Any) -> set[str]:
    values: set[str] = set()
    entity_id = getattr(entity, "id", None)
    username = getattr(entity, "username", None)
    title = getattr(entity, "title", None)
    if entity_id is not None:
        values.add(str(entity_id).lower())
    if username:
        values.add(str(username).lower().lstrip("@"))
    if title:
        values.add(str(title).lower())
    return values


def source_is_allowed(chat: Any, sender: Any, config: AppConfig) -> tuple[bool, str]:
    if config.allowed_chats and not (_candidate_ids(chat) & config.allowed_chats):
        return False, "群组不在允许列表"
    if config.allowed_senders and not (_candidate_ids(sender) & config.allowed_senders):
        return False, "发送者不在允许列表"
    return True, "来源符合配置"
