import asyncio
import logging
import os
import random
import re
from decimal import Decimal
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from telethon.errors.rpcerrorlist import ChannelPrivateError, DataInvalidError, FloodWaitError

from .adapter import GenericRedPacketAdapter
from .clicker import (
    button_count,
    button_url,
    find_button_index,
    has_button_keyword,
    has_locked_button,
    parse_custom_emoji_math,
)
from .config import AppConfig, config_path_from_env, load_config
from .dedup import MessageAttemptTracker
from .filters import source_is_allowed
from .perf import PerfTimer
from .rules import evaluate_threshold
from .sample_capture import capture_message_sample

logger = logging.getLogger(__name__)

NOTICE_BUTTON_KEYWORDS = ("访问红包消息", "前往红包消息")
MINIAPP_CLAIM_BUTTON_KEYWORDS = ("点击领取", "立即领取")
FAST_MEMBER_PACKET_BUTTON_KEYWORDS = ("会员红包",)
FAST_MEMBER_PACKET_CHAT_KEYWORDS = ("福利来", "fll", "fllqb")
QUESTION_TEXT_KEYWORDS = ("正确答案", "答案领取", "= ?")
CHAIN_PACKET_TEXT_KEYWORDS = ("拼手气接龙", "接龙红包")
CHAIN_PACKET_BUTTON_KEYWORDS = ("拼拼手气", "接龙")
EXCLUSIVE_PACKET_TEXT_KEYWORDS = ("专属红包", "专享红包")
DIRECTED_PACKET_TEXT_KEYWORDS = (
    "给您发送了一个红包",
    "给你发送了一个红包",
)
PROMOTIONAL_PACKET_TEXT_KEYWORDS = (
    "邀请奖励规则",
    "邀请小技巧",
    "邀请好友加入",
    "点击即可领取红包",
)
GAMBLING_AD_KEYWORDS = (
    "亏损最高",
    "反水模式",
    "新人首充",
    "每天猜数字",
    "流水补偿",
    "红包抢不停",
)
TEST_PACKET_CONTEXT_LOOKBACK = 5
TEST_PACKET_CONTEXT_MAX_AGE = timedelta(seconds=30)
TEST_PACKET_KEYWORDS = (
    "\u6d4b\u6302",
    "\u6d4b\u5366",
    "\u6d4b\u6302\u5305",
    "\u6d4b\u8bd5\u6302",
    "\u6d4b\u8bd5\u5916\u6302",
    "\u5916\u6302\u6d4b\u8bd5",
    "\u6d4b\u8bd5\u62a2\u5305",
    "\u6d4b\u8bd5\u673a\u5668\u4eba",
    "\u6d4b\u8bd5\u811a\u672c",
    "\u6d4b\u8bd5\u81ea\u52a8",
    "\u4e0b\u4e00\u4e2a\u6d4b",
    "\u4e0b\u4e00\u4e2a\u662f\u6d4b",
    "\u4e0b\u4e2a\u6d4b",
    "\u4e0b\u4e2a\u662f\u6d4b",
)
PREMIUM_LIMITED_PACKET_KEYWORDS = (
    "\u4ec5\u9650 Premium\u4f1a\u5458\u9886\u53d6",
    "\u53ea\u9650 Premium\u4f1a\u5458\u9886\u53d6",
    "\u9650 Premium\u4f1a\u5458\u9886\u53d6",
    "Premium\u4f1a\u5458\u9886\u53d6",
    "Premium \u4f1a\u5458\u9886\u53d6",
)
PUBLIC_CONDITION_PACKET_KEYWORDS = (
    "\u4ec5\u9650\u7fa4\u7ec4\u6210\u5458",
    "\u53ea\u9650\u7fa4\u7ec4\u6210\u5458",
    "\u9650\u7fa4\u7ec4\u6210\u5458",
    "\u4ec5\u9650\u7fa4\u6210\u5458",
    "\u53ea\u9650\u7fa4\u6210\u5458",
    "\u9650\u7fa4\u6210\u5458",
    "\u7fa4\u7ec4\u6210\u5458\u9886\u53d6",
    "\u7fa4\u6210\u5458\u9886\u53d6",
    "\u4eca\u65e5\u53d1\u8a00",
    "\u6240\u9700\u4eca\u65e5\u53d1\u8a00",
    "\u53d1\u8a00\u8981\u6c42",
    "\u53d1\u8a00\u6b21\u6570",
)
MAX_PACKET_AGE = timedelta(
    seconds=max(60, float(os.getenv("MAX_PACKET_AGE_SECONDS", "600")))
)
ACCOUNT_CLICK_MIN_INTERVAL_SECONDS = max(
    0.0,
    min(float(os.getenv("ACCOUNT_CLICK_MIN_INTERVAL_SECONDS", "1.2")), 10.0),
)
VISIBLE_PACKET_TEXT_KEYWORDS = ("\u7ea2\u5305", "red packet", "redpacket")
VISIBLE_CLAIM_BUTTON_KEYWORDS = (
    "\u9886\u53d6\u7ea2\u5305",
    "\u62a2\u7ea2\u5305",
    "\u4f1a\u5458\u7ea2\u5305",
    "\u70b9\u51fb\u9886\u53d6",
    "\u7acb\u5373\u9886\u53d6",
)
PACKET_TEXT_KEYWORDS = ("红包", "red packet", "redpacket")
EMPTY_PACKET_PATTERN = re.compile(r"剩余\s*[:：]?\s*0\s*/\s*\d+", re.IGNORECASE)
VISIBLE_EMPTY_PACKET_PATTERN = re.compile(
    r"(?:剩余|还剩)\s*[:：]?\s*0\s*/\s*\d+",
    re.IGNORECASE,
)
DIRECTED_MENTION_PACKET_PATTERN = re.compile(
    r"(?:仅限|只限|指定|专属|限)[^\n\r]{0,80}@[A-Za-z0-9_]{3,32}[^\n\r]{0,30}(?:领取|领)",
    re.IGNORECASE,
)
DIRECTED_NICKNAME_PACKET_PATTERN = re.compile(
    r"(?:仅限|只限|指定|专属|限)[^\n\r@]{0,60}(?:领取|领)",
    re.IGNORECASE,
)
SILENT_CHAT_IDS = {
    -1003411071473,
}
SILENT_MINIAPP_URL_KEYWORDS = (
    "t.me/mymy/redreceive",
    "telegram.me/mymy/redreceive",
)
SILENT_PACKET_KEYWORDS = (
    "akpoker",
)
SILENT_CHAT_NAME_KEYWORDS = (
    "卢本伟红包推送",
    "卢本伟红包监控",
    "卢本伟",
)


def _is_silent_chat(chat_id: Any) -> bool:
    if chat_id is None:
        return False
    try:
        cid = int(chat_id)
    except (TypeError, ValueError):
        return False
    return cid in SILENT_CHAT_IDS or -cid in SILENT_CHAT_IDS


def _is_silent_chat_name(chat_name: str | None) -> bool:
    normalized = str(chat_name or "").lower()
    return any(keyword.lower() in normalized for keyword in SILENT_CHAT_NAME_KEYWORDS)


def _is_silent_miniapp_url(url: str | None) -> bool:
    if not url:
        return False
    normalized = str(url).lower()
    return any(keyword in normalized for keyword in SILENT_MINIAPP_URL_KEYWORDS)


def _has_silent_packet_keyword(event: Any, text: str) -> bool:
    normalized = (text or "").lower()
    if any(keyword in normalized for keyword in SILENT_PACKET_KEYWORDS):
        return True
    for row in getattr(event, "buttons", None) or []:
        for button in row:
            value = (
                str(getattr(button, "text", "") or "")
                + " "
                + str(getattr(button, "url", "") or "")
            ).lower()
            if any(keyword in value for keyword in SILENT_PACKET_KEYWORDS):
                return True
    return False


def _is_empty_packet_text(text: str) -> bool:
    return bool(
        EMPTY_PACKET_PATTERN.search(text or "")
        or VISIBLE_EMPTY_PACKET_PATTERN.search(text or "")
    )


def _has_visible_button_keyword(event: Any, keywords: tuple[str, ...]) -> bool:
    for row in getattr(event, "buttons", None) or []:
        for button in row:
            label = str(getattr(button, "text", "") or "")
            if any(keyword in label for keyword in keywords):
                return True
    return False


def _looks_like_packet_candidate(
    event: Any,
    text: str,
    config: AppConfig,
    packet: Any,
) -> bool:
    value = (text or "").lower()
    if packet is not None:
        return True
    if any(keyword in value for keyword in PACKET_TEXT_KEYWORDS):
        return True
    if any(keyword in value for keyword in VISIBLE_PACKET_TEXT_KEYWORDS):
        return True
    if not getattr(event, "buttons", None):
        return False
    return (
        has_button_keyword(event, config.button_text_keywords)
        or has_locked_button(event, config.locked_button_keywords)
        or has_button_keyword(event, NOTICE_BUTTON_KEYWORDS)
        or has_button_keyword(event, MINIAPP_CLAIM_BUTTON_KEYWORDS)
        or has_button_keyword(event, FAST_MEMBER_PACKET_BUTTON_KEYWORDS)
        or _has_visible_button_keyword(event, VISIBLE_CLAIM_BUTTON_KEYWORDS)
    )


def _is_premium_limited_packet(text: str) -> bool:
    value = text or ""
    normalized = re.sub(r"\s+", " ", value)
    return any(keyword in value or keyword in normalized for keyword in PREMIUM_LIMITED_PACKET_KEYWORDS)


def _is_transient_telegram_error(exc: Exception) -> bool:
    message = str(exc)
    return (
        "Request was unsuccessful" in message
        or "request was unsuccessful" in message
        or "Server closed the connection" in message
        or "Connection to Telegram failed" in message
    )


async def _current_account_is_premium(client: Any) -> bool:
    me = await client.get_me()
    return bool(getattr(me, "premium", False))


def _is_directed_or_exclusive_packet_text(text: str) -> bool:
    value = text or ""
    if _is_premium_limited_packet(value):
        return False
    if any(keyword in value for keyword in PUBLIC_CONDITION_PACKET_KEYWORDS):
        return False
    if DIRECTED_MENTION_PACKET_PATTERN.search(value):
        return True
    if DIRECTED_NICKNAME_PACKET_PATTERN.search(value):
        return True
    return any(
        keyword in value
        for keyword in (
            "专属红包",
            "专享红包",
            "不属于您",
            "无法领取",
            "给您发送了一个红包",
            "给你发送了一个红包",
        )
    )


def _has_test_packet_keyword(text: str) -> bool:
    value = (text or "").lower()
    return any(keyword.lower() in value for keyword in TEST_PACKET_KEYWORDS)


def _is_fast_member_packet(event: Any, chat_name: str) -> bool:
    name = (chat_name or "").lower()
    if not any(keyword in name for keyword in FAST_MEMBER_PACKET_CHAT_KEYWORDS):
        return False
    return has_button_keyword(event, FAST_MEMBER_PACKET_BUTTON_KEYWORDS)


async def _has_recent_test_packet_context(event: Any) -> bool:
    chat_id = getattr(event, "chat_id", None)
    message_id = getattr(event, "id", None)
    if not chat_id or not message_id:
        return False
    try:
        messages = await event.client.get_messages(
            chat_id,
            limit=TEST_PACKET_CONTEXT_LOOKBACK,
            max_id=message_id,
        )
    except Exception:
        logger.debug(
            "读取测挂包前置消息失败：chat=%s message=%s",
            chat_id,
            message_id,
            exc_info=True,
        )
        return False

    current_date = getattr(event, "date", None) or datetime.now(timezone.utc)
    if current_date.tzinfo is None:
        current_date = current_date.replace(tzinfo=timezone.utc)

    for message in messages or []:
        message_date = getattr(message, "date", None)
        if message_date:
            if message_date.tzinfo is None:
                message_date = message_date.replace(tzinfo=timezone.utc)
            if current_date - message_date > TEST_PACKET_CONTEXT_MAX_AGE:
                continue
        if _has_test_packet_keyword(getattr(message, "raw_text", "") or getattr(message, "message", "")):
            return True
    return False


_attempts = MessageAttemptTracker()
_config_cache: tuple[Path, int, AppConfig] | None = None
_adapter_cache: tuple[Path, int, GenericRedPacketAdapter] | None = None
_account_click_last_at: dict[Any, float] = {}
_account_click_locks: dict[Any, asyncio.Lock] = {}
RETRYABLE_CLICK_ERRORS = (asyncio.TimeoutError, ConnectionError, OSError)
CALLBACK_FAILURE_KEYWORDS = (
    "❌",
    "失败",
    "不足",
    "已抢完",
    "抢完",
    "已领取",
    "重复领取",
    "不符合",
    "无资格",
    "过期",
    "不属于您",
    "无法领取",
    "专属红包",
    "抢光",
    "抢完",
    "已领取",
    "频繁",
    "太快",
    "稍后再试",
    "Too many",
    "wait",
    "Flood",
)
SILENT_CALLBACK_FAILURE_KEYWORDS = (
    "专属红包不属于您",
    "专属红包不属于你",
    "不属于您",
    "不属于你",
    "无法领取",
    "不是你的专属红包",
)


async def _wait_account_click_slot(attempt_scope: Any) -> None:
    if attempt_scope is None or ACCOUNT_CLICK_MIN_INTERVAL_SECONDS <= 0:
        return
    lock = _account_click_locks.get(attempt_scope)
    if lock is None:
        lock = asyncio.Lock()
        _account_click_locks[attempt_scope] = lock
    async with lock:
        loop = asyncio.get_running_loop()
        now = loop.time()
        last_at = _account_click_last_at.get(attempt_scope, 0.0)
        wait_seconds = last_at + ACCOUNT_CLICK_MIN_INTERVAL_SECONDS - now
        if wait_seconds > 0:
            await asyncio.sleep(wait_seconds)
        _account_click_last_at[attempt_scope] = loop.time()


def _get_config() -> AppConfig:
    global _config_cache
    path = config_path_from_env().resolve()
    modified_ns = path.stat().st_mtime_ns
    if (
        _config_cache is None
        or _config_cache[0] != path
        or _config_cache[1] != modified_ns
    ):
        _config_cache = (path, modified_ns, load_config(path))
        logger.info("已加载配置：%s", path)
    return _config_cache[2]


def _get_adapter(config: AppConfig) -> GenericRedPacketAdapter:
    global _adapter_cache
    path = config_path_from_env().resolve()
    modified_ns = path.stat().st_mtime_ns
    if (
        _adapter_cache is None
        or _adapter_cache[0] != path
        or _adapter_cache[1] != modified_ns
    ):
        _adapter_cache = (
            path,
            modified_ns,
            GenericRedPacketAdapter(config.parser),
        )
    return _adapter_cache[2]


def _message_url(event: Any) -> str:
    message = getattr(event, "message", None)
    direct_link = getattr(message, "message_link", None)
    if direct_link:
        return str(direct_link)
    chat_id = getattr(event, "chat_id", None)
    message_id = getattr(event, "id", None)
    if chat_id and message_id and str(chat_id).startswith("-100"):
        return f"https://t.me/c/{str(chat_id)[4:]}/{message_id}"
    return "未知"


def _result(
    success: bool,
    reason: str,
    event: Any,
    *,
    amount: str = "0.00",
    currency: str = "",
    clicked: bool = False,
    notify: bool = False,
    chat_name: str = "",
    url: str | None = None,
    manual_required: bool = False,
    bot_username: str = "",
) -> dict[str, Any]:
    clean_bot_username = str(bot_username or "").strip().lstrip("@")
    message_url = _message_url(event)
    return {
        "success": success,
        "clicked": clicked,
        "notify": notify,
        "amount": amount,
        "currency": currency,
        "reason": reason,
        # url 可能是按钮/Mini App 领取链接；message_url 永远指向原群消息。
        "url": url or message_url,
        "message_url": message_url,
        "chat_id": getattr(event, "chat_id", None),
        "chat_name": chat_name,
        "message_id": getattr(event, "id", None),
        "manual_required": manual_required,
        "bot_username": clean_bot_username,
        "bot_url": f"https://t.me/{clean_bot_username}" if clean_bot_username else "",
    }


async def _source_bot_usernames(event: Any, sender: Any) -> set[str]:
    usernames = set()
    sender_username = str(getattr(sender, "username", "") or "").lower()
    if sender_username:
        usernames.add(sender_username)
    via_bot_id = getattr(getattr(event, "message", None), "via_bot_id", None)
    if via_bot_id:
        try:
            via_bot = await event.client.get_entity(via_bot_id)
            via_username = str(
                getattr(via_bot, "username", "") or ""
            ).lower()
            if via_username:
                usernames.add(via_username)
        except Exception:
            logger.debug("读取 via bot 信息失败：%s", via_bot_id, exc_info=True)
    for row in getattr(event, "buttons", None) or []:
        for button in row:
            url = str(getattr(button, "url", "") or "")
            match = re.search(r"https?://t\.me/([A-Za-z0-9_]+)", url)
            if match:
                usernames.add(match.group(1).lower())
    return usernames


async def handle_message(
    event: Any,
    *,
    attempt_scope: Any = None,
    thresholds_override: dict[str, Decimal] | None = None,
    skip_count_gt_amount: bool = False,
    click_delay: float = 0.0,
    click_delay_max: float | None = None,
    blocked_bots: set[str] | None = None,
) -> dict[str, Any]:
    """过滤、识别并处理一条可能的红包消息。"""
    try:
        timer = PerfTimer(
            "redpacket.handle_message",
            logger,
            context={
                "chat_id": getattr(event, "chat_id", None),
                "message_id": getattr(event, "id", None),
                "attempt_scope": attempt_scope,
            },
        )
        config = _get_config()
        chat_name = ""
        text = event.raw_text or ""
        adapter = _get_adapter(config)
        packet = adapter.parse(text)
        has_buttons = bool(getattr(event, "buttons", None))
        timer.mark("parsed")

        if _is_silent_chat(getattr(event, "chat_id", None)):
            logger.info(
                "静默群组已过滤：chat=%s message=%s",
                getattr(event, "chat_id", None),
                getattr(event, "id", None),
            )
            return _result(False, "静默群组已过滤", event, notify=False, chat_name=chat_name)
        if getattr(event, "is_private", False):
            logger.info(
                "私聊消息已静默过滤：chat=%s message=%s",
                getattr(event, "chat_id", None),
                getattr(event, "id", None),
            )
            return _result(False, "私聊消息已静默过滤", event, notify=False, chat_name=chat_name)
        if not _looks_like_packet_candidate(event, text, config, packet):
            return _result(
                False,
                "非红包消息已静默过滤",
                event,
                notify=False,
                chat_name=chat_name,
            )
        timer.mark("candidate")
        chat = getattr(event, "chat", None)
        sender = getattr(event, "sender", None)
        try:
            chat = chat or await event.get_chat()
        except (ChannelPrivateError, FloodWaitError) as exc:
            logger.info(
                "读取群组信息失败，继续尝试处理红包：chat=%s message=%s error=%s",
                getattr(event, "chat_id", None),
                getattr(event, "id", None),
                exc,
            )
            chat = None
        except Exception as exc:
            if _is_transient_telegram_error(exc):
                logger.info(
                    "读取群组信息临时失败，继续尝试处理红包：chat=%s message=%s error=%s",
                    getattr(event, "chat_id", None),
                    getattr(event, "id", None),
                    exc,
                )
                chat = None
            else:
                raise
        chat_name = (
            getattr(chat, "title", None)
            or getattr(chat, "username", None)
            or str(getattr(chat, "id", "未知群组"))
        )
        if _is_silent_chat(getattr(event, "chat_id", None)):
            logger.info(
                "静默群组已过滤：chat=%s message=%s",
                getattr(event, "chat_id", None),
                getattr(event, "id", None),
            )
            return _result(False, "静默群组已过滤", event, notify=False, chat_name=chat_name)
        if _is_silent_chat_name(chat_name):
            logger.info(
                "静默群名已过滤：chat=%s name=%s message=%s",
                getattr(event, "chat_id", None),
                chat_name,
                getattr(event, "id", None),
            )
            return _result(False, "静默群名已过滤", event, notify=False, chat_name=chat_name)
        if getattr(event, "is_private", False):
            logger.info(
                "私聊消息已静默过滤：chat=%s message=%s",
                getattr(event, "chat_id", None),
                getattr(event, "id", None),
            )
            return _result(False, "私聊消息已静默过滤", event, notify=False, chat_name=chat_name)
        if config.allowed_senders and sender is None:
            try:
                sender = await event.get_sender()
            except Exception as exc:
                logger.info(
                    "读取发送者信息失败，按来源过滤静默跳过：chat=%s message=%s error=%s",
                    getattr(event, "chat_id", None),
                    getattr(event, "id", None),
                    exc,
                )
                return _result(False, "读取发送者信息失败，静默跳过", event, notify=False, chat_name=chat_name)

        allowed, source_reason = source_is_allowed(chat, sender, config)
        if not allowed:
            return _result(False, source_reason, event, chat_name=chat_name)
        source_bots = set()
        if blocked_bots:
            if sender is None:
                try:
                    sender = await event.get_sender()
                except Exception as exc:
                    logger.info(
                        "读取发送者信息失败，跳过屏蔽机器人判断：chat=%s message=%s error=%s",
                        getattr(event, "chat_id", None),
                        getattr(event, "id", None),
                        exc,
                    )
                    sender = None
            try:
                source_bots = await _source_bot_usernames(event, sender)
            except Exception as exc:
                logger.info(
                    "读取来源机器人失败，跳过屏蔽机器人判断：chat=%s message=%s error=%s",
                    getattr(event, "chat_id", None),
                    getattr(event, "id", None),
                    exc,
                )
        source_bot_username = sorted(source_bots)[0] if source_bots else ""
        matched_blocked_bots = source_bots.intersection(blocked_bots or set())
        if matched_blocked_bots:
            blocked_username = sorted(matched_blocked_bots)[0]
            return _result(
                False,
                f"已按账号设置屏蔽 @{blocked_username}",
                event,
                chat_name=chat_name,
            )

        text = event.raw_text or ""
        has_buttons = bool(getattr(event, "buttons", None))
        is_fast_member_packet = _is_fast_member_packet(event, chat_name)

        if config.capture_samples and (
            has_buttons or not config.capture_only_with_buttons
        ):
            try:
                capture_message_sample(
                    config.sample_path,
                    event,
                    chat,
                    sender,
                    recognized=packet is not None,
                )
            except Exception:
                logger.debug("采集消息样本失败，继续处理", exc_info=True)

        if _has_test_packet_keyword(text):
            logger.info(
                "测挂/测试红包已静默过滤：chat=%s message=%s",
                getattr(event, "chat_id", None),
                getattr(event, "id", None),
            )
            return _result(
                False,
                "测挂/测试红包已静默过滤",
                event,
                chat_name=chat_name,
            )

        if any(keyword in text for keyword in CHAIN_PACKET_TEXT_KEYWORDS) or (
            has_buttons
            and has_button_keyword(event, CHAIN_PACKET_BUTTON_KEYWORDS)
        ):
            return _result(
                False,
                "接龙红包已静默过滤",
                event,
                chat_name=chat_name,
            )

        if _is_premium_limited_packet(text):
            if not await _current_account_is_premium(event.client):
                logger.info(
                    "Premium 限定红包非 Premium 账号静默跳过：chat=%s message=%s",
                    getattr(event, "chat_id", None),
                    getattr(event, "id", None),
                )
                return _result(
                    False,
                    "非 Premium 账号跳过",
                    event,
                    notify=False,
                    chat_name=chat_name,
                )

        if _is_directed_or_exclusive_packet_text(text):
            logger.info(
                "专属/定向红包已静默过滤：chat=%s message=%s",
                getattr(event, "chat_id", None),
                getattr(event, "id", None),
            )
            return _result(
                False,
                "专属/定向红包已静默过滤",
                event,
                chat_name=chat_name,
            )

        if any(keyword in text for keyword in EXCLUSIVE_PACKET_TEXT_KEYWORDS):
            return _result(
                False,
                "专属红包已静默过滤",
                event,
                chat_name=chat_name,
            )

        if any(keyword in text for keyword in DIRECTED_PACKET_TEXT_KEYWORDS):
            return _result(
                False,
                "定向红包已静默过滤",
                event,
                chat_name=chat_name,
            )

        if _has_silent_packet_keyword(event, text):
            logger.info(
                "静默关键词红包已过滤：chat=%s message=%s",
                getattr(event, "chat_id", None),
                getattr(event, "id", None),
            )
            return _result(
                False,
                "静默关键词红包已过滤",
                event,
                notify=False,
                chat_name=chat_name,
            )

        if any(keyword in text for keyword in PROMOTIONAL_PACKET_TEXT_KEYWORDS):
            return _result(
                False,
                "红包推广消息已静默过滤",
                event,
                chat_name=chat_name,
            )

        if sum(keyword in text for keyword in GAMBLING_AD_KEYWORDS) >= 2:
            return _result(
                False,
                "博彩推广消息已静默过滤",
                event,
                chat_name=chat_name,
            )

        if _is_empty_packet_text(text) and not is_fast_member_packet:
            logger.info(
                "红包已领完，静默过滤：chat=%s message=%s",
                getattr(event, "chat_id", None),
                getattr(event, "id", None),
            )
            return _result(
                False,
                "红包已领完，静默过滤",
                event,
                chat_name=chat_name,
            )

        message_date = getattr(event, "date", None) or getattr(
            getattr(event, "message", None),
            "date",
            None,
        )
        if message_date:
            if message_date.tzinfo is None:
                message_date = message_date.replace(tzinfo=timezone.utc)
            if datetime.now(timezone.utc) - message_date > MAX_PACKET_AGE:
                return _result(
                    False,
                    "旧红包消息已静默过滤",
                    event,
                    chat_name=chat_name,
                )

        normalized_text = text.lower()
        has_packet_text = any(
            keyword in normalized_text
            for keyword in PACKET_TEXT_KEYWORDS
        )
        has_packet_button = has_buttons and (
            has_button_keyword(event, config.button_text_keywords)
            or has_locked_button(event, config.locked_button_keywords)
            or has_button_keyword(event, NOTICE_BUTTON_KEYWORDS)
            or has_button_keyword(event, MINIAPP_CLAIM_BUTTON_KEYWORDS)
            or has_button_keyword(event, FAST_MEMBER_PACKET_BUTTON_KEYWORDS)
        )
        if not has_packet_text and not has_packet_button:
            return _result(
                False,
                "非红包消息已静默过滤",
                event,
                chat_name=chat_name,
            )

        if await _has_recent_test_packet_context(event):
            logger.info(
                "前置消息提示测挂/测试红包，已静默过滤：chat=%s message=%s",
                getattr(event, "chat_id", None),
                getattr(event, "id", None),
            )
            return _result(
                False,
                "前置消息提示为测挂/测试红包，已静默过滤",
                event,
                chat_name=chat_name,
            )

        if not config.enabled:
            return _result(False, "功能未启用", event, chat_name=chat_name)
        if not has_buttons:
            return _result(False, "消息没有按钮", event, chat_name=chat_name)
        if has_button_keyword(event, NOTICE_BUTTON_KEYWORDS):
            return _result(
                False, "这是跨群红包通知，不自动跳转", event, chat_name=chat_name
            )
        if has_locked_button(event, config.locked_button_keywords):
            return _result(False, "红包尚未解锁", event, chat_name=chat_name)
        if packet is None:
            return _result(
                False, "未识别到红包币种或金额", event, chat_name=chat_name
            )

        button_index = find_button_index(event, config.button_text_keywords)
        if button_index is None:
            button_index = find_button_index(
                event,
                MINIAPP_CLAIM_BUTTON_KEYWORDS,
            )
        if button_index is None and is_fast_member_packet:
            button_index = find_button_index(
                event,
                FAST_MEMBER_PACKET_BUTTON_KEYWORDS,
            )
            if button_index is not None:
                logger.info(
                    "福利来会员红包快速通道：chat=%s message=%s button=%s",
                    getattr(event, "chat_id", None),
                    getattr(event, "id", None),
                    button_index,
                )
        if button_index is None and any(
            keyword in text for keyword in QUESTION_TEXT_KEYWORDS
        ):
            button_index = await parse_custom_emoji_math(event)
        if button_index is None:
            return _result(
                False,
                "没有找到可安全点击的领取按钮，静默过滤",
                event,
                chat_name=chat_name,
            )
        if not 0 <= button_index < button_count(event):
            return _result(
                False,
                "识别出的按钮索引无效，静默过滤",
                event,
                chat_name=chat_name,
            )

        miniapp_url = button_url(event, button_index)
        if _is_silent_miniapp_url(miniapp_url):
            logger.info(
                "MY Mini App 红包已静默过滤：chat=%s message=%s url=%s",
                getattr(event, "chat_id", None),
                getattr(event, "id", None),
                miniapp_url,
            )
            return _result(
                False,
                "MY Mini App 红包已静默过滤",
                event,
                amount=str(packet.amount),
                currency=packet.currency,
                notify=False,
                chat_name=chat_name,
                url=miniapp_url,
            )

        if (
            skip_count_gt_amount
            and packet.count is not None
            and Decimal(packet.count) > packet.amount
        ):
            return _result(
                False,
                f"红包包数 {packet.count} 大于总金额 {packet.amount}，按账号规则跳过",
                event,
                amount=str(packet.amount),
                currency=packet.currency,
                notify=False,
                chat_name=chat_name,
            )

        thresholds = (
            thresholds_override
            if thresholds_override is not None
            else config.currency_thresholds
        )
        decision = evaluate_threshold(packet, thresholds)
        if not decision.should_click:
            return _result(
                False,
                decision.reason,
                event,
                amount=str(packet.amount),
                currency=packet.currency,
                notify=False,
                chat_name=chat_name,
            )

        key = (
            attempt_scope,
            getattr(event, "chat_id", None),
            getattr(event, "id", None),
        )
        if _attempts.has_attempted(key):
            return _result(
                False,
                "该消息已经尝试过",
                event,
                amount=str(packet.amount),
                currency=packet.currency,
                chat_name=chat_name,
            )

        if config.dry_run:
            return _result(
                True,
                f"演练模式：将点击第 {button_index + 1} 个按钮",
                event,
                amount=str(packet.amount),
                currency=packet.currency,
                notify=True,
                chat_name=chat_name,
            )

        _attempts.mark_attempted(key)
        try:
            delay_min = max(0.0, min(float(click_delay or 0), 10.0))
            delay_max = max(0.0, min(float(click_delay_max if click_delay_max is not None else delay_min), 10.0))
            if delay_max < delay_min:
                delay_min, delay_max = delay_max, delay_min
            delay_seconds = (
                random.uniform(delay_min, delay_max)
                if delay_max > delay_min
                else delay_min
            )
            if delay_seconds:
                await asyncio.sleep(delay_seconds)
            await _wait_account_click_slot(attempt_scope)
            timer.mark("before_click", level=logging.INFO)
            click_response = await event.click(button_index)
            timer.mark("after_click", level=logging.INFO)
        except DataInvalidError:
            _attempts.remove_attempt(key)
            return _result(
                False,
                "按钮数据已失效，红包可能已被抢完或消息按钮已更新",
                event,
                amount=str(packet.amount),
                currency=packet.currency,
                clicked=False,
                notify=True,
                chat_name=chat_name,
            )
        except RETRYABLE_CLICK_ERRORS as first_error:
            retry_delay = random.uniform(0.5, 2.0)
            logger.warning(
                "首次点击发生网络异常，%.2f 秒后重试一次：%s",
                retry_delay,
                first_error,
            )
            await asyncio.sleep(retry_delay)
            try:
                timer.mark("before_retry_click", level=logging.INFO)
                click_response = await event.click(button_index)
                timer.mark("after_retry_click", level=logging.INFO)
            except DataInvalidError:
                _attempts.remove_attempt(key)
                return _result(
                    False,
                    "按钮数据已失效，红包可能已被抢完或消息按钮已更新",
                    event,
                    amount=str(packet.amount),
                    currency=packet.currency,
                    clicked=False,
                    notify=True,
                    chat_name=chat_name,
                )
            except Exception:
                _attempts.remove_attempt(key)
                raise
        except Exception:
            _attempts.remove_attempt(key)
            raise
        miniapp_url = miniapp_url or button_url(event, button_index)
        if miniapp_url and isinstance(click_response, str):
            logger.info(
                "已识别 Mini App 领取链接：chat=%s message=%s button=%s",
                getattr(event, "chat_id", None),
                getattr(event, "id", None),
                button_index,
            )
            return _result(
                False,
                "已触发领取链接；该页面需要在对应 Telegram 账号内完成，若出现验证码请手动验证",
                event,
                amount=str(packet.amount),
                currency=packet.currency,
                clicked=True,
                notify=True,
                chat_name=chat_name,
                url=miniapp_url,
                manual_required=True,
            )
        callback_message = str(
            getattr(click_response, "message", None) or ""
        ).strip()
        callback_failed = bool(
            callback_message
            and any(
                keyword in callback_message
                for keyword in CALLBACK_FAILURE_KEYWORDS
            )
        )
        silent_callback_failed = bool(
            callback_message
            and any(
                keyword in callback_message
                for keyword in SILENT_CALLBACK_FAILURE_KEYWORDS
            )
        )
        click_reason = callback_message or "点击请求已成功提交"

        logger.info(
            "已提交领取请求：chat=%s message=%s amount=%s %s button=%s",
            getattr(event, "chat_id", None),
            getattr(event, "id", None),
            packet.amount,
            packet.currency,
            button_index,
        )
        return _result(
            not callback_failed,
            click_reason,
            event,
            amount=str(packet.amount),
            currency=packet.currency,
            clicked=True,
            notify=not silent_callback_failed,
            chat_name=chat_name,
            bot_username=source_bot_username,
        )
    except ChannelPrivateError as exc:
        logger.info(
            "无权限访问私有/不可见频道，已静默过滤：chat=%s message=%s error=%s",
            getattr(event, "chat_id", None),
            getattr(event, "id", None),
            exc,
        )
        return _result(
            False,
            "无权限访问私有/不可见频道，已静默过滤",
            event,
            notify=False,
            chat_name=locals().get("chat_name", ""),
        )
    except FloodWaitError as exc:
        seconds = int(getattr(exc, "seconds", 0) or 0)
        logger.info(
            "Telegram FloodWait 静默冷却：chat=%s message=%s seconds=%s request=%s",
            getattr(event, "chat_id", None),
            getattr(event, "id", None),
            seconds,
            getattr(exc, "request", ""),
        )
        return _result(
            False,
            f"Telegram 限流冷却 {seconds} 秒，静默跳过",
            event,
            notify=False,
            chat_name=locals().get("chat_name", ""),
        )
    except Exception as exc:
        if _is_transient_telegram_error(exc):
            logger.info(
                "Telegram 临时请求异常静默跳过：chat=%s message=%s error=%s",
                getattr(event, "chat_id", None),
                getattr(event, "id", None),
                exc,
            )
            return _result(
                False,
                f"Telegram 临时请求异常，静默跳过：{exc}",
                event,
                notify=False,
                chat_name=locals().get("chat_name", ""),
            )
        logger.exception("处理红包消息失败")
        return _result(
            False,
            f"处理异常：{exc}",
            event,
            notify=True,
            chat_name=locals().get("chat_name", ""),
        )
