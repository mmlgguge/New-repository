# Telegram 红包监听核心（第一阶段）

这是单账号验证版本，完成以下链路：

```text
监听新消息 → 校验群组/发送者 → 识别币种与总金额
→ 应用按币种阈值 → 找到领取按钮 → 演练或点击 → 中文日志
```

默认是安全的演练模式：`dry_run=true`，只识别，不会实际点击。

默认还会开启样本采集：

```json
"capture_samples": true,
"capture_only_with_buttons": true,
"sample_path": "data/message_samples.jsonl"
```

它默认只记录通过群组/发送者过滤且带按钮的消息，帮助制作专用适配器。不会记录登录验证码、两步验证密码或 Session。由于群消息仍可能含隐私，分享该文件前请先检查并脱敏。

## 1. 准备环境

需要 Python 3.10 或更高版本。

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
Copy-Item config.example.json config.json
```

编辑 `.env`：

```dotenv
TG_API_ID=你的API_ID
TG_API_HASH=你的API_HASH
TG_PHONE=+86138xxxxxxxx
TG_SESSION_PATH=data/account
APP_CONFIG_PATH=config.json
```

首次运行会要求输入 Telegram 登录验证码；如果开启了两步验证，还会要求输入密码。成功后生成 `data/account.session`。不要发送或提交该文件。

## 2. 配置规则

先保持：

```json
"enabled": false,
"dry_run": true
```

`currency_thresholds` 是按币种设置的最低总金额：

```json
{
  "USDT": "1",
  "JIBA": "10000"
}
```

- 识别到 `0.5 USDT`：跳过。
- 识别到 `1 USDT`：允许。
- 未配置的币种：不限制，允许。
- 要取消某币种限制，直接从 JSON 中删除；后续机器人界面会支持输入 `USDT 0` 删除。

`allowed_chats` 和 `allowed_senders` 支持填写数字 ID、用户名（可带 `@`）或群名。空数组代表不限制。测试时强烈建议至少限制红包机器人的用户名：

```json
"allowed_senders": ["target_redpacket_bot"]
```

确认配置无误后，把 `enabled` 改为 `true`。

## 3. 运行

```powershell
python main.py
```

先观察日志，确认群组、币种、金额和按钮识别正确。验证充分后，才把：

```json
"dry_run": false
```

改为真实点击模式。

如果通用规则没有识别出红包，请退出程序，然后检查：

```text
data/message_samples.jsonl
```

把相关记录脱敏后提供给开发者即可，不需要提供 `.env` 或 `.session` 文件。

## 4. 运行测试

测试不连接 Telegram：

```powershell
python -m unittest discover -s tests -v
```

## 5. 当前边界

- 当前金额表示红包消息中公开显示的“总金额”，不是随机红包最终可领取金额。
- 遇到“解锁红包”按钮时程序不会点击，而是等待发包人解锁。程序同时监听消息编辑；按钮更新为“领取红包”后会重新识别。
- 同一账号运行期间，同一群组的同一条红包消息只会尝试一次，避免红包剩余数量更新等消息编辑触发重复点击。
- “访问红包消息”属于其他群组红包通知，当前版本不会自动跨群跳转。
- 需要选择正确答案的答题红包，在没有可靠答案规则时会跳过，绝不随机点击。
- 通用正则只是骨架。目标红包机器人的真实文本、按钮结构和成功/失败返回方式确定后，应增加专用适配器。
- “点击请求已提交”不等于领取成功。准确的成功金额和失败原因，需要根据目标机器人的回调提示或后续消息做适配。
- 同一份 Session 不要同时启动两个程序实例。

## 下一步需要的测试材料

请提供脱敏后的三类内容：

1. 红包发布消息的完整文本和按钮文字。
2. 领取成功后的回调提示或机器人回复。
3. 常见失败状态，例如已抢完、资格不足、重复领取。

有这些样本后，就可以把通用识别升级为目标红包机器人的专用识别。
