"""Telegram 红包监听核心。"""
