import os
import sys
from pathlib import Path


def _restart_in_project_venv() -> None:
    """使用系统 Python 启动时，自动切换到项目虚拟环境。"""
    venv_python = Path(__file__).resolve().parent / ".venv" / "Scripts" / "python.exe"
    if not venv_python.exists():
        return
    if Path(sys.executable).resolve() == venv_python.resolve():
        return
    os.execv(
        str(venv_python),
        [str(venv_python), str(Path(__file__).resolve()), *sys.argv[1:]],
    )


if __name__ == "__main__":
    _restart_in_project_venv()
    from redpacket_core.master_bot import run

    run()
