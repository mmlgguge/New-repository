import asyncio
import base64
import functools
import json
import logging
import os
import re
import sqlite3
import unicodedata
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

import openai
from telethon.tl.functions.messages import GetCustomEmojiDocumentsRequest
from telethon.tl.types import MessageEntityCustomEmoji

logger = logging.getLogger(__name__)

EMOJI_LABEL_PATTERN = re.compile(r"^(?:[A-Z0-9]{1,4}|[+\-*/×÷=？?])$")
VISION_BASE_URL = "https://dashscope.aliyuncs.com/compatible-mode/v1"
VISION_MODEL = os.getenv("DASHSCOPE_VISION_MODEL", "qwen-vl-max")
_emoji_db: sqlite3.Connection | None = None
_emoji_learning_lock = asyncio.Lock()
_button_text_cache: dict[int, tuple[int, tuple[tuple[int, Any, str, str | None], ...]]] = {}


def normalize_button_text(text: str) -> str:
    """移除 emoji、空白和零宽字符，保留中英文、数字。"""
    normalized = unicodedata.normalize("NFKC", str(text or ""))
    return "".join(
        char
        for char in normalized
        if unicodedata.category(char)[0] in {"L", "N"}
    ).lower()


def iter_buttons(event: Any):
    for row_index, row in enumerate(getattr(event, "buttons", None) or []):
        for column_index, button in enumerate(row):
            yield row_index, column_index, button


@functools.lru_cache(maxsize=256)
def _normalized_keywords(keywords: tuple[str, ...]) -> tuple[str, ...]:
    return tuple(
        value for keyword in keywords if (value := normalize_button_text(keyword))
    )


def _button_texts(event: Any) -> tuple[tuple[int, Any, str, str | None], ...]:
    buttons = getattr(event, "buttons", None) or []
    event_key = id(event)
    buttons_key = id(buttons)
    cached = _button_text_cache.get(event_key)
    if cached and cached[0] == buttons_key:
        return cached[1]

    values = tuple(
        (
            flat_index,
            button,
            normalize_button_text(getattr(button, "text", "")),
            str(url) if (url := getattr(button, "url", None)) else None,
        )
        for flat_index, (_, _, button) in enumerate(iter_buttons(event))
    )
    _button_text_cache[event_key] = (buttons_key, values)
    if len(_button_text_cache) > 2048:
        _button_text_cache.clear()
    return values


def clear_button_text_cache() -> None:
    _button_text_cache.clear()
    _normalized_keywords.cache_clear()


def has_button_keyword(event: Any, keywords: tuple[str, ...]) -> bool:
    normalized_keywords = _normalized_keywords(tuple(keywords))
    return any(
        keyword in text
        for _, _, text, _ in _button_texts(event)
        for keyword in normalized_keywords
    )


def has_locked_button(event: Any, keywords: tuple[str, ...]) -> bool:
    return has_button_keyword(event, keywords)


def find_button_index(event: Any, keywords: tuple[str, ...]) -> Optional[int]:
    """返回 Telethon event.click(index) 使用的扁平按钮索引。"""
    normalized_keywords = _normalized_keywords(tuple(keywords))
    for flat_index, _, text, _ in _button_texts(event):
        if any(keyword in text for keyword in normalized_keywords):
            return flat_index
    return None


def button_count(event: Any) -> int:
    return len(_button_texts(event))


def button_url(event: Any, index: int) -> str | None:
    for flat_index, _, _, url in _button_texts(event):
        if flat_index != index:
            continue
        return url
    return None


def _cache_connection() -> sqlite3.Connection:
    global _emoji_db
    if _emoji_db is not None:
        return _emoji_db
    path = Path(os.getenv("EMOJI_CACHE_PATH", "data/emoji_cache.db"))
    path.parent.mkdir(parents=True, exist_ok=True)
    _emoji_db = sqlite3.connect(path, check_same_thread=False)
    _emoji_db.row_factory = sqlite3.Row
    _emoji_db.execute(
        """
        CREATE TABLE IF NOT EXISTS emoji_labels (
            document_id TEXT PRIMARY KEY,
            label TEXT NOT NULL,
            source TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
        """
    )
    _emoji_db.execute(
        """
        CREATE TABLE IF NOT EXISTS emoji_unknowns (
            document_id TEXT PRIMARY KEY,
            document_ids TEXT,
            labels TEXT,
            chat_id TEXT,
            message_id TEXT,
            message_url TEXT,
            buttons TEXT,
            count INTEGER DEFAULT 1,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
        """
    )
    columns = {row[1] for row in _emoji_db.execute("PRAGMA table_info(emoji_unknowns)")}
    if "buttons" not in columns:
        _emoji_db.execute("ALTER TABLE emoji_unknowns ADD COLUMN buttons TEXT")
    _emoji_db.commit()
    return _emoji_db


def _normalize_emoji_label(value: Any) -> str | None:
    label = unicodedata.normalize("NFKC", str(value or "")).strip().upper()
    label = re.sub(r"\s+", "", label)
    aliases = {
        "＋": "+",
        "➕": "+",
        "加": "+",
        "PLUS": "+",
        "－": "-",
        "—": "-",
        "➖": "-",
        "减": "-",
        "MINUS": "-",
        "×": "*",
        "✖": "*",
        "✕": "*",
        "X": "*",
        "乘": "*",
        "÷": "/",
        "➗": "/",
        "除": "/",
        "＝": "=",
        "🟰": "=",
        "等于": "=",
        "？": "?",
        "❓": "?",
    }
    label = aliases.get(label, label)
    label = {
        "¥": "?",
        "￥": "?",
        "YEN": "?",
        "？": "?",
        "×": "*",
        "÷": "/",
    }.get(label, label)
    return label if EMOJI_LABEL_PATTERN.fullmatch(label) else None


def _is_operand(label: str) -> bool:
    return bool(re.fullmatch(r"[A-Z0-9]{1,4}", label or ""))


def _is_operator(label: str) -> bool:
    return label in {"+", "-", "*", "/"}


def _operand_options(tokens: list[str], index: int, direction: int) -> list[str]:
    if not 0 <= index < len(tokens) or not _is_operand(tokens[index]):
        return []
    values = [tokens[index]]
    if tokens[index].isdigit():
        digits = tokens[index]
        cursor = index + direction
        while 0 <= cursor < len(tokens) and tokens[cursor].isdigit():
            if direction > 0:
                digits += tokens[cursor]
            else:
                digits = tokens[cursor] + digits
            values.append(digits)
            cursor += direction
    return values


def _answer_candidates_from_labels(labels: list[str]) -> list[str]:
    if any(label in {None, "?"} for label in labels):
        return []
    tokens = [label for label in labels if label != "="]
    candidates: list[str] = []

    for index, token in enumerate(tokens):
        if not _is_operator(token):
            continue
        if index <= 0 or index + 1 >= len(tokens):
            continue
        for left in _operand_options(tokens, index - 1, -1):
            for right in _operand_options(tokens, index + 1, 1):
                if token == "+":
                    if left.isdigit() and right.isdigit():
                        candidates.append(str(int(left) + int(right)))
                    elif left.isalpha() and right.isalpha():
                        candidates.append(f"{left}{right}".upper())
                elif token == "-":
                    if left.isdigit() and right.isdigit():
                        value = int(left) - int(right)
                        candidates.append(str(value))
                        candidates.append(str(abs(value)))
                elif token == "*":
                    if left.isdigit() and right.isdigit():
                        candidates.append(str(int(left) * int(right)))
                elif token == "/":
                    if left.isdigit() and right.isdigit() and int(right) != 0:
                        value = int(left) / int(right)
                        if value.is_integer():
                            candidates.append(str(int(value)))

    if not candidates:
        operands = [label for label in tokens if _is_operand(label)]
        if len(operands) >= 2:
            left, right = operands[-2], operands[-1]
            if left.isdigit() and right.isdigit():
                candidates.append(str(int(left) + int(right)))
                candidates.append(f"{left}{right}")
            elif left.isalpha() and right.isalpha():
                candidates.append(f"{left}{right}".upper())

    operands = [label for label in tokens if _is_operand(label)]
    if len(operands) >= 2:
        left, right = operands[-2], operands[-1]
        if left.isdigit() and right.isdigit():
            candidates.append(f"{left}{right}")
        elif left.isalpha() and right.isalpha():
            candidates.append(f"{left}{right}".upper())

    if tokens and _is_operator(tokens[0]) and len(operands) >= 2:
        left, right = operands[0], operands[1]
        if tokens[0] == "+":
            if left.isdigit() and right.isdigit():
                candidates.append(str(int(left) + int(right)))
                candidates.append(f"{left}{right}")
            elif left.isalpha() and right.isalpha():
                candidates.append(f"{left}{right}".upper())

    deduped: list[str] = []
    for value in candidates:
        if value not in deduped:
            deduped.append(value)
    return deduped


def _cached_labels(document_ids: list[int]) -> dict[int, str]:
    if not document_ids:
        return {}
    placeholders = ",".join("?" for _ in document_ids)
    rows = _cache_connection().execute(
        f"""
        SELECT document_id, label FROM emoji_labels
        WHERE document_id IN ({placeholders})
        """,
        tuple(str(value) for value in document_ids),
    ).fetchall()
    return {
        int(document_id): label
        for document_id, label in rows
        if label and label != "?"
    }


def _save_labels(labels: dict[int, str], source: str) -> None:
    labels = {
        int(document_id): label
        for document_id, label in labels.items()
        if label and label != "?"
    }
    if not labels:
        return
    now = datetime.now().isoformat(timespec="seconds")
    _cache_connection().executemany(
        """
        INSERT INTO emoji_labels (document_id, label, source, updated_at)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(document_id) DO UPDATE SET
            label=excluded.label,
            source=excluded.source,
            updated_at=excluded.updated_at
        """,
        [
            (str(document_id), label, source, now)
            for document_id, label in labels.items()
        ],
    )
    _cache_connection().commit()



def _message_url(event: Any) -> str | None:
    chat_id = getattr(event, "chat_id", None)
    message_id = getattr(event, "id", None)
    if chat_id is None or message_id is None:
        return None
    value = str(chat_id)
    if value.startswith("-100"):
        return f"https://t.me/c/{value[4:]}/{message_id}"
    return None


def _record_unknown_labels(
    event: Any,
    document_ids: list[int],
    labels: list[str | None],
) -> None:
    unknown_ids = [
        int(document_id)
        for document_id, label in zip(document_ids, labels)
        if label in {None, "?"}
    ]
    if not unknown_ids:
        return
    now = datetime.now().isoformat(timespec="seconds")
    payload_document_ids = json.dumps([int(value) for value in document_ids], ensure_ascii=False)
    payload_labels = json.dumps(labels, ensure_ascii=False)
    payload_buttons = json.dumps(
        [str(getattr(button, "text", "")) for _, _, button in iter_buttons(event)],
        ensure_ascii=False,
    )
    chat_id = getattr(event, "chat_id", None)
    message_id = getattr(event, "id", None)
    url = _message_url(event)
    conn = _cache_connection()
    conn.executemany(
        """
        INSERT INTO emoji_unknowns (
            document_id, document_ids, labels, chat_id, message_id,
            message_url, buttons, count, created_at, updated_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?)
        ON CONFLICT(document_id) DO UPDATE SET
            document_ids=excluded.document_ids,
            labels=excluded.labels,
            chat_id=excluded.chat_id,
            message_id=excluded.message_id,
            message_url=excluded.message_url,
            buttons=excluded.buttons,
            count=emoji_unknowns.count + 1,
            updated_at=excluded.updated_at
        """,
        [
            (
                str(document_id),
                payload_document_ids,
                payload_labels,
                str(chat_id or ""),
                str(message_id or ""),
                url or "",
                now,
                now,
            )
            for document_id in unknown_ids
        ],
    )
    conn.commit()


def list_unknown_emoji_records(limit: int = 20) -> list[dict[str, Any]]:
    rows = _cache_connection().execute(
        """
        SELECT document_id, document_ids, labels, chat_id, message_id,
               message_url, buttons, count, created_at, updated_at
        FROM emoji_unknowns
        ORDER BY updated_at DESC
        LIMIT ?
        """,
        (int(limit),),
    ).fetchall()
    result: list[dict[str, Any]] = []
    for row in rows:
        item = dict(row)
        try:
            item["document_ids"] = json.loads(item.get("document_ids") or "[]")
        except Exception:
            item["document_ids"] = []
        try:
            item["labels"] = json.loads(item.get("labels") or "[]")
        except Exception:
            item["labels"] = []
        try:
            item["buttons"] = json.loads(item.get("buttons") or "[]")
        except Exception:
            item["buttons"] = []
        result.append(item)
    return result


def get_unknown_emoji_record(document_id: int) -> dict[str, Any] | None:
    rows = [
        row
        for row in list_unknown_emoji_records(100)
        if str(row.get("document_id")) == str(int(document_id))
    ]
    return rows[0] if rows else None


def label_emoji_document(document_id: int, label: str) -> str:
    normalized = _normalize_emoji_label(label)
    if not normalized or normalized == "?":
        raise ValueError("标签无效")
    _save_labels({int(document_id): normalized}, "manual")
    conn = _cache_connection()
    conn.execute("DELETE FROM emoji_unknowns WHERE document_id=?", (str(int(document_id)),))
    conn.commit()
    return normalized


def _document_alt(document: Any) -> str | None:
    for attribute in getattr(document, "attributes", None) or []:
        label = _normalize_emoji_label(getattr(attribute, "alt", None))
        if label:
            return label
    return None


def _utf16_units(text: str) -> int:
    return len(str(text or "").encode("utf-16-le")) // 2


def _select_math_entities(message: Any, entities: list[Any]) -> list[Any]:
    text = str(getattr(message, "message", "") or "")
    if not text or not entities:
        return entities[-7:]

    line_ranges: list[tuple[int, int, str]] = []
    cursor = 0
    for raw_line in text.splitlines(keepends=True):
        line = raw_line.rstrip("\r\n")
        start = cursor
        end = cursor + len(line)
        line_ranges.append((start, end, line))
        cursor += len(raw_line)

    for start, end, line in reversed(line_ranges):
        stripped = line.strip()
        if not stripped:
            continue
        if "=" not in stripped and "＝" not in stripped:
            continue
        if "?" not in stripped and "？" not in stripped:
            continue
        start16 = _utf16_units(text[:start])
        end16 = _utf16_units(text[:end])
        selected = [
            entity
            for entity in entities
            if start16 <= int(getattr(entity, "offset", 0)) < end16
        ]
        if len(selected) >= 2:
            return selected[-9:]

    markers = ("正确答案", "答案领取", "领取红包")
    marker_index = max(text.rfind(marker) for marker in markers)
    if marker_index >= 0:
        marker16 = _utf16_units(text[:marker_index])
        selected = [
            entity
            for entity in entities
            if int(getattr(entity, "offset", 0)) >= marker16
        ]
        if len(selected) >= 2:
            return selected[-9:]

    return entities[-7:]


def _image_mime_type(content: bytes, fallback: str = "image/webp") -> str:
    if content.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    if content.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png"
    if content.startswith((b"RIFF",)) and content[8:12] == b"WEBP":
        return "image/webp"
    if content.startswith((b"GIF87a", b"GIF89a")):
        return "image/gif"
    return fallback


def _answer_text_variants(value: Any) -> set[str]:
    raw = unicodedata.normalize("NFKC", str(value or "")).strip().upper()
    compact = re.sub(r"\s+", "", raw)
    normalized = normalize_button_text(raw)
    variants = {normalized} if normalized else set()

    # 兼容 18.0、１８、18️⃣、答案：18 这一类按钮文本。
    for match in re.finditer(r"-?\d+(?:\.\d+)?", raw):
        number_text = match.group(0)
        variants.add(number_text)
        try:
            number_value = float(number_text)
            if number_value.is_integer():
                variants.add(str(int(number_value)))
        except ValueError:
            pass

    # 兼容 AU / A-U / 答案AU 这类字母按钮。
    alpha_num = re.sub(r"[^A-Z0-9]+", "", compact)
    if alpha_num:
        variants.add(alpha_num.lower())
        variants.add(alpha_num)
    return {value.lower() for value in variants if value}


def _answer_button_index(event: Any, answer: str | list[str]) -> int | None:
    answers = answer if isinstance(answer, list) else [answer]
    targets: set[str] = set()
    for value in answers:
        targets.update(_answer_text_variants(value))
    for index, (_, _, button) in enumerate(iter_buttons(event)):
        button_values = _answer_text_variants(getattr(button, "text", ""))
        if button_values & targets:
            return index
    return None


def _extract_json_object(text: str) -> dict[str, Any] | None:
    match = re.search(r"\{.*\}", text or "", re.DOTALL)
    if not match:
        return None
    try:
        value = json.loads(match.group())
    except json.JSONDecodeError:
        return None
    return value if isinstance(value, dict) else None


async def _document_image_data_url(event: Any, document: Any) -> str | None:
    mime_type = str(getattr(document, "mime_type", "") or "")
    content = None
    if mime_type.startswith("image/"):
        content = await event.client.download_media(document, file=bytes)
    else:
        try:
            content = await event.client.download_media(
                document,
                file=bytes,
                thumb=-1,
            )
            mime_type = "image/webp"
        except Exception:
            logger.debug(
                "无法下载自定义 Emoji 缩略图：document=%s",
                getattr(document, "id", None),
                exc_info=True,
            )
    if not content:
        return None
    mime_type = _image_mime_type(content, mime_type or "image/webp")
    return f"data:{mime_type or 'image/webp'};base64,{base64.b64encode(content).decode('ascii')}"


async def _recognize_unknown_labels(
    event: Any,
    documents: list[Any],
    buttons: list[str],
) -> tuple[dict[int, str], float]:
    api_key = os.getenv("DASHSCOPE_API_KEY", "").strip()
    if not api_key or not documents:
        return {}, 0.0

    image_items = []
    document_ids = []
    for document in documents:
        data_url = await _document_image_data_url(event, document)
        if not data_url:
            continue
        document_ids.append(int(document.id))
        image_items.append(
            {"type": "image_url", "image_url": {"url": data_url}}
        )
    if not image_items:
        return {}, 0.0

    client = openai.AsyncOpenAI(api_key=api_key, base_url=VISION_BASE_URL)
    response = await client.chat.completions.create(
        model=VISION_MODEL,
        messages=[
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": (
                            "这些图片依次来自 Telegram 红包算式里的彩色自定义表情。"
                            "请逐张识别它显示的内容，只允许返回：数字、英文字母、+、-、*、/、=、?。"
                            "如果图片明显是运算符号，必须在 +、-、*、/、= 中选择最像的一项，不要轻易返回 ?。"
                            "只有图片完全不是算式内容、严重遮挡、无法判断时才返回 ?。"
                            "候选答案按钮为："
                            f"{buttons}。"
                            "只返回严格 JSON，例如："
                            '{"labels":["2","+","6","=","?"],"confidence":0.98}。'
                            "labels 数量必须与图片数量一致。"
                        ),
                    },
                    *image_items,
                ],
            }
        ],
        temperature=0,
        timeout=8.0,
    )
    payload = _extract_json_object(response.choices[0].message.content or "")
    if not payload:
        logger.warning(
            "视觉模型未返回可解析 JSON：%s",
            response.choices[0].message.content,
        )
        return {}, 0.0
    try:
        confidence = float(payload.get("confidence", 0))
    except (TypeError, ValueError):
        confidence = 0.0
    raw_labels = payload.get("labels")
    if not isinstance(raw_labels, list) or len(raw_labels) != len(document_ids):
        logger.warning("视觉模型标签数量异常：%s", payload)
        return {}, confidence
    labels = [_normalize_emoji_label(value) for value in raw_labels]
    if any(label is None for label in labels):
        logger.warning("视觉模型标签格式异常：%s", payload)
        return {}, confidence
    logger.info(
        "视觉模型识别结果：documents=%s labels=%s confidence=%.3f",
        document_ids,
        labels,
        confidence,
    )
    return {
        document_id: label
        for document_id, label in zip(document_ids, labels)
        if label != "?"
    }, confidence


async def _recognize_expression_answer(
    event: Any,
    documents: list[Any],
    known_labels: dict[int, str],
    buttons: list[str],
) -> tuple[dict[int, str], list[str], float]:
    api_key = os.getenv("DASHSCOPE_API_KEY", "").strip()
    if not api_key or not documents:
        return {}, [], 0.0

    image_items = []
    document_ids = []
    known_hint = []
    for document in documents:
        data_url = await _document_image_data_url(event, document)
        if not data_url:
            continue
        document_id = int(document.id)
        document_ids.append(document_id)
        label = known_labels.get(document_id)
        known_hint.append(label if label else "?")
        image_items.append(
            {"type": "image_url", "image_url": {"url": data_url}}
        )
    if not image_items:
        return {}, [], 0.0

    client = openai.AsyncOpenAI(api_key=api_key, base_url=VISION_BASE_URL)
    response = await client.chat.completions.create(
        model=VISION_MODEL,
        messages=[
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": (
                            "These images are custom emoji from one Telegram red-packet math captcha, "
                            "in their original order. Identify the full expression and the final answer. "
                            "Allowed labels are digits 0-9, uppercase letters A-Z, operators + - * / =, and ?. "
                            "If an image is clearly an operator symbol, choose the closest operator from + - * / =; do not use ? casually. "
                            "Use ? only when the image is not part of the expression, heavily obscured, or truly impossible to judge. "
                            f"Known labels in order: {known_hint}. "
                            f"Candidate answer buttons: {buttons}. "
                            "Return strict JSON only, for example: "
                            '{"labels":["0","+","1","8","=","?"],"expression":"0+18","answers":["18"],"confidence":0.98}. '
                            "The labels array length must equal the number of images. "
                            "answers should include the most likely button text values, with the best answer first."
                        ),
                    },
                    *image_items,
                ],
            }
        ],
        temperature=0,
        timeout=8.0,
    )
    payload = _extract_json_object(response.choices[0].message.content or "")
    if not payload:
        logger.warning(
            "Emoji 完整识别未返回可解析 JSON：%s",
            response.choices[0].message.content,
        )
        return {}, [], 0.0
    try:
        confidence = float(payload.get("confidence", 0))
    except (TypeError, ValueError):
        confidence = 0.0

    raw_labels = payload.get("labels")
    labels_by_id: dict[int, str] = {}
    if isinstance(raw_labels, list) and len(raw_labels) == len(document_ids):
        normalized_labels = [_normalize_emoji_label(value) for value in raw_labels]
        if all(label is not None for label in normalized_labels):
            labels_by_id = {
                document_id: label
                for document_id, label in zip(document_ids, normalized_labels)
                if label != "?"
            }
        else:
            logger.warning("Emoji 完整识别标签格式异常：%s", payload)
    else:
        logger.warning("Emoji 完整识别标签数量异常：%s", payload)

    raw_answers = payload.get("answers", payload.get("answer", []))
    if isinstance(raw_answers, (str, int, float)):
        raw_answers = [raw_answers]
    answers: list[str] = []
    if isinstance(raw_answers, list):
        for value in raw_answers:
            text = unicodedata.normalize("NFKC", str(value or "")).strip().upper()
            if text and text not in answers:
                answers.append(text)

    merged_labels = [
        labels_by_id.get(document_id) or known_labels.get(document_id)
        for document_id in document_ids
    ]
    if all(label is not None for label in merged_labels):
        for value in _answer_candidates_from_labels(merged_labels):
            if value not in answers:
                answers.append(value)

    logger.info(
        "Emoji 完整识别结果：documents=%s labels=%s answers=%s confidence=%.3f",
        document_ids,
        [labels_by_id.get(document_id) for document_id in document_ids],
        answers,
        confidence,
    )
    return labels_by_id, answers, confidence


async def parse_custom_emoji_math(event: Any) -> Optional[int]:
    """本地缓存优先识别自定义 Emoji 算式，必要时使用阿里视觉模型学习。"""
    message = event.message
    entities = [
        entity
        for entity in (getattr(message, "entities", None) or [])
        if isinstance(entity, MessageEntityCustomEmoji)
    ]
    if len(entities) < 2:
        return None
    # 题目前的灯泡等装饰也可能是自定义 Emoji；算式通常位于最后 2–7 个。
    # 兼容：5 + 3、5 + 3 = ?、A + U = ?，以及 +、-、=、? 都是自定义表情的情况。
    entities = _select_math_entities(message, entities)

    document_ids = [int(entity.document_id) for entity in entities]
    labels_by_id = _cached_labels(document_ids)
    learned_from_alt: dict[int, str] = {}
    learned_from_ai: dict[int, str] = {}

    try:
        unknown_ids = [
            document_id
            for document_id in document_ids
            if document_id not in labels_by_id
        ]
        if unknown_ids:
            async with _emoji_learning_lock:
                # 其他账号可能刚刚完成了同一套新表情的学习。
                labels_by_id.update(_cached_labels(unknown_ids))
                unknown_ids = [
                    document_id
                    for document_id in unknown_ids
                    if document_id not in labels_by_id
                ]
                documents = []
                if unknown_ids:
                    documents = list(
                        await event.client(
                            GetCustomEmojiDocumentsRequest(
                                document_id=unknown_ids
                            )
                        )
                    )
                documents_by_id = {
                    int(document.id): document for document in documents
                }
                for document_id in unknown_ids:
                    document = documents_by_id.get(document_id)
                    label = _document_alt(document) if document else None
                    if label:
                        labels_by_id[document_id] = label
                        learned_from_alt[document_id] = label

                still_unknown = [
                    documents_by_id[document_id]
                    for document_id in unknown_ids
                    if document_id not in labels_by_id
                    and document_id in documents_by_id
                ]
                if still_unknown:
                    buttons = [
                        str(getattr(button, "text", ""))
                        for _, _, button in iter_buttons(event)
                    ]
                    ai_labels, confidence = await _recognize_unknown_labels(
                        event,
                        still_unknown,
                        buttons,
                    )
                    if confidence >= 0.8:
                        labels_by_id.update(ai_labels)
                        learned_from_ai.update(ai_labels)

        ordered_labels = [labels_by_id.get(value) for value in document_ids]
        full_answers: list[str] = []
        if any(label is None for label in ordered_labels):
            documents = list(
                await event.client(
                    GetCustomEmojiDocumentsRequest(document_id=document_ids)
                )
            )
            buttons = [
                str(getattr(button, "text", ""))
                for _, _, button in iter_buttons(event)
            ]
            full_labels, full_answers, full_confidence = await _recognize_expression_answer(
                event,
                documents,
                labels_by_id,
                buttons,
            )
            if full_confidence >= 0.75:
                labels_by_id.update(full_labels)
                learned_from_ai.update(full_labels)
                ordered_labels = [labels_by_id.get(value) for value in document_ids]
        if any(label is None for label in ordered_labels):
            _record_unknown_labels(event, document_ids, ordered_labels)
            logger.info("自定义 Emoji 尚未识别完整：%s", document_ids)
            return None
        if any(label == "?" for label in ordered_labels):
            _record_unknown_labels(event, document_ids, ordered_labels)
            logger.info("自定义 Emoji 存在未知符号，放弃自动点击：labels=%s documents=%s", ordered_labels, document_ids)
            return None
        answers = _answer_candidates_from_labels(ordered_labels)
        for value in full_answers:
            if value not in answers:
                answers.append(value)
        if not answers:
            return None
        button_index = _answer_button_index(event, answers)
        if button_index is None:
            documents = list(
                await event.client(
                    GetCustomEmojiDocumentsRequest(document_id=document_ids)
                )
            )
            buttons = [
                str(getattr(button, "text", ""))
                for _, _, button in iter_buttons(event)
            ]
            full_labels, full_answers, full_confidence = await _recognize_expression_answer(
                event,
                documents,
                labels_by_id,
                buttons,
            )
            if full_confidence >= 0.75:
                labels_by_id.update(full_labels)
                for value in full_answers:
                    if value not in answers:
                        answers.append(value)
                button_index = _answer_button_index(event, answers)
                if button_index is not None:
                    learned_from_ai.update(full_labels)
        if button_index is None:
            logger.warning(
                "Emoji 识别结果未匹配按钮，不缓存：labels=%s answers=%s",
                ordered_labels,
                answers,
            )
            return None

        _save_labels(learned_from_alt, "telegram_alt")
        _save_labels(learned_from_ai, "dashscope")
        logger.info(
            "Emoji 算式识别成功：labels=%s answers=%s button=%s new=%s",
            ordered_labels,
            answers,
            button_index,
            len(learned_from_alt) + len(learned_from_ai),
        )
        return button_index
    except Exception:
        logger.exception("自定义 Emoji 算式识别异常")
        return None
