import asyncio
import io
from collections import deque
import logging
import os
import random
import re
import sqlite3
import sys
from dataclasses import dataclass
from datetime import datetime, time, timedelta
from time import monotonic
from decimal import Decimal, InvalidOperation
from html import escape
from typing import Any, Optional
from zoneinfo import ZoneInfo

import socks
from dotenv import load_dotenv
from telethon import Button, TelegramClient, events
from telethon.errors import FloodWaitError, MessageNotModifiedError, SessionPasswordNeededError
from telethon.errors.rpcerrorlist import ChannelPrivateError
from telethon.sessions import StringSession
from telethon.tl.functions.bots import SetBotCommandsRequest
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.tl.functions.messages import GetCustomEmojiDocumentsRequest, ImportChatInviteRequest
from telethon.tl.types import BotCommand, BotCommandScopeDefault, InputPeerChannel

from .clicker import (
    get_unknown_emoji_record,
    label_emoji_document,
    list_unknown_emoji_records,
)
from .listener import handle_message
from .tasks import create_tracked_task

load_dotenv()

API_ID = 0
API_HASH = "your_api_hash_here"
BOT_TOKEN = "your_bot_token_here"
ADMIN_ID = 0
proxy_host = os.getenv("TG_PROXY_HOST", "127.0.0.1").strip()
proxy_port = int(os.getenv("TG_PROXY_PORT", "7890"))
PROXY = (socks.SOCKS5, proxy_host, proxy_port) if proxy_host else None

logger = logging.getLogger(__name__)
REPORT_TZ = ZoneInfo(os.getenv("DAILY_REPORT_TIMEZONE", "Asia/Shanghai"))
DAILY_REPORT_TIME = time(
    int(os.getenv("DAILY_REPORT_HOUR", "22")),
    int(os.getenv("DAILY_REPORT_MINUTE", "0")),
)
JOIN_GROUP_DELAY_MIN = float(os.getenv("JOIN_GROUP_DELAY_MIN", "8"))
JOIN_GROUP_DELAY_MAX = float(os.getenv("JOIN_GROUP_DELAY_MAX", "25"))

db = sqlite3.connect("users.db", check_same_thread=False)
db.row_factory = sqlite3.Row
db.execute(
    """
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY,
        is_auth INTEGER DEFAULT 0,
        session TEXT,
        username TEXT,
        display_name TEXT,
        account_id INTEGER,
        account_username TEXT,
        account_name TEXT,
        account_phone TEXT,
        notify_enabled INTEGER DEFAULT 1,
        first_seen TEXT,
        updated_at TEXT
    )
    """
)
existing_columns = {row[1] for row in db.execute("PRAGMA table_info(users)")}
for column, definition in (
    ("is_auth", "INTEGER DEFAULT 0"),
    ("session", "TEXT"),
    ("username", "TEXT"),
    ("display_name", "TEXT"),
    ("account_id", "INTEGER"),
    ("account_username", "TEXT"),
    ("account_name", "TEXT"),
    ("account_phone", "TEXT"),
    ("notify_enabled", "INTEGER DEFAULT 1"),
    ("first_seen", "TEXT"),
    ("updated_at", "TEXT"),
):
    if column not in existing_columns:
        db.execute(f"ALTER TABLE users ADD COLUMN {column} {definition}")
db.execute(
    """
    CREATE TABLE IF NOT EXISTS accounts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        owner_id INTEGER NOT NULL,
        telegram_id INTEGER NOT NULL,
        session TEXT NOT NULL,
        username TEXT,
        display_name TEXT,
        phone TEXT,
        notify_enabled INTEGER DEFAULT 1,
        claim_enabled INTEGER DEFAULT 0,
        skip_count_gt_amount INTEGER DEFAULT 0,
        click_delay REAL DEFAULT 0,
        click_delay_max REAL DEFAULT 0,
        updated_at TEXT,
        UNIQUE(owner_id, telegram_id)
    )
    """
)
account_columns = {row[1] for row in db.execute("PRAGMA table_info(accounts)")}
if "skip_count_gt_amount" not in account_columns:
    db.execute(
        "ALTER TABLE accounts ADD COLUMN skip_count_gt_amount INTEGER DEFAULT 0"
    )
if "claim_enabled" not in account_columns:
    db.execute(
        "ALTER TABLE accounts ADD COLUMN claim_enabled INTEGER DEFAULT 0"
    )
if "click_delay" not in account_columns:
    db.execute("ALTER TABLE accounts ADD COLUMN click_delay REAL DEFAULT 0")
if "click_delay_max" not in account_columns:
    db.execute("ALTER TABLE accounts ADD COLUMN click_delay_max REAL DEFAULT 0")
if "threshold_enabled" not in account_columns:
    db.execute("ALTER TABLE accounts ADD COLUMN threshold_enabled INTEGER DEFAULT 1")
if "allowed_chats_enabled" not in account_columns:
    db.execute("ALTER TABLE accounts ADD COLUMN allowed_chats_enabled INTEGER DEFAULT 0")
db.execute(
    """
    CREATE TABLE IF NOT EXISTS account_thresholds (
        account_id INTEGER NOT NULL,
        currency TEXT NOT NULL,
        minimum TEXT NOT NULL,
        PRIMARY KEY (account_id, currency)
    )
    """
)
db.execute(
    """
    CREATE TABLE IF NOT EXISTS account_blocked_bots (
        account_id INTEGER NOT NULL,
        bot_username TEXT NOT NULL,
        PRIMARY KEY (account_id, bot_username)
    )
    """
)
db.execute(
    """
    CREATE TABLE IF NOT EXISTS account_allowed_chats (
        account_id INTEGER NOT NULL,
        chat_id INTEGER NOT NULL,
        chat_name TEXT,
        updated_at TEXT,
        PRIMARY KEY (account_id, chat_id)
    )
    """
)
db.execute(
    """
    CREATE TABLE IF NOT EXISTS account_recent_chats (
        account_id INTEGER NOT NULL,
        chat_id INTEGER NOT NULL,
        chat_name TEXT,
        updated_at TEXT,
        PRIMARY KEY (account_id, chat_id)
    )
    """
)
db.execute(
    """
    CREATE TABLE IF NOT EXISTS public_relay_entities (
        account_id INTEGER NOT NULL,
        username TEXT NOT NULL,
        entity_id INTEGER,
        access_hash INTEGER,
        status TEXT NOT NULL DEFAULT 'unknown',
        expire_at INTEGER DEFAULT 0,
        updated_at INTEGER NOT NULL,
        last_error TEXT,
        PRIMARY KEY (account_id, username)
    )
    """
)
db.execute(
    """
    CREATE TABLE IF NOT EXISTS public_relay_resolve_usage (
        account_id INTEGER NOT NULL,
        window_start INTEGER NOT NULL,
        resolve_count INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY (account_id, window_start)
    )
    """
)
db.execute(
    """
    CREATE TABLE IF NOT EXISTS claim_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        success INTEGER NOT NULL,
        clicked INTEGER NOT NULL,
        chat_id INTEGER,
        chat_name TEXT,
        amount TEXT,
        currency TEXT,
        reason TEXT,
        message_url TEXT,
        account_ref INTEGER
    )
    """
)
log_columns = {row[1] for row in db.execute("PRAGMA table_info(claim_logs)")}
if "account_ref" not in log_columns:
    db.execute("ALTER TABLE claim_logs ADD COLUMN account_ref INTEGER")
if "manual_required" not in log_columns:
    db.execute("ALTER TABLE claim_logs ADD COLUMN manual_required INTEGER DEFAULT 0")
db.execute(
    """
    CREATE TABLE IF NOT EXISTS activity_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        action TEXT NOT NULL,
        detail TEXT
    )
    """
)
db.execute(
    "UPDATE users SET first_seen=updated_at "
    "WHERE first_seen IS NULL AND updated_at IS NOT NULL"
)

# 将旧版 users 表中的单账号登录数据迁移到多账号表。
db.execute(
    """
    INSERT OR IGNORE INTO accounts (
        owner_id, telegram_id, session, username, display_name, phone,
        notify_enabled, updated_at
    )
    SELECT id, account_id, session, account_username, account_name,
           account_phone, COALESCE(notify_enabled, 1), updated_at
    FROM users
    WHERE session IS NOT NULL AND session<>'' AND account_id IS NOT NULL
    """
)
db.commit()

bot = TelegramClient("admin_bot", API_ID, API_HASH, proxy=PROXY)
login_states: dict[int, dict] = {}
setting_states: dict[int, dict] = {}
SUPPORTED_CURRENCIES = ("CNY", "USDT", "KKCOIN", "JIBA", "TON", "TRX")
BLOCKABLE_BOTS = ("okpay", "kkpay", "fllqb", "dlqb")
DEFAULT_CURRENCY_THRESHOLDS = {
    "KKCOIN": Decimal(os.getenv("DEFAULT_KKCOIN_THRESHOLD", "50000")),
}


@dataclass
class Worker:
    task: asyncio.Task
    owner_id: int
    account_db_id: int
    client: Optional[TelegramClient] = None
    account_name: str = ""


active_workers: dict[int, Worker] = {}
_broadcasted_packets: set[tuple[int, int]] = set()
_broadcast_order: deque[tuple[int, int]] = deque()
MAX_BROADCAST_HISTORY = 5000
_public_entity_cache: dict[tuple[int, str], Any] = {}
_public_username_entity_cache: dict[str, Any] = {}
_public_resolve_cooldown_until: dict[int, float] = {}
_public_account_username_cooldown_until: dict[tuple[int, str], float] = {}
PUBLIC_USERNAME_FAIL_COOLDOWN_SECONDS = int(os.getenv("PUBLIC_USERNAME_FAIL_COOLDOWN_SECONDS", "86400"))
PUBLIC_RELAY_SUCCESS_TTL_SECONDS = int(os.getenv("PUBLIC_RELAY_SUCCESS_TTL_SECONDS", str(30 * 86400)))
PUBLIC_RELAY_FLOOD_EXTRA_COOLDOWN_SECONDS = int(os.getenv("PUBLIC_RELAY_FLOOD_EXTRA_COOLDOWN_SECONDS", "1800"))
PUBLIC_RELAY_RESOLVE_LIMIT_PER_HOUR = int(os.getenv("PUBLIC_RELAY_RESOLVE_LIMIT_PER_HOUR", "2"))
PUBLIC_RELAY_NEW_RESOLVE_TARGETS_PER_PACKET = int(os.getenv("PUBLIC_RELAY_NEW_RESOLVE_TARGETS_PER_PACKET", "1"))
ACCOUNT_TRANSIENT_ERROR_COOLDOWN_SECONDS = int(os.getenv("ACCOUNT_TRANSIENT_ERROR_COOLDOWN_SECONDS", "600"))
PUBLIC_CACHE_MAX_SIZE = int(os.getenv("PUBLIC_CACHE_MAX_SIZE", "2000"))
PUBLIC_RELAY_ENABLED = os.getenv("PUBLIC_RELAY_ENABLED", "1").lower() in {
    "1",
    "true",
    "yes",
    "on",
}
TG_UPDATE_ERROR_WINDOW_SECONDS = int(os.getenv("TG_UPDATE_ERROR_WINDOW_SECONDS", "180"))
TG_UPDATE_ERROR_THRESHOLD = int(os.getenv("TG_UPDATE_ERROR_THRESHOLD", "20"))
TG_UPDATE_RECOVERY_COOLDOWN_SECONDS = int(os.getenv("TG_UPDATE_RECOVERY_COOLDOWN_SECONDS", "1800"))
TG_UPDATE_AUTO_RECOVER_ENABLED = os.getenv("TG_UPDATE_AUTO_RECOVER_ENABLED", "0").lower() in {
    "1",
    "true",
    "yes",
    "on",
}
# Only severe Telegram update-difference failures should trigger auto recovery.
# PersistentTimestampOutdatedError is common after reconnects or when a busy
# channel has many updates; Telethon normally recovers by fetching differences.
TELETHON_UPDATE_ERROR_KEYWORDS = (
    "RpcMcgetFailError",
    "ending getting difference prematurely",
)
TELETHON_UPDATE_IGNORE_KEYWORDS = (
    "PersistentTimestampOutdatedError",
)
_telegram_update_error_times: deque[float] = deque()
_telegram_update_error_last_message = ""
_telegram_update_recovery_last_at = 0.0
_telegram_update_recovery_task: asyncio.Task | None = None
_telethon_update_log_handler_installed = False
_account_transient_error_cooldown_until: dict[int, float] = {}
_packet_summaries: dict[tuple[int, int], dict] = {}
_summarized_packets: set[tuple[int, int]] = set()
_summary_order: deque[tuple[int, int]] = deque()
SUMMARY_MIN_WAIT_SECONDS = 2.0
SUMMARY_MAX_WAIT_SECONDS = 15.0
SUMMARY_DETAIL_PAGE_SIZE = 8
_sent_summaries: dict[tuple[int, int], dict] = {}
JOIN_VERIFY_WATCH_SECONDS = int(os.getenv("JOIN_VERIFY_WATCH_SECONDS", "180"))
JOIN_VERIFY_KEYWORDS = (
    "验证",
    "验证码",
    "人机",
    "captcha",
    "hcaptcha",
    "verify",
    "verification",
    "bot check",
    "点击验证",
    "完成验证",
    "入群验证",
    "进群验证",
    "私聊验证",
    "私聊机器人",
    "私聊管理",
    "start",
)
JOIN_VERIFY_EXCLUDE_KEYWORDS = (
    "私聊下注",
    "下注",
    "开奖",
    "开奖结果",
    "中奖",
    "赔率",
    "号码:",
    "号码：",
    "恭喜以下玩家",
    "加拿大pc",
    "期",
)
_join_verify_watches: dict[int, dict] = {}
PREBROADCAST_TEXT_KEYWORDS = ("红包", "red packet", "redpacket")
PREBROADCAST_BUTTON_KEYWORDS = ("领取", "红包")
PREBROADCAST_TEXT_KEYWORDS = ("\u7ea2\u5305", "red packet", "redpacket")
PREBROADCAST_BUTTON_KEYWORDS = ("\u9886\u53d6", "\u7ea2\u5305")


def should_prebroadcast_packet(event) -> bool:
    message = getattr(event, "message", None)
    text = str(getattr(message, "message", "") or "").lower()
    if any(keyword in text for keyword in PREBROADCAST_TEXT_KEYWORDS):
        return True

    for row in getattr(event, "buttons", None) or []:
        for button in row:
            button_text = str(getattr(button, "text", "") or "").lower()
            if any(keyword in button_text for keyword in PREBROADCAST_BUTTON_KEYWORDS):
                return True
    return False


def is_authorized(uid: int) -> bool:
    if uid == ADMIN_ID:
        return True
    row = db.execute("SELECT is_auth FROM users WHERE id=?", (uid,)).fetchone()
    return bool(row and row["is_auth"] == 1)


def account_count(uid: int) -> int:
    return db.execute(
        "SELECT COUNT(*) FROM accounts WHERE owner_id=?", (uid,)
    ).fetchone()[0]


def is_running(account_db_id: int) -> bool:
    worker = active_workers.get(account_db_id)
    return bool(worker and not worker.task.done())


def notifications_enabled(account_db_id: int) -> bool:
    row = db.execute(
        "SELECT notify_enabled FROM accounts WHERE id=?", (account_db_id,)
    ).fetchone()
    return not row or row["notify_enabled"] != 0


def get_account(account_db_id: int, owner_id: int):
    return db.execute(
        "SELECT * FROM accounts WHERE id=? AND owner_id=?",
        (account_db_id, owner_id),
    ).fetchone()


def get_account_by_id(account_db_id: int):
    return db.execute(
        "SELECT * FROM accounts WHERE id=?",
        (account_db_id,),
    ).fetchone()


def account_thresholds(account_db_id: int) -> dict[str, Decimal]:
    account = get_account_by_id(account_db_id)
    if account and account["threshold_enabled"] == 0:
        return {}
    rows = db.execute(
        "SELECT currency, minimum FROM account_thresholds WHERE account_id=?",
        (account_db_id,),
    ).fetchall()
    thresholds = dict(DEFAULT_CURRENCY_THRESHOLDS)
    thresholds.update({
        row["currency"]: Decimal(row["minimum"])
        for row in rows
    })
    return thresholds


def threshold_enabled(account_db_id: int) -> bool:
    row = get_account_by_id(account_db_id)
    return not row or row["threshold_enabled"] != 0


def account_blocked_bots(account_db_id: int) -> set[str]:
    return {
        row["bot_username"]
        for row in db.execute(
            "SELECT bot_username FROM account_blocked_bots WHERE account_id=?",
            (account_db_id,),
        ).fetchall()
    }


def allowed_chats_enabled(account_db_id: int) -> bool:
    row = get_account_by_id(account_db_id)
    return bool(row and row["allowed_chats_enabled"])


def account_allowed_chat_ids(account_db_id: int) -> set[int]:
    return {
        int(row["chat_id"])
        for row in db.execute(
            "SELECT chat_id FROM account_allowed_chats WHERE account_id=?",
            (account_db_id,),
        ).fetchall()
    }


def remember_account_chat(account_db_id: int, chat_id: int, chat_name: str) -> None:
    now = datetime.now().isoformat(timespec="seconds")
    db.execute(
        """
        INSERT INTO account_recent_chats (account_id, chat_id, chat_name, updated_at)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(account_id, chat_id) DO UPDATE SET
            chat_name=excluded.chat_name,
            updated_at=excluded.updated_at
        """,
        (account_db_id, int(chat_id), chat_name[:200], now),
    )
    db.commit()


def account_recent_chats(account_db_id: int, limit: int = 12) -> list[sqlite3.Row]:
    return db.execute(
        """
        SELECT chat_id, chat_name, updated_at
        FROM account_recent_chats
        WHERE account_id=?
        ORDER BY updated_at DESC
        LIMIT ?
        """,
        (account_db_id, limit),
    ).fetchall()


def account_recently_seen_chat(account_db_id: int, chat_id: int, hours: int = 72) -> bool:
    row = db.execute(
        """
        SELECT 1
        FROM account_recent_chats
        WHERE account_id=?
          AND chat_id=?
          AND updated_at >= datetime('now', ?)
        LIMIT 1
        """,
        (account_db_id, int(chat_id), f"-{hours} hours"),
    ).fetchone()
    return bool(row)


def _epoch_now() -> int:
    return int(datetime.now().timestamp())


def public_relay_record(account_db_id: int, username: str) -> sqlite3.Row | None:
    return db.execute(
        """
        SELECT account_id, username, entity_id, access_hash, status, expire_at, updated_at, last_error
        FROM public_relay_entities
        WHERE account_id=? AND username=?
        """,
        (account_db_id, username.lower()),
    ).fetchone()


def public_relay_cached_peer(account_db_id: int, username: str) -> InputPeerChannel | None:
    row = public_relay_record(account_db_id, username)
    if not row or row["status"] != "ok":
        return None
    if int(row["expire_at"] or 0) <= _epoch_now():
        return None
    if row["entity_id"] is None or row["access_hash"] is None:
        return None
    try:
        return InputPeerChannel(
            channel_id=int(row["entity_id"]),
            access_hash=int(row["access_hash"]),
        )
    except (TypeError, ValueError):
        return None


def public_relay_has_valid_success(account_db_id: int, username: str) -> bool:
    return public_relay_cached_peer(account_db_id, username) is not None


def public_relay_cooldown_left(account_db_id: int, username: str) -> int:
    row = public_relay_record(account_db_id, username)
    if not row or row["status"] == "ok":
        return 0
    return max(0, int(row["expire_at"] or 0) - _epoch_now())


def save_public_relay_status(
    account_db_id: int,
    username: str,
    *,
    status: str,
    entity_id: int | None = None,
    access_hash: int | None = None,
    ttl_seconds: int,
    error: str = "",
) -> None:
    now = _epoch_now()
    db.execute(
        """
        INSERT INTO public_relay_entities (
            account_id, username, entity_id, access_hash, status, expire_at, updated_at, last_error
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(account_id, username) DO UPDATE SET
            entity_id=excluded.entity_id,
            access_hash=excluded.access_hash,
            status=excluded.status,
            expire_at=excluded.expire_at,
            updated_at=excluded.updated_at,
            last_error=excluded.last_error
        """,
        (
            account_db_id,
            username.lower(),
            entity_id,
            access_hash,
            status,
            now + max(60, int(ttl_seconds)),
            now,
            error[:500],
        ),
    )
    db.commit()


def save_public_relay_success(account_db_id: int, username: str, entity: Any) -> None:
    entity_id = getattr(entity, "channel_id", None) or getattr(entity, "id", None)
    access_hash = getattr(entity, "access_hash", None)
    if entity_id is None or access_hash is None:
        return
    save_public_relay_status(
        account_db_id,
        username,
        status="ok",
        entity_id=int(entity_id),
        access_hash=int(access_hash),
        ttl_seconds=PUBLIC_RELAY_SUCCESS_TTL_SECONDS,
    )


def consume_public_relay_resolve_quota(account_db_id: int) -> bool:
    if PUBLIC_RELAY_RESOLVE_LIMIT_PER_HOUR <= 0:
        return False
    now = _epoch_now()
    window_start = now - (now % 3600)
    row = db.execute(
        """
        SELECT resolve_count
        FROM public_relay_resolve_usage
        WHERE account_id=? AND window_start=?
        """,
        (account_db_id, window_start),
    ).fetchone()
    current = int(row["resolve_count"] if row else 0)
    if current >= PUBLIC_RELAY_RESOLVE_LIMIT_PER_HOUR:
        return False
    db.execute(
        """
        INSERT INTO public_relay_resolve_usage (account_id, window_start, resolve_count)
        VALUES (?, ?, 1)
        ON CONFLICT(account_id, window_start) DO UPDATE SET
            resolve_count=resolve_count + 1
        """,
        (account_db_id, window_start),
    )
    db.commit()
    return True


def account_allowed_chats(account_db_id: int) -> list[sqlite3.Row]:
    return db.execute(
        """
        SELECT chat_id, chat_name, updated_at
        FROM account_allowed_chats
        WHERE account_id=?
        ORDER BY updated_at DESC
        """,
        (account_db_id,),
    ).fetchall()


def parse_allowed_chat_id(raw: str) -> int:
    value = raw.strip()
    value = value.replace("，", " ").replace(",", " ").split()[0]
    if not re.fullmatch(r"-?\d+", value):
        raise ValueError("请只输入群 ID，例如 -1001234567890。")
    chat_id = int(value)
    if chat_id > 0 and value.startswith("100") and len(value) >= 10:
        chat_id = -chat_id
    if chat_id == 0:
        raise ValueError("群 ID 不能是 0。")
    return chat_id


def normalize_click_delay(value: float, max_value: float | None = None) -> tuple[float, float]:
    low = max(0.0, min(float(value or 0), 10.0))
    high = max(0.0, min(float(max_value if max_value is not None else low), 10.0))
    if high < low:
        low, high = high, low
    return low, high


def format_click_delay(row: sqlite3.Row) -> str:
    low, high = normalize_click_delay(row["click_delay"] or 0, row["click_delay_max"] or row["click_delay"] or 0)
    if abs(high - low) < 0.001:
        return f"{low:g} 秒"
    return f"随机 {low:g}-{high:g} 秒"


def parse_click_delay_setting(raw: str) -> tuple[float, float]:
    text = raw.strip().replace("～", "-").replace("—", "-").replace("–", "-")
    text = text.replace("到", "-").replace("至", "-")
    parts = [part for part in re.split(r"\s*-\s*", text) if part]
    if len(parts) == 1:
        try:
            value = float(parts[0])
        except ValueError as exc:
            raise ValueError("请输入固定秒数，例如 0.5；或随机范围，例如 0.5-2。") from exc
        low, high = value, value
    elif len(parts) == 2:
        try:
            low, high = float(parts[0]), float(parts[1])
        except ValueError as exc:
            raise ValueError("随机范围格式不正确，例如 0.5-2。") from exc
    else:
        raise ValueError("请输入固定秒数，例如 0.5；或随机范围，例如 0.5-2。")
    if low < 0 or high < 0 or low > 10 or high > 10:
        raise ValueError("点击延迟必须在 0–10 秒之间。")
    return normalize_click_delay(low, high)


def log_activity(uid: int, action: str, detail: str = "") -> None:
    db.execute(
        """
        INSERT INTO activity_logs (user_id, created_at, action, detail)
        VALUES (?, ?, ?, ?)
        """,
        (
            uid,
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            action[:80],
            detail[:500],
        ),
    )
    db.commit()


async def remember_user(event) -> None:
    sender = await event.get_sender()
    first = getattr(sender, "first_name", "") or ""
    last = getattr(sender, "last_name", "") or ""
    display_name = " ".join(part for part in (first, last) if part).strip()
    username = getattr(sender, "username", None)
    db.execute(
        """
        INSERT INTO users (id, username, display_name, first_seen, updated_at)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET
            username=excluded.username,
            display_name=excluded.display_name,
            updated_at=excluded.updated_at
        """,
        (
            event.sender_id,
            username,
            display_name,
            datetime.now().isoformat(timespec="seconds"),
            datetime.now().isoformat(timespec="seconds"),
        ),
    )
    db.commit()


async def user_identity(event) -> str:
    sender = await event.get_sender()
    first = getattr(sender, "first_name", "") or ""
    last = getattr(sender, "last_name", "") or ""
    name = " ".join(part for part in (first, last) if part).strip() or "未设置昵称"
    return name


def user_buttons(uid: int):
    if not is_authorized(uid):
        return [[Button.inline("🔄 刷新资料", b"home")]]
    rows = [[Button.inline("👤 查看我的账号", b"account")]]
    if uid == ADMIN_ID:
        rows.append([Button.inline("🛠 管理员中心", b"admin")])
    return rows


async def render_home(event, *, edit: bool = False) -> None:
    await remember_user(event)
    uid = event.sender_id
    name = await user_identity(event)
    if not is_authorized(uid):
        text = (
            "👋 <b>欢迎使用红包监听助手</b>\n\n"
            "🔒 当前状态：<b>未授权</b>\n"
            f"👤 昵称：{escape(name)}\n"
            f"🆔 Telegram ID：<code>{uid}</code>\n\n"
            "请将上面的 ID 提供给管理员申请授权。"
        )
    else:
        total_accounts = account_count(uid)
        running_accounts = sum(
            is_running(row["id"])
            for row in db.execute(
                "SELECT id FROM accounts WHERE owner_id=?", (uid,)
            )
        )
        text = (
            "🧧 <b>红包监听控制台</b>\n\n"
            f"👤 昵称：{escape(name)}\n"
            f"🆔 Telegram ID：<code>{uid}</code>\n"
            f"🔐 已登录账号：<b>{total_accounts}</b> 个\n"
            f"🧧 正在抢红包：<b>{running_accounts}</b> 个\n\n"
            "点击“查看我的账号”进行设置。"
        )
    kwargs = {"buttons": user_buttons(uid), "parse_mode": "html"}
    if edit:
        await event.edit(text, **kwargs)
    else:
        await event.respond(text, **kwargs)


def save_account_profile(uid: int, session: str, me) -> int:
    first = getattr(me, "first_name", "") or ""
    last = getattr(me, "last_name", "") or ""
    account_name = " ".join(part for part in (first, last) if part).strip()
    db.execute(
        """
        INSERT INTO accounts (
            owner_id, telegram_id, session, username, display_name, phone,
            notify_enabled, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, 1, ?)
        ON CONFLICT(owner_id, telegram_id) DO UPDATE SET
            session=excluded.session,
            username=excluded.username,
            display_name=excluded.display_name,
            phone=excluded.phone,
            updated_at=excluded.updated_at
        """,
        (
            uid,
            getattr(me, "id", None),
            session,
            getattr(me, "username", None),
            account_name,
            getattr(me, "phone", None),
            datetime.now().isoformat(timespec="seconds"),
        ),
    )
    db.commit()
    return db.execute(
        "SELECT id FROM accounts WHERE owner_id=? AND telegram_id=?",
        (uid, getattr(me, "id", None)),
    ).fetchone()["id"]


async def render_accounts(event, *, edit: bool = False) -> None:
    uid = event.sender_id
    rows = db.execute(
        """
        SELECT id, telegram_id, phone, display_name, notify_enabled
        FROM accounts WHERE owner_id=? ORDER BY id
        """,
        (uid,),
    ).fetchall()
    text = (
        "👤 <b>我的账号</b>\n\n"
        "每行依次是：账号｜抢红包｜红包通知\n"
        "点击手机号可查看账号详细信息。"
        if rows
        else "👤 <b>我的账号</b>\n\n❌ 暂无已登录账号。"
    )
    buttons = []
    for row in rows:
        phone = f"+{row['phone']}" if row["phone"] else str(row["telegram_id"])
        buttons.append(
            [
                Button.inline(phone, f"detail:{row['id']}".encode()),
                Button.inline(
                    "🧧 ✅" if is_running(row["id"]) else "🧧 ❌",
                    f"claim:{row['id']}".encode(),
                ),
                Button.inline(
                    "🔔 ✅" if row["notify_enabled"] else "🔕 ❌",
                    f"notify:{row['id']}".encode(),
                ),
            ]
        )
    buttons.extend(
        [
            *(
                [[Button.inline("📥 我的全部账号加入群", b"join_group:mine")]]
                if rows
                else []
            ),
            [Button.inline("➕ 登录新账号", b"login")],
            [Button.inline("🏠 返回主页", b"home")],
        ]
    )
    if edit:
        await event.edit(text, buttons=buttons, parse_mode="html")
    else:
        await event.respond(text, buttons=buttons, parse_mode="html")


async def render_account_detail(event, account_db_id: int) -> None:
    row = get_account(account_db_id, event.sender_id)
    if not row:
        await event.answer("账号不存在", alert=True)
        await render_accounts(event, edit=True)
        return
    username = f"@{row['username']}" if row["username"] else "未设置"
    phone = f"+{row['phone']}" if row["phone"] else "未显示"
    text = (
        "📱 <b>账号详细信息</b>\n\n"
        f"📛 昵称：{escape(row['display_name'] or '未设置')}\n"
        f"🔗 用户名：{escape(username)}\n"
        f"🆔 账号 ID：<code>{row['telegram_id']}</code>\n"
        f"📱 手机号：{escape(phone)}\n"
        f"🧧 抢红包：{'✅ 已开启' if is_running(account_db_id) else '❌ 已关闭'}\n"
        f"🔔 红包通知：{'✅ 已开启' if row['notify_enabled'] else '❌ 已关闭'}\n"
        f"⏱ 点击延迟：{format_click_delay(row)}"
    )
    try:
        await event.edit(
            text,
            buttons=[
                [Button.inline("💰 金额阈值", f"rules:{account_db_id}".encode())],
                [
                    Button.inline(
                        f"⏱ 点击延迟 {format_click_delay(row)}",
                        f"delay:{account_db_id}".encode(),
                    )
                ],
                [
                    Button.inline(
                        "🚫 屏蔽红包机器人",
                        f"blocked_bots:{account_db_id}".encode(),
                    )
                ],
                [
                    Button.inline(
                        "📥 当前账号加入群",
                        f"join_group:account:{account_db_id}".encode(),
                    )
                ],
                [
                    Button.inline(
                        (
                            "📦 红包个数大于金额不抢 ✅"
                            if row["skip_count_gt_amount"]
                            else "📦 红包个数大于金额不抢 ❌"
                        ),
                        f"count_rule:{account_db_id}".encode(),
                    )
                ],
                [
                    Button.inline(
                        "🔄 同步个数规则到其他账号",
                        f"sync_count_rule:{account_db_id}".encode(),
                    )
                ],
                [Button.inline("⬅️ 返回账号列表", b"account")],
            ],
            parse_mode="html",
        )
    except MessageNotModifiedError:
        pass


async def render_blocked_bots(event, account_db_id: int) -> None:
    row = get_account(account_db_id, event.sender_id)
    if not row:
        await event.answer("账号不存在", alert=True)
        await render_accounts(event, edit=True)
        return
    blocked = account_blocked_bots(account_db_id)
    buttons = [
        [
            Button.inline(
                f"@{username} {'❌ 已屏蔽' if username in blocked else '✅ 允许'}",
                f"toggle_bot:{account_db_id}:{username}".encode(),
            )
        ]
        for username in BLOCKABLE_BOTS
    ]
    buttons.append(
        [
            Button.inline(
                "⬅️ 返回账号详情",
                f"detail:{account_db_id}".encode(),
            )
        ]
    )
    await event.edit(
        "🚫 <b>屏蔽红包机器人</b>\n\n"
        "设置只对当前账号生效。\n"
        "已屏蔽的机器人红包将静默跳过，不点击、不汇总。",
        buttons=buttons,
        parse_mode="html",
    )


def rule_targets(uid: int, target: str) -> list[int]:
    if target == "all":
        return [
            row["id"]
            for row in db.execute(
                "SELECT id FROM accounts WHERE owner_id=?", (uid,)
            ).fetchall()
        ]
    account_db_id = int(target)
    return [account_db_id] if get_account(account_db_id, uid) else []


async def render_rules(event, target: str) -> None:
    targets = rule_targets(event.sender_id, target)
    if not targets:
        await event.answer("没有可配置的账号", alert=True)
        await render_accounts(event, edit=True)
        return
    account = get_account(targets[0], event.sender_id)
    label = (
        f"+{account['phone']}"
        if account and account["phone"]
        else str(account["telegram_id"])
    )
    description = (
        f"当前账号：{escape(label)}"
        if target != "all"
        else f"当前范围：我的全部账号（{len(targets)} 个）"
    )
    threshold_rows = db.execute(
        """
        SELECT currency, minimum FROM account_thresholds
        WHERE account_id=?
        """,
        (targets[0],),
    ).fetchall()
    values = {row["currency"]: row["minimum"] for row in threshold_rows}
    enabled = all(threshold_enabled(account_id) for account_id in targets)
    lines = [
        "💰 <b>金额阈值设置</b>",
        "",
        description,
        f"当前状态：{'✅ 已开启' if enabled else '❌ 已关闭'}",
        "开启后，低于对应金额阈值的红包将不抢。",
        "关闭后，当前账号不会按金额阈值过滤。",
        "",
    ]
    for currency in SUPPORTED_CURRENCIES:
        lines.append(f"{currency}：{values.get(currency, '不限')}")
    buttons = [
        [
            Button.inline(
                "❌ 关闭金额阈值" if enabled else "✅ 开启金额阈值",
                f"toggle_threshold:{target}".encode(),
            ),
        ],
        [
            Button.inline("✏️ 修改金额阈值", f"edit_rules:{target}".encode()),
        ],
        [
            Button.inline(
                "🔧 同步到我的其他账号",
                f"sync_rules:{target}".encode(),
            )
        ],
        [
            Button.inline(
                "⬅️ 返回账号详情",
                f"detail:{target}".encode(),
            )
        ],
    ]
    try:
        await event.edit(
            "\n".join(lines),
            buttons=buttons,
            parse_mode="html",
        )
    except MessageNotModifiedError:
        pass

async def render_status(event, *, edit: bool = False) -> None:
    uid = event.sender_id
    total = account_count(uid)
    running = db.execute(
        "SELECT id FROM accounts WHERE owner_id=?", (uid,)
    ).fetchall()
    row = db.execute(
        "SELECT created_at, success, chat_name, amount, currency, reason "
        "FROM claim_logs WHERE user_id=? ORDER BY id DESC LIMIT 1",
        (uid,),
    ).fetchone()
    last = "暂无记录"
    if row:
        icon = "✅" if row["success"] else "❌"
        last = (
            f"{icon} {row['created_at']}｜{row['chat_name'] or '未知群组'}｜"
            f"{row['amount'] or '0'} {row['currency'] or ''}｜{row['reason']}"
        )
    text = (
        "📊 <b>运行状态</b>\n\n"
        f"🔐 已登录账号：{total} 个\n"
        f"📡 正在抢红包：{sum(is_running(row['id']) for row in running)} 个\n\n"
        f"🕘 最近结果：\n{escape(last)}"
    )
    buttons = [[Button.inline("🏠 返回主页", b"home")]]
    if edit:
        await event.edit(text, buttons=buttons, parse_mode="html")
    else:
        await event.respond(text, buttons=buttons, parse_mode="html")


async def render_history(event, *, edit: bool = False) -> None:
    rows = db.execute(
        """
        SELECT created_at, success, clicked, chat_name, amount, currency, reason
        FROM claim_logs WHERE user_id=? ORDER BY id DESC LIMIT 8
        """,
        (event.sender_id,),
    ).fetchall()
    lines = ["🧾 <b>最近处理记录</b>", ""]
    if not rows:
        lines.append("暂无领取记录。")
    for row in rows:
        icon = "✅" if row["success"] else "❌"
        lines.append(
            f"{icon} {escape(row['created_at'])}\n"
            f"🏘 {escape(row['chat_name'] or '未知群组')}\n"
            f"💰 {escape(row['amount'] or '0')} {escape(row['currency'] or '')}\n"
            f"📝 {escape(row['reason'] or '')}"
        )
    text = "\n\n".join(lines)
    buttons = [[Button.inline("🏠 返回主页", b"home")]]
    if edit:
        await event.edit(text, buttons=buttons, parse_mode="html")
    else:
        await event.respond(text, buttons=buttons, parse_mode="html")


EMOJI_LABEL_CHOICES = (
    ["+", "-", "*", "/", "="]
    + [str(value) for value in range(10)]
    + list("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
)


def _emoji_label_buttons(document_id: int) -> list[list[Button]]:
    rows: list[list[Button]] = []
    current: list[Button] = []
    for label in EMOJI_LABEL_CHOICES:
        current.append(
            Button.inline(label, f"emoji_label:{document_id}:{label}".encode())
        )
        if len(current) == 5:
            rows.append(current)
            current = []
    if current:
        rows.append(current)
    rows.append([Button.inline("⬅️ 返回表情管理", b"emoji_admin")])
    return rows


def _format_unknown_emoji_record(row: dict[str, Any]) -> str:
    labels = row.get("labels") or []
    document_ids = row.get("document_ids") or []
    context = " ".join(str(label if label is not None else "?") for label in labels) or "未知"
    try:
        position = document_ids.index(int(row["document_id"])) + 1
    except Exception:
        position = 0
    suffix = f"｜第 {position} 个" if position else ""
    return (
        f"<code>{escape(str(row['document_id']))}</code>{suffix}\n"
        f"🧩 识别：<code>{escape(context)}</code>\n"
        f"🔁 次数：{int(row.get('count') or 0)}｜🕒 {escape(str(row.get('updated_at') or ''))}"
    )


async def render_emoji_admin(event, *, edit: bool = False) -> None:
    if event.sender_id != ADMIN_ID:
        await event.respond("无权限")
        return
    rows = list_unknown_emoji_records(10)
    lines = [
        "🧠 <b>表情识别管理</b>",
        "",
        "这里显示最近没识别出来的自定义 Emoji。",
        "点进去后，按它实际代表的符号/数字/字母标记一次，以后会直接走缓存。",
    ]
    buttons: list[list[Button]] = []
    if not rows:
        lines.extend(["", "暂无未识别表情。"])
    else:
        for index, row in enumerate(rows, 1):
            lines.extend(["", f"<b>#{index}</b> " + _format_unknown_emoji_record(row)])
            if row.get("message_url"):
                lines.append(f'🔎 <a href="{escape(str(row["message_url"]), quote=True)}">点击查看原红包</a>')
            buttons.append([
                Button.inline(
                    f"🧩 标记 #{index}",
                    f"emoji_record:{row['document_id']}".encode(),
                )
            ])
    buttons.append([Button.inline("🔄 刷新", b"emoji_admin")])
    buttons.append([Button.inline("⬅️ 返回管理员", b"admin")])
    sender = event.edit if edit else event.respond
    await sender(
        "\n".join(lines),
        buttons=buttons,
        parse_mode="html",
        link_preview=False,
    )


async def _build_emoji_question_image(row: dict[str, Any]) -> io.BytesIO | None:
    document_ids = [int(value) for value in (row.get("document_ids") or [])]
    if not document_ids:
        return None
    try:
        from PIL import Image, ImageDraw, ImageFont
    except Exception:
        return None
    try:
        documents = await bot(
            GetCustomEmojiDocumentsRequest(document_id=sorted(set(document_ids)))
        )
    except Exception:
        logger.exception("读取自定义 Emoji 文档失败：%s", document_ids)
        return None
    document_map = {int(document.id): document for document in documents}
    labels = row.get("labels") or []
    buttons = [str(value) for value in (row.get("buttons") or []) if str(value).strip()]

    tile = 112
    pad = 16
    label_h = 28
    button_h = 34 if buttons else 0
    count = max(1, len(document_ids))
    width = pad * 2 + tile * count
    height = pad * 2 + tile + label_h + button_h
    canvas = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(canvas)
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 18)
        small_font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 15)
    except Exception:
        font = ImageFont.load_default()
        small_font = font

    for index, doc_id in enumerate(document_ids):
        x = pad + index * tile
        y = pad
        draw.rounded_rectangle([x, y, x + tile - 10, y + tile - 10], radius=10, outline=(210, 210, 210), width=2)
        content = None
        document = document_map.get(doc_id)
        if document is not None:
            try:
                content = await bot.download_media(document, file=bytes)
            except Exception:
                try:
                    content = await bot.download_media(document, file=bytes, thumb=-1)
                except Exception:
                    content = None
        if content:
            try:
                image = Image.open(io.BytesIO(content)).convert("RGBA")
                image.thumbnail((tile - 24, tile - 24))
                ix = x + (tile - 10 - image.width) // 2
                iy = y + (tile - 10 - image.height) // 2
                canvas.paste(image, (ix, iy), image)
            except Exception:
                draw.text((x + 28, y + 38), "?", fill=(0, 0, 0), font=font)
        else:
            draw.text((x + 28, y + 38), "?", fill=(0, 0, 0), font=font)
        label = labels[index] if index < len(labels) else None
        label_text = str(label if label is not None else "?")
        draw.text((x + 8, y + tile - 2), label_text, fill=(0, 0, 0), font=font)

    if buttons:
        button_text = "候选答案: " + " / ".join(buttons[:8])
        draw.text((pad, height - button_h + 6), button_text, fill=(30, 30, 30), font=small_font)

    output = io.BytesIO()
    output.name = "emoji_question.png"
    canvas.save(output, format="PNG")
    output.seek(0)
    return output


def _emoji_question_caption(row: dict[str, Any]) -> str:
    labels = row.get("labels") or []
    buttons = [str(value) for value in (row.get("buttons") or []) if str(value).strip()]
    context = " ".join(str(label if label is not None else "?") for label in labels) or "未知"
    lines = [
        "🧩 <b>完整表情题目</b>",
        "",
        f"当前识别：<code>{escape(context)}</code>",
    ]
    if buttons:
        lines.append(f"候选答案：<code>{escape(' / '.join(buttons))}</code>")
    lines.append(f"出现次数：{int(row.get('count') or 0)}")
    if row.get("message_url"):
        lines.append(f'🔎 <a href="{escape(str(row["message_url"]), quote=True)}">点击查看原红包</a>')
    lines.extend(["", "看图片后，点击下面按钮标记当前未知表情。"])
    return "\n".join(lines)


async def render_emoji_record(event, document_id: int) -> None:
    if event.sender_id != ADMIN_ID:
        await event.answer("无权限", alert=True)
        return
    row = get_unknown_emoji_record(document_id)
    if not row:
        await event.answer("这条未知表情记录已不存在", alert=True)
        await render_emoji_admin(event, edit=True)
        return
    image = await _build_emoji_question_image(row)
    buttons = _emoji_label_buttons(document_id)
    caption = _emoji_question_caption(row)
    if image is not None:
        await event.answer("已发送完整题目图片")
        await bot.send_file(
            event.chat_id,
            image,
            caption=caption,
            buttons=buttons,
            parse_mode="html",
            link_preview=False,
        )
        return
    lines = [
        "🧩 <b>标记未知表情</b>",
        "",
        _format_unknown_emoji_record(row),
        "",
        "图片生成失败，请先按当前记录标记。标记后立即写入缓存，下次自动生效。",
    ]
    if row.get("message_url"):
        lines.append(f'🔎 <a href="{escape(str(row["message_url"]), quote=True)}">点击查看原红包</a>')
    await event.edit(
        "\n".join(lines),
        buttons=buttons,
        parse_mode="html",
        link_preview=False,
    )


async def render_admin(event, *, edit: bool = False) -> None:
    user_count = db.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    auth_count = db.execute(
        "SELECT COUNT(*) FROM users WHERE is_auth=1 AND id<>?",
        (ADMIN_ID,),
    ).fetchone()[0]
    session_count = db.execute(
        "SELECT COUNT(*) FROM accounts"
    ).fetchone()[0]
    success_count = db.execute(
        "SELECT COUNT(*) FROM claim_logs WHERE success=1"
    ).fetchone()[0]
    failure_count = db.execute(
        "SELECT COUNT(*) FROM claim_logs WHERE success=0"
    ).fetchone()[0]
    text = (
        "🛠 <b>管理员中心</b>\n\n"
        f"👥 已访问用户：<b>{user_count}</b>\n"
        f"🔓 已授权用户：<b>{auth_count + 1}</b>（含管理员）\n"
        f"🔐 已登录账号：<b>{session_count}</b>\n"
        f"📡 在线任务：<b>{sum(is_running(account_id) for account_id in active_workers)}</b>\n"
        f"✅ 成功/已提交：<b>{success_count}</b>\n"
        f"❌ 失败/已跳过：<b>{failure_count}</b>\n\n"
        "授权命令：\n"
        "<code>/auth 用户ID</code>\n"
        "<code>/unauth 用户ID</code>"
    )
    buttons = [
        [Button.inline("👥 用户列表", b"users")],
        [Button.inline("📅 每日日报", b"daily_report")],
        [Button.inline("🧠 表情识别管理", b"emoji_admin")],
        [Button.inline("📥 批量加入群", b"join_group:admin_all")],
        [Button.inline("🏠 返回主页", b"home")],
    ]
    if edit:
        await event.edit(text, buttons=buttons, parse_mode="html")
    else:
        await event.respond(text, buttons=buttons, parse_mode="html")


async def render_users(event) -> None:
    rows = db.execute(
        """
        SELECT id, username, display_name, is_auth, first_seen, updated_at,
               (SELECT COUNT(*) FROM accounts WHERE owner_id=users.id) account_count
        FROM users ORDER BY updated_at DESC LIMIT 20
        """
    ).fetchall()
    lines = ["👥 <b>用户列表（最近 20 位）</b>", ""]
    for row in rows:
        auth = "🔓" if is_authorized(row["id"]) else "🔒"
        login = f"📱{row['account_count']}"
        identity = row["username"] or row["display_name"] or "未命名"
        lines.append(
            f"{auth} {login} {escape(identity)}\n"
            f"🆔 <code>{row['id']}</code>\n"
            f"🕐 首次：{escape(row['first_seen'] or '未知')}\n"
            f"🕒 最近：{escape(row['updated_at'] or '未知')}"
        )
    await event.edit(
        "\n\n".join(lines),
        buttons=[
            [Button.inline("📋 最近操作记录", b"activity_logs")],
            [Button.inline("⬅️ 返回管理中心", b"admin")],
        ],
        parse_mode="html",
    )


async def _disconnect_login_client(state: dict) -> None:
    client = state.get("client")
    if client and client.is_connected():
        await client.disconnect()


async def _save_login(uid: int, state: dict) -> None:
    client = state["client"]
    session = client.session.save()
    me = await client.get_me()
    if me:
        save_account_profile(uid, session, me)


async def begin_login(event, *, edit: bool = False) -> None:
    uid = event.sender_id
    old_state = login_states.pop(uid, None)
    if old_state:
        await _disconnect_login_client(old_state)
    login_states[uid] = {"step": "phone", "processing": False}
    text = (
        "📱 <b>登录 Telegram 账号</b>\n\n"
        "请输入完整手机号（包含国家区号）：\n"
        "例如：<code>+8613812345678</code>\n\n"
        "发送 /cancel 可以取消登录。"
    )
    buttons = [[Button.inline("⬅️ 返回账号列表", b"cancel_login")]]
    if edit:
        await event.edit(text, buttons=buttons, parse_mode="html")
    else:
        await event.respond(text, buttons=buttons, parse_mode="html")


async def start_account_worker(uid: int, account_db_id: int) -> tuple[bool, str]:
    account = get_account(account_db_id, uid)
    if not account:
        return False, "账号不存在。"
    existing = active_workers.get(account_db_id)
    if existing and not existing.task.done():
        return False, "该账号正在抢红包。"
    db.execute(
        "UPDATE accounts SET claim_enabled=1, updated_at=? WHERE id=?",
        (datetime.now().isoformat(timespec="seconds"), account_db_id),
    )
    db.commit()
    task = asyncio.create_task(
        start_worker(uid, account_db_id, account["session"]),
        name=f"worker-{uid}-{account_db_id}",
    )
    active_workers[account_db_id] = Worker(
        task=task,
        owner_id=uid,
        account_db_id=account_db_id,
    )
    return True, "该账号已开启抢红包。"


async def recover_telegram_update_stream(reason: str, error_count: int) -> None:
    """Notify admin and softly reconnect active listener accounts.

    Telethon update-difference errors are usually server-side/transient.  A
    reconnect is intentionally rate-limited by note_telegram_update_error().
    """

    workers = [
        (account_db_id, worker.owner_id, worker.account_name or str(account_db_id))
        for account_db_id, worker in list(active_workers.items())
        if not worker.task.done()
    ]
    if not workers:
        try:
            await bot.send_message(
                ADMIN_ID,
                "⚠️ <b>Telegram 更新异常</b>\n\n"
                f"90秒内异常次数：{error_count}\n"
                "当前没有在线抢红包账号，无需自动重连。\n\n"
                f"最近错误：<code>{escape(reason[:300])}</code>",
                parse_mode="html",
            )
        except Exception:
            logger.exception("发送 Telegram 更新异常通知失败")
        return

    try:
        await bot.send_message(
            ADMIN_ID,
            "⚠️ <b>Telegram 更新异常，正在自动恢复</b>\n\n"
            f"90秒内异常次数：{error_count}\n"
            f"在线账号：{len(workers)} 个\n"
            "我会分批重连在线抢红包账号，降低漏消息概率。\n\n"
            f"最近错误：<code>{escape(reason[:300])}</code>",
            parse_mode="html",
        )
    except Exception:
        logger.exception("发送 Telegram 更新异常通知失败")

    restarted = 0
    failed: list[str] = []
    for account_db_id, owner_id, label in workers:
        try:
            await stop_account_worker(owner_id, account_db_id, persist=False)
            await asyncio.sleep(2)
            ok, message = await start_account_worker(owner_id, account_db_id)
            if ok:
                restarted += 1
            else:
                failed.append(f"{label}: {message}")
            await asyncio.sleep(3)
        except Exception as exc:
            logger.exception("自动重连监听账号失败：account=%s", account_db_id)
            failed.append(f"{label}: {exc}")

    try:
        text = (
            "✅ <b>Telegram 更新异常恢复完成</b>\n\n"
            f"已重连：{restarted}/{len(workers)} 个账号"
        )
        if failed:
            text += "\n\n失败明细：\n" + "\n".join(
                f"- {escape(item[:120])}" for item in failed[:8]
            )
        await bot.send_message(ADMIN_ID, text, parse_mode="html")
    except Exception:
        logger.exception("发送 Telegram 更新恢复完成通知失败")


def schedule_telegram_update_recovery(reason: str, error_count: int) -> None:
    global _telegram_update_recovery_task
    if _telegram_update_recovery_task and not _telegram_update_recovery_task.done():
        return
    _telegram_update_recovery_task = asyncio.create_task(
        recover_telegram_update_stream(reason, error_count)
    )


async def notify_telegram_update_alert(reason: str, error_count: int) -> None:
    workers = [
        worker for worker in active_workers.values()
        if not worker.task.done()
    ]
    try:
        await bot.send_message(
            ADMIN_ID,
            "⚠️ <b>Telegram 更新异常提醒</b>\n\n"
            f"{TG_UPDATE_ERROR_WINDOW_SECONDS}秒内异常次数：{error_count}\n"
            f"在线账号：{len(workers)} 个\n"
            "已切换为保守模式：只提醒，不自动批量重连账号。\n"
            "如果连续漏消息，再手动重启服务或减少监听账号/群数量。\n\n"
            f"最近错误：<code>{escape(reason[:300])}</code>",
            parse_mode="html",
        )
    except Exception:
        logger.exception("发送 Telegram 更新异常提醒失败")


def schedule_telegram_update_alert(reason: str, error_count: int) -> None:
    global _telegram_update_recovery_task
    if _telegram_update_recovery_task and not _telegram_update_recovery_task.done():
        return
    _telegram_update_recovery_task = asyncio.create_task(
        notify_telegram_update_alert(reason, error_count)
    )


def note_telegram_update_error(message: str) -> None:
    global _telegram_update_error_last_message, _telegram_update_recovery_last_at
    now_ts = monotonic()
    _telegram_update_error_last_message = message
    _telegram_update_error_times.append(now_ts)
    while (
        _telegram_update_error_times
        and now_ts - _telegram_update_error_times[0] > TG_UPDATE_ERROR_WINDOW_SECONDS
    ):
        _telegram_update_error_times.popleft()
    error_count = len(_telegram_update_error_times)
    if error_count < TG_UPDATE_ERROR_THRESHOLD:
        return
    if now_ts - _telegram_update_recovery_last_at < TG_UPDATE_RECOVERY_COOLDOWN_SECONDS:
        return
    _telegram_update_recovery_last_at = now_ts
    logger.warning(
        "Telegram 更新异常达到阈值：count=%s window=%ss message=%s",
        error_count,
        TG_UPDATE_ERROR_WINDOW_SECONDS,
        message,
    )
    try:
        loop = bot.loop
        if not loop.is_running():
            return
        if TG_UPDATE_AUTO_RECOVER_ENABLED:
            loop.call_soon_threadsafe(
                schedule_telegram_update_recovery,
                message,
                error_count,
            )
        else:
            loop.call_soon_threadsafe(
                schedule_telegram_update_alert,
                message,
                error_count,
            )
    except Exception:
        logger.exception("安排 Telegram 更新异常提醒/恢复任务失败")


class TelethonUpdateErrorLogHandler(logging.Handler):
    def emit(self, record: logging.LogRecord) -> None:
        try:
            if not record.name.startswith("telethon"):
                return
            message = record.getMessage()
            if any(keyword in message for keyword in TELETHON_UPDATE_IGNORE_KEYWORDS):
                return
            if any(keyword in message for keyword in TELETHON_UPDATE_ERROR_KEYWORDS):
                note_telegram_update_error(message)
        except Exception:
            pass


def install_telethon_update_error_monitor() -> None:
    global _telethon_update_log_handler_installed
    if _telethon_update_log_handler_installed:
        return
    logging.getLogger("telethon").addHandler(TelethonUpdateErrorLogHandler(level=logging.WARNING))
    _telethon_update_log_handler_installed = True


async def stop_account_worker(
    uid: int,
    account_db_id: int,
    *,
    persist: bool = True,
) -> tuple[bool, str]:
    if not get_account(account_db_id, uid):
        return False, "账号不存在。"
    worker = active_workers.get(account_db_id)
    if not worker or worker.task.done():
        active_workers.pop(account_db_id, None)
        if persist:
            db.execute(
                "UPDATE accounts SET claim_enabled=0, updated_at=? WHERE id=?",
                (datetime.now().isoformat(timespec="seconds"), account_db_id),
            )
            db.commit()
        return False, "该账号没有开启抢红包。"
    if worker.client and worker.client.is_connected():
        await worker.client.disconnect()
    try:
        await asyncio.wait_for(worker.task, timeout=10)
    except asyncio.TimeoutError:
        worker.task.cancel()
    active_workers.pop(account_db_id, None)
    if persist:
        db.execute(
            "UPDATE accounts SET claim_enabled=0, updated_at=? WHERE id=?",
            (datetime.now().isoformat(timespec="seconds"), account_db_id),
        )
        db.commit()
    return True, "该账号已关闭抢红包。"


def save_claim_log(uid: int, account_db_id: int, result: dict) -> None:
    db.execute(
        """
        INSERT INTO claim_logs (
            user_id, created_at, success, clicked, chat_id, chat_name,
            amount, currency, reason, message_url, account_ref,
            manual_required
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            uid,
            datetime.now(REPORT_TZ).strftime("%Y-%m-%d %H:%M:%S"),
            int(bool(result.get("success"))),
            int(bool(result.get("clicked"))),
            result.get("chat_id"),
            result.get("chat_name"),
            result.get("amount"),
            result.get("currency"),
            result.get("reason"),
            result.get("url"),
            account_db_id,
            int(bool(result.get("manual_required"))),
        ),
    )
    db.commit()


def claim_bot_link_html(result: dict) -> str:
    username = str(result.get("bot_username") or "").strip().lstrip("@")
    url = str(result.get("bot_url") or "").strip()
    if not username and "t.me/" in url:
        username = url.rstrip("/").rsplit("/", 1)[-1].lstrip("@")
    if not username:
        return ""
    if not url:
        url = f"https://t.me/{username}"
    return f'🤖 机器人：<a href="{escape(url, quote=True)}">@{escape(username)}</a>'


def is_transient_telegram_error(exc: Exception) -> bool:
    text = str(exc)
    return isinstance(exc, FloodWaitError) or any(
        marker in text
        for marker in (
            "Request was unsuccessful",
            "GetUsersRequest",
            "GetChannelsRequest",
            "Could not find the input entity",
            "The channel specified is private",
            "lack permission",
            "Invalid channel object",
            "timed out",
            "TimeoutError",
        )
    )


def should_save_silent_result(result: dict) -> bool:
    reason = str(result.get("reason") or "")
    return any(
        marker in reason
        for marker in (
            "低于阈值",
            "账号已开启只抢指定群",
            "红包包数",
            "静默群组已过滤",
            "静默群名已过滤",
        )
    )


async def send_claim_feedback(
    uid: int, account_db_id: int, result: dict
) -> None:
    account = get_account(account_db_id, uid)
    account_label = (
        account["display_name"] if account and account["display_name"]
        else f"@{account['username']}" if account and account["username"]
        else str(account["telegram_id"]) if account
        else "未知账号"
    )
    success = bool(result.get("success"))
    chat_name = escape(str(result.get("chat_name") or "未知群组"))
    if result.get("manual_required"):
        outcome = (
            "⚠️ <b>需要手动验证</b>\n"
            f"💬 {escape(str(result.get('reason') or '请打开领取页面完成验证'))}"
        )
    elif success:
        outcome = (
            "✅ <b>领取成功</b>\n"
            f"💬 {escape(str(result.get('reason') or '领取成功'))}"
        )
    else:
        outcome = (
            "❌ <b>领取失败</b>\n"
            f"💬 {escape(str(result.get('reason') or '未知原因'))}"
        )
    processed_at = datetime.now(REPORT_TZ).strftime("%Y-%m-%d %H:%M:%S")
    text = (
        f"🧧 账号 <b>{escape(account_label)}</b> 在 "
        f"<b>{chat_name}</b> 尝试领取红包\n\n"
        f"{outcome}"
    )
    url = result.get("message_url") or result.get("url")
    if url and url != "未知":
        safe_url = escape(str(url), quote=True)
        text += f'\n\n🔎 <a href="{safe_url}">点击查看</a>　🕒 {processed_at}'
    else:
        text += f"\n\n🕒 {processed_at}"
    if success:
        bot_link = claim_bot_link_html(result)
        if bot_link:
            text += f"\n{bot_link}"
    await bot.send_message(
        uid,
        text,
        parse_mode="html",
        link_preview=False,
    )


async def process_account_message(
    uid: int,
    account_db_id: int,
    event,
) -> dict:
    loop_now = asyncio.get_running_loop().time()
    cooldown_until = _account_transient_error_cooldown_until.get(account_db_id, 0)
    if cooldown_until > loop_now:
        return {
            "success": False,
            "clicked": False,
            "notify": False,
            "amount": "0.00",
            "currency": "",
            "reason": f"账号临时解析冷却中，剩余 {int(cooldown_until - loop_now)} 秒",
            "chat_id": getattr(event, "chat_id", None),
            "chat_name": str(getattr(event, "chat_id", None) or "未知群组"),
            "url": "未知",
            "manual_required": False,
            "processed_at": datetime.now(REPORT_TZ).strftime("%H:%M:%S"),
        }
    account = get_account(account_db_id, uid)
    chat_id = getattr(event, "chat_id", None)
    chat_name = str(chat_id or "未知群组")
    try:
        chat = await event.get_chat()
        chat_id = getattr(event, "chat_id", None) or getattr(chat, "id", None)
        chat_name = (
            getattr(chat, "title", None)
            or getattr(chat, "username", None)
            or str(chat_id or "未知群组")
        )
    except Exception as exc:
        if is_transient_telegram_error(exc):
            _account_transient_error_cooldown_until[account_db_id] = (
                asyncio.get_running_loop().time() + ACCOUNT_TRANSIENT_ERROR_COOLDOWN_SECONDS
            )
            logger.warning(
                "账号临时解析异常，进入冷却：user=%s account=%s cooldown=%ss error=%s",
                uid,
                account_db_id,
                ACCOUNT_TRANSIENT_ERROR_COOLDOWN_SECONDS,
                exc,
            )
            return {
                "success": False,
                "clicked": False,
                "notify": False,
                "amount": "0.00",
                "currency": "",
                "reason": f"账号临时解析异常，已冷却 {ACCOUNT_TRANSIENT_ERROR_COOLDOWN_SECONDS} 秒：{exc}",
                "chat_id": chat_id,
                "chat_name": chat_name,
                "url": "未知",
                "manual_required": False,
                "processed_at": datetime.now(REPORT_TZ).strftime("%H:%M:%S"),
            }
        pass
    if chat_id is not None:
        try:
            remember_account_chat(account_db_id, int(chat_id), chat_name)
        except Exception:
            logger.debug(
                "记录账号最近群失败：account=%s chat=%s",
                account_db_id,
                chat_id,
                exc_info=True,
            )
        if account and account["allowed_chats_enabled"]:
            allowed_ids = account_allowed_chat_ids(account_db_id)
            if int(chat_id) not in allowed_ids:
                return {
                    "success": False,
                    "clicked": False,
                    "notify": False,
                    "amount": "0.00",
                    "currency": "",
                    "reason": "账号已开启只抢指定群，该群不在允许列表",
                    "chat_id": int(chat_id),
                    "chat_name": chat_name,
                    "url": "未知",
                    "manual_required": False,
                    "processed_at": datetime.now(REPORT_TZ).strftime("%H:%M:%S"),
                }
    try:
        result = await handle_message(
            event,
            attempt_scope=account_db_id,
            thresholds_override=account_thresholds(account_db_id),
            skip_count_gt_amount=bool(
                account and account["skip_count_gt_amount"]
            ),
            click_delay=float(account["click_delay"] or 0) if account else 0,
            click_delay_max=float(account["click_delay_max"] or account["click_delay"] or 0) if account else 0,
            blocked_bots=account_blocked_bots(account_db_id),
        )
    except Exception as exc:
        if is_transient_telegram_error(exc):
            _account_transient_error_cooldown_until[account_db_id] = (
                asyncio.get_running_loop().time() + ACCOUNT_TRANSIENT_ERROR_COOLDOWN_SECONDS
            )
            logger.warning(
                "账号处理消息临时异常，进入冷却：user=%s account=%s cooldown=%ss error=%s",
                uid,
                account_db_id,
                ACCOUNT_TRANSIENT_ERROR_COOLDOWN_SECONDS,
                exc,
            )
            return {
                "success": False,
                "clicked": False,
                "notify": False,
                "amount": "0.00",
                "currency": "",
                "reason": f"账号处理消息临时异常，已冷却 {ACCOUNT_TRANSIENT_ERROR_COOLDOWN_SECONDS} 秒：{exc}",
                "chat_id": chat_id,
                "chat_name": chat_name,
                "url": "未知",
                "manual_required": False,
                "processed_at": datetime.now(REPORT_TZ).strftime("%H:%M:%S"),
            }
        raise
    result["processed_at"] = datetime.now(REPORT_TZ).strftime("%H:%M:%S")
    if result.get("notify"):
        logger.info(
            "用户 %s｜账号 %s｜群组 %s｜%s %s｜%s",
            uid,
            account_db_id,
            result.get("chat_name") or result.get("chat_id"),
            result.get("amount") or "0",
            result.get("currency") or "",
            result["reason"],
        )
        save_claim_log(uid, account_db_id, result)
        if uid != ADMIN_ID and notifications_enabled(account_db_id):
            try:
                await send_claim_feedback(uid, account_db_id, result)
            except Exception:
                logger.exception("发送领取反馈失败：user=%s", uid)
        record_admin_summary(account_db_id, result)
    else:
        if should_save_silent_result(result):
            save_claim_log(uid, account_db_id, result)
        logger.debug("用户 %s 账号 %s：%s", uid, account_db_id, result["reason"])
    return result


def account_summary_label(account_db_id: int) -> str:
    row = db.execute(
        "SELECT display_name, username, phone, telegram_id FROM accounts WHERE id=?",
        (account_db_id,),
    ).fetchone()
    if not row:
        return f"账号 {account_db_id}"
    return (
        row["display_name"]
        or (f"@{row['username']}" if row["username"] else None)
        or (f"+{row['phone']}" if row["phone"] else None)
        or str(row["telegram_id"])
    )


async def render_account_detail(event, account_db_id: int) -> None:
    row = get_account(account_db_id, event.sender_id)
    if not row:
        await event.answer("账号不存在", alert=True)
        await render_accounts(event, edit=True)
        return
    username = f"@{row['username']}" if row["username"] else "未设置"
    phone = f"+{row['phone']}" if row["phone"] else "未显示"
    text = (
        "📱 <b>账号详细信息</b>\n\n"
        f"📛 昵称：{escape(row['display_name'] or '未设置')}\n"
        f"🔗 用户名：{escape(username)}\n"
        f"🆔 账号 ID：<code>{row['telegram_id']}</code>\n"
        f"📞 手机号：{escape(phone)}\n"
        f"🧧 抢红包：{'✅ 已开启' if is_running(account_db_id) else '❌ 已关闭'}\n"
        f"🔔 红包通知：{'✅ 已开启' if row['notify_enabled'] else '❌ 已关闭'}\n"
        f"🏘 只抢指定群：{'✅ 已开启' if row['allowed_chats_enabled'] else '❌ 已关闭'}\n"
        f"⏱ 点击延迟：{format_click_delay(row)}"
    )
    buttons = [
        [Button.inline("💰 金额阈值", f"rules:{account_db_id}".encode())],
        [
            Button.inline(
                f"⏱ 点击延迟 {format_click_delay(row)}",
                f"delay:{account_db_id}".encode(),
            )
        ],
        [Button.inline("🚫 屏蔽红包机器人", f"blocked_bots:{account_db_id}".encode())],
        [
            Button.inline(
                f"🏘 只抢指定群 {'✅' if row['allowed_chats_enabled'] else '❌'}",
                f"allowed_chats:{account_db_id}".encode(),
            )
        ],
        [Button.inline("📥 当前账号加入群", f"join_group:account:{account_db_id}".encode())],
        [
            Button.inline(
                (
                    "📦 红包个数大于金额不抢 ✅"
                    if row["skip_count_gt_amount"]
                    else "📦 红包个数大于金额不抢 ❌"
                ),
                f"count_rule:{account_db_id}".encode(),
            )
        ],
        [Button.inline("🔄 同步个数规则到其他账号", f"sync_count_rule:{account_db_id}".encode())],
        [Button.inline("⬅️ 返回账号列表", b"account")],
    ]
    try:
        await event.edit(text, buttons=buttons, parse_mode="html")
    except MessageNotModifiedError:
        pass


async def render_allowed_chats(event, account_db_id: int) -> None:
    row = get_account(account_db_id, event.sender_id)
    if not row:
        await event.answer("账号不存在", alert=True)
        await render_accounts(event, edit=True)
        return
    enabled = bool(row["allowed_chats_enabled"])
    allowed_rows = account_allowed_chats(account_db_id)
    allowed_lines = []
    for item in allowed_rows:
        chat_id = int(item["chat_id"])
        name = str(item["chat_name"] or chat_id)
        allowed_lines.append(f"• <code>{chat_id}</code> {escape(name) if name != str(chat_id) else ''}".rstrip())
    allowed_text = "\n".join(allowed_lines) if allowed_lines else "暂未添加允许群。"
    text = (
        "🏘 <b>只抢指定群</b>\n\n"
        f"当前状态：{'✅ 已开启' if enabled else '❌ 已关闭'}\n"
        f"已允许群数：<b>{len(allowed_rows)}</b>\n\n"
        "开启后，当前账号只会抢允许列表里的群；其它群会静默跳过。\n\n"
        "添加/删除方式：点击下方按钮后，直接发送群 ID。\n"
        "例如：<code>-1001234567890</code>；如果你只输入 <code>1001234567890</code>，我会自动补成 <code>-1001234567890</code>。\n\n"
        f"<b>当前允许群：</b>\n{allowed_text}"
    )
    buttons = [
        [
            Button.inline(
                "✅ 关闭只抢指定群" if enabled else "✅ 开启只抢指定群",
                f"toggle_allowed_chats:{account_db_id}".encode(),
            )
        ],
        [
            Button.inline("➕ 添加群 ID", f"add_allowed_chat:{account_db_id}".encode()),
            Button.inline("➖ 删除群 ID", f"remove_allowed_chat:{account_db_id}".encode()),
        ],
    ]
    if allowed_rows:
        buttons.append([
            Button.inline("🧹 清空允许群", f"clear_allowed_chats:{account_db_id}".encode())
        ])
    buttons.append([Button.inline("⬅️ 返回账号详情", f"detail:{account_db_id}".encode())])
    try:
        await event.edit(text, buttons=buttons, parse_mode="html")
    except MessageNotModifiedError:
        pass


def schedule_join_verification_watch(
    account_db_id: int,
    owner_id: int,
    raw_link: str,
) -> None:
    if JOIN_VERIFY_WATCH_SECONDS <= 0:
        return
    _join_verify_watches[account_db_id] = {
        "owner_id": owner_id,
        "raw_link": raw_link,
        "deadline": datetime.now().timestamp() + JOIN_VERIFY_WATCH_SECONDS,
        "notified": False,
    }


def _message_button_texts(event) -> list[str]:
    texts: list[str] = []
    for row in getattr(event, "buttons", None) or []:
        for button in row:
            text = getattr(button, "text", None)
            if text:
                texts.append(str(text))
    return texts


def _looks_like_join_verification(event) -> tuple[bool, str]:
    raw_text = str(getattr(event, "raw_text", "") or "")
    button_texts = _message_button_texts(event)
    haystack = "\n".join([raw_text, *button_texts]).lower()
    if any(keyword.lower() in haystack for keyword in JOIN_VERIFY_EXCLUDE_KEYWORDS):
        return False, ""
    matched = [
        keyword for keyword in JOIN_VERIFY_KEYWORDS
        if keyword.lower() in haystack
    ]
    if not matched:
        return False, ""
    # A bare /start button or text is too broad; require another verification hint.
    if matched == ["start"] and not any(
        keyword.lower() in haystack
        for keyword in ("bot", "机器人", "验证", "captcha", "verify", "入群", "进群")
    ):
        return False, ""
    reason = f"检测到验证关键词：{', '.join(matched[:3])}"
    if button_texts:
        reason += f"；按钮：{', '.join(button_texts[:4])}"
    return True, reason


async def maybe_notify_join_verification(
    uid: int,
    account_db_id: int,
    event,
) -> None:
    watch = _join_verify_watches.get(account_db_id)
    if not watch:
        return
    now = datetime.now().timestamp()
    if now > float(watch.get("deadline", 0)):
        _join_verify_watches.pop(account_db_id, None)
        return
    if watch.get("notified"):
        return
    matched, reason = _looks_like_join_verification(event)
    if not matched:
        return

    watch["notified"] = True
    try:
        chat = await event.get_chat()
        chat_name = (
            getattr(chat, "title", None)
            or getattr(chat, "username", None)
            or getattr(chat, "first_name", None)
            or "未知会话"
        )
    except Exception:
        chat_name = "未知会话"
    preview = str(getattr(event, "raw_text", "") or "").strip()
    if len(preview) > 300:
        preview = preview[:300] + "..."
    text = (
        "⚠️ <b>入群后疑似需要验证</b>\n\n"
        f"👤 账号：{escape(account_summary_label(account_db_id))}\n"
        f"🔗 群链接：<code>{escape(str(watch.get('raw_link') or ''))}</code>\n"
        f"💬 来源：{escape(str(chat_name))}\n"
        f"🧩 原因：{escape(reason)}\n\n"
        "请用对应 Telegram 账号手动完成验证。\n"
        "系统只做提醒，不会自动处理人机验证。"
    )
    if preview:
        text += f"\n\n<code>{escape(preview)}</code>"
    try:
        await bot.send_message(
            ADMIN_ID,
            text,
            parse_mode="html",
            link_preview=False,
        )
        log_activity(uid, "入群验证提醒", f"account={account_db_id} {reason}")
    except Exception:
        logger.exception("发送入群验证提醒失败：account=%s", account_db_id)


def _today_range() -> tuple[str, str]:
    now = datetime.now(REPORT_TZ)
    start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    end = now
    return (
        start.strftime("%Y-%m-%d %H:%M:%S"),
        end.strftime("%Y-%m-%d %H:%M:%S"),
    )


def _decimal_amount(value: object) -> Decimal:
    try:
        return Decimal(str(value or "0"))
    except (InvalidOperation, ValueError):
        return Decimal("0")


def _format_amount(value: Decimal) -> str:
    normalized = value.quantize(Decimal("0.0001")).normalize()
    return format(normalized, "f")


def _is_manual_required_log(row) -> bool:
    reason = str(row["reason"] or "")
    return bool(
        row["manual_required"]
        or "手动验证" in reason
        or "已触发领取链接" in reason
    )


def _parse_group_link(raw_link: str) -> tuple[str, str]:
    link = raw_link.strip()
    if not link:
        raise ValueError("群链接不能为空")
    invite_match = re.search(
        r"(?:https?://)?t\.me/(?:joinchat/|\+)([A-Za-z0-9_-]+)",
        link,
        re.IGNORECASE,
    )
    if invite_match:
        return "invite", invite_match.group(1)

    public_match = re.search(
        r"(?:https?://)?t\.me/([A-Za-z0-9_]{4,})(?:\?.*)?$",
        link,
        re.IGNORECASE,
    )
    if public_match:
        username = public_match.group(1)
        if username.lower() not in {"c", "s", "joinchat"}:
            return "public", username

    if re.fullmatch(r"@?[A-Za-z0-9_]{4,}", link):
        return "public", link.lstrip("@")

    raise ValueError(
        "请发送公开群用户名或邀请链接，例如 @group、https://t.me/group、https://t.me/+xxxx"
    )


def join_group_targets(uid: int, target: str) -> list[tuple[int, int]]:
    if target == "mine":
        return [
            (row["id"], row["owner_id"])
            for row in db.execute(
                "SELECT id, owner_id FROM accounts WHERE owner_id=? ORDER BY id",
                (uid,),
            ).fetchall()
        ]
    if target == "admin_all" and uid == ADMIN_ID:
        return [
            (row["id"], row["owner_id"])
            for row in db.execute(
                "SELECT id, owner_id FROM accounts ORDER BY owner_id, id"
            ).fetchall()
        ]
    if target.startswith("account:"):
        account_id = int(target.split(":", 1)[1])
        row = get_account(account_id, uid)
        return [(row["id"], row["owner_id"])] if row else []
    return []


async def _account_join_group(
    account_db_id: int,
    owner_id: int,
    raw_link: str,
) -> tuple[str, str]:
    account = get_account_by_id(account_db_id)
    if not account or account["owner_id"] != owner_id:
        return "❌", "账号不存在"

    kind, value = _parse_group_link(raw_link)
    worker = active_workers.get(account_db_id)
    client = worker.client if worker and worker.client else None
    temporary_client: TelegramClient | None = None
    try:
        if not client or not client.is_connected():
            temporary_client = TelegramClient(
                StringSession(account["session"]),
                API_ID,
                API_HASH,
                proxy=PROXY,
            )
            await temporary_client.connect()
            client = temporary_client
        if not await client.is_user_authorized():
            return "❌", "账号会话已失效，需要重新登录"

        if kind == "invite":
            await client(ImportChatInviteRequest(value))
        else:
            await client(JoinChannelRequest(value))
        schedule_join_verification_watch(account_db_id, owner_id, raw_link)
        return "✅", "加入成功；如果群内出现验证，请手动完成"
    except FloodWaitError as exc:
        return "⏳", f"触发等待限制，需要 {exc.seconds} 秒后再试"
    except Exception as exc:
        message = str(exc)
        class_name = exc.__class__.__name__
        if "already" in message.lower() or class_name == "UserAlreadyParticipantError":
            schedule_join_verification_watch(account_db_id, owner_id, raw_link)
            return "✅", "已经在群里"
        if "invite" in message.lower() and (
            "invalid" in message.lower() or "expired" in message.lower()
        ):
            return "❌", "邀请链接无效或已过期"
        if "private" in message.lower():
            return "❌", "无法加入该私有群或需要审核"
        logger.warning(
            "账号加群失败：account=%s link=%s error=%s",
            account_db_id,
            raw_link,
            exc,
        )
        return "❌", message or class_name
    finally:
        if temporary_client and temporary_client.is_connected():
            await temporary_client.disconnect()


async def run_join_group_queue(
    uid: int,
    target: str,
    raw_link: str,
) -> str:
    targets = join_group_targets(uid, target)
    if not targets:
        return "❌ 没有可操作的账号。"
    try:
        _parse_group_link(raw_link)
    except ValueError as exc:
        return f"❌ {escape(str(exc))}"

    lines = [
        "📥 <b>批量加入群结果</b>",
        "",
        f"🔗 群链接：<code>{escape(raw_link)}</code>",
        f"👥 账号数量：<b>{len(targets)}</b>",
        (
            "⏱ 执行方式：排队加入，随机间隔 "
            f"{JOIN_GROUP_DELAY_MIN:g}–{JOIN_GROUP_DELAY_MAX:g} 秒"
        ),
        "",
    ]
    for index, (account_db_id, owner_id) in enumerate(targets, start=1):
        if index > 1:
            delay = random.uniform(JOIN_GROUP_DELAY_MIN, JOIN_GROUP_DELAY_MAX)
            await asyncio.sleep(delay)
        icon, message = await _account_join_group(account_db_id, owner_id, raw_link)
        lines.append(
            f"{icon} {escape(account_summary_label(account_db_id))}："
            f"{escape(message)}"
        )
        if icon == "⏳":
            lines.append("已停止后续加群，请等待限制结束后再继续。")
            break

    lines.extend(
        [
            "",
            "⚠️ 如果加入后群内出现验证码、问答、滑块或网页验证，请用对应账号手动完成。",
        ]
    )
    log_activity(uid, "批量加入群", f"{target} {raw_link}")
    return "\n".join(lines)


def build_daily_report_text() -> str:
    start, end = _today_range()
    rows = db.execute(
        """
        SELECT id, created_at, user_id, success, clicked, chat_name, amount,
               currency, reason, message_url, account_ref, manual_required
        FROM claim_logs
        WHERE created_at>=? AND created_at<=?
        ORDER BY id ASC
        """,
        (start, end),
    ).fetchall()
    rows = [
        row for row in rows
        if "低于阈值" not in str(row["reason"] or "")
    ]

    account_stats: dict[int | str, dict] = {}
    currency_stats: dict[str, dict[str, object]] = {}
    success_packet_keys: set[str] = set()
    group_stats: dict[str, int] = {}
    total_clicked = total_success = total_manual = total_failed = 0
    total_skipped = 0

    for row in rows:
        key = row["account_ref"] or f"user:{row['user_id']}"
        stat = account_stats.setdefault(
            key,
            {
                "total": 0,
                "clicked": 0,
                "success": 0,
                "manual": 0,
                "failed": 0,
                "skipped": 0,
                "latest": "",
                "last_reason": "",
            },
        )
        stat["total"] += 1
        stat["latest"] = row["created_at"] or stat["latest"]
        stat["last_reason"] = row["reason"] or stat["last_reason"]

        clicked = bool(row["clicked"])
        success = bool(row["success"])
        manual = _is_manual_required_log(row)
        if clicked:
            stat["clicked"] += 1
            total_clicked += 1
        else:
            stat["skipped"] += 1
            total_skipped += 1
        if success:
            stat["success"] += 1
            total_success += 1
            currency = str(row["currency"] or "未知").upper()
            amount = _decimal_amount(row["amount"])
            packet_key = (
                str(row["message_url"] or "")
                or f"{row['chat_name']}:{row['amount']}:{row['currency']}:{row['created_at']}"
            )
            if packet_key not in success_packet_keys:
                success_packet_keys.add(packet_key)
                currency_stat = currency_stats.setdefault(
                    currency,
                    {"count": 0, "amount": Decimal("0")},
                )
                currency_stat["count"] = int(currency_stat["count"]) + 1
                currency_stat["amount"] = currency_stat["amount"] + amount
        elif manual:
            stat["manual"] += 1
            total_manual += 1
        elif clicked:
            stat["failed"] += 1
            total_failed += 1

        chat_name = str(row["chat_name"] or "未知群组")
        group_stats[chat_name] = group_stats.get(chat_name, 0) + 1

    date_label = datetime.now(REPORT_TZ).strftime("%Y-%m-%d")
    lines = [
        f"📅 <b>每日日报</b>｜{escape(date_label)}",
        "",
        f"📦 记录总数：<b>{len(rows)}</b>",
        f"🖱 尝试点击：<b>{total_clicked}</b>",
        f"🧧 成功红包：<b>{len(success_packet_keys)}</b>（按消息去重）",
        f"✅ 成功账号记录：<b>{total_success}</b>",
        f"⚠️ 手动验证：<b>{total_manual}</b>",
        f"❌ 失败：<b>{total_failed}</b>",
        f"⏭ 规则跳过：<b>{total_skipped}</b>",
        "",
        "💰 <b>成功红包面额汇总</b>",
    ]

    if currency_stats:
        for currency, stat in sorted(currency_stats.items()):
            lines.append(
                f"• {escape(currency)}：<b>{stat['count']}</b> 次，"
                f"合计 <b>{escape(_format_amount(stat['amount']))}</b>"
            )
    else:
        lines.append("• 暂无成功/已提交记录")

    lines.extend(["", "👤 <b>账号明细</b>"])
    if account_stats:
        for account_key, stat in account_stats.items():
            if isinstance(account_key, int):
                label = account_summary_label(account_key)
            else:
                label = str(account_key)
            latest_time = str(stat["latest"] or "")[-8:]
            lines.append(
                f"• <b>{escape(label)}</b>\n"
                f"  点击 {stat['clicked']}｜成功 {stat['success']}｜"
                f"手动 {stat['manual']}｜失败 {stat['failed']}｜"
                f"跳过 {stat['skipped']}"
                + (f"\n  最近处理：{escape(latest_time)}" if latest_time else "")
            )
    else:
        lines.append("• 暂无账号记录")

    if group_stats:
        lines.extend(["", "🏘 <b>活跃群组 Top 5</b>"])
        for chat_name, count in sorted(
            group_stats.items(), key=lambda item: item[1], reverse=True
        )[:5]:
            lines.append(f"• {escape(chat_name)}：{count} 条")

    lines.extend(
        [
            "",
            "💡 <b>建议观察</b>",
            "• 手动验证过多：可以考虑屏蔽对应机器人或单独处理 Mini App 红包",
            "• 某账号失败明显偏多：优先检查群发言资格、账号风控或网络延迟",
            "• 某币种金额过低：可以调高该币种阈值，减少无效点击",
        ]
    )
    return "\n".join(lines)


async def render_daily_report(event, *, edit: bool = False) -> None:
    buttons = [[Button.inline("⬅️ 返回管理中心", b"admin")]]
    text = build_daily_report_text()
    if edit:
        await event.edit(text, buttons=buttons, parse_mode="html")
    else:
        await event.respond(text, buttons=buttons, parse_mode="html")


async def send_daily_report_to_admin() -> None:
    text = build_daily_report_text()
    await bot.send_message(
        ADMIN_ID,
        text,
        parse_mode="html",
        link_preview=False,
    )


def _seconds_until_next_daily_report() -> float:
    now = datetime.now(REPORT_TZ)
    target = datetime.combine(now.date(), DAILY_REPORT_TIME, tzinfo=REPORT_TZ)
    if target <= now:
        target += timedelta(days=1)
    return max(1.0, (target - now).total_seconds())


async def daily_report_scheduler() -> None:
    while True:
        delay = _seconds_until_next_daily_report()
        logger.info(
            "每日统计任务已安排：%.0f 秒后推送管理员日报",
            delay,
        )
        await asyncio.sleep(delay)
        try:
            await send_daily_report_to_admin()
            logger.info("每日统计日报已推送给管理员")
        except Exception:
            logger.exception("每日统计日报推送失败")


def record_admin_summary(account_db_id: int, result: dict) -> None:
    chat_id = result.get("chat_id")
    message_id = result.get("message_id")
    if chat_id is None or message_id is None:
        return
    key = (int(chat_id), int(message_id))
    if key in _summarized_packets:
        return
    summary = _packet_summaries.get(key)
    if summary is None:
        summary = {
            "chat_name": result.get("chat_name") or "未知群组",
            "amount": result.get("amount") or "0",
            "currency": result.get("currency") or "",
            "url": result.get("message_url") or result.get("url"),
            "expected": sum(
                1 for worker in active_workers.values() if not worker.task.done()
            ),
            "results": {},
        }
        _packet_summaries[key] = summary
        asyncio.create_task(send_admin_summary_after_delay(key))
    summary["results"][account_db_id] = dict(result)


def build_admin_summary_page(
    key: tuple[int, int],
    summary: dict,
    page: int = 0,
) -> tuple[str, Optional[list]]:
    results = summary["results"]
    processed = len(results)
    attempted = sum(bool(result.get("clicked")) for result in results.values())
    succeeded = sum(
        bool(result.get("clicked") and result.get("success"))
        for result in results.values()
    )
    manual_required = sum(
        bool(result.get("manual_required"))
        for result in results.values()
    )
    failed = sum(
        bool(
            result.get("clicked")
            and not result.get("success")
            and not result.get("manual_required")
        )
        for result in results.values()
    )
    skipped = processed - attempted
    items = list(results.items())
    total_pages = max(1, (len(items) + SUMMARY_DETAIL_PAGE_SIZE - 1) // SUMMARY_DETAIL_PAGE_SIZE)
    page = max(0, min(page, total_pages - 1))
    start = page * SUMMARY_DETAIL_PAGE_SIZE
    end = start + SUMMARY_DETAIL_PAGE_SIZE

    lines = [
        "📊 <b>红包处理汇总</b>",
        "",
        f"🏘 群组：{escape(str(summary['chat_name']))}",
        f"💰 红包：{escape(str(summary['amount']))} "
        f"{escape(str(summary['currency']))}",
        f"👥 当前开启账号：<b>{summary['expected']}</b>",
        f"⚙️ 已处理账号：<b>{processed}</b>",
        f"🖱 尝试点击：<b>{attempted}</b>",
        f"✅ 成功：<b>{succeeded}</b>",
        f"⚠️ 手动验证：<b>{manual_required}</b>",
        f"❌ 失败：<b>{failed}</b>",
        f"⏭️ 规则跳过：<b>{skipped}</b>",
        "",
        f"📋 <b>账号明细</b>（第 {page + 1}/{total_pages} 页）",
    ]
    for account_db_id, result in items[start:end]:
        if result.get("manual_required"):
            icon = "⚠️"
            reason = "需要手动验证"
        elif result.get("clicked") and result.get("success"):
            icon = "✅"
            reason = str(result.get("reason") or "领取成功")
        elif result.get("clicked"):
            icon = "❌"
            reason = str(result.get("reason") or "未知失败")
        else:
            icon = "⏭️"
            reason = str(result.get("reason") or "规则跳过")
        processed_at = str(result.get("processed_at") or "")
        time_suffix = f" 🕒 {escape(processed_at)}" if processed_at else ""
        lines.append(
            f"{icon} {escape(account_summary_label(account_db_id))}："
            f"{escape(reason)}"
            f"{time_suffix}"
        )
    url = summary.get("url")
    if url and url != "未知":
        lines.extend(
            [
                "",
                f'🔎 <a href="{escape(str(url), quote=True)}">点击查看</a>',
            ]
        )

    success_bot_links = []
    seen_bot_links = set()
    for result in results.values():
        if not (result.get("clicked") and result.get("success")):
            continue
        bot_link = claim_bot_link_html(result)
        if bot_link and bot_link not in seen_bot_links:
            seen_bot_links.add(bot_link)
            success_bot_links.append(bot_link)
    if success_bot_links:
        lines.append("🤖 领取机器人：" + "、".join(success_bot_links))

    buttons = None
    if total_pages > 1:
        chat_id, message_id = key
        nav = []
        if page > 0:
            nav.append(
                Button.inline(
                    "⬅️ 上一页",
                    f"summary_page:{chat_id}:{message_id}:{page - 1}".encode(),
                )
            )
        if page + 1 < total_pages:
            nav.append(
                Button.inline(
                    "下一页 ➡️",
                    f"summary_page:{chat_id}:{message_id}:{page + 1}".encode(),
                )
            )
        buttons = [nav] if nav else None
    return "\n".join(lines), buttons


async def send_admin_summary_after_delay(key: tuple[int, int]) -> None:
    started = asyncio.get_running_loop().time()
    await asyncio.sleep(SUMMARY_MIN_WAIT_SECONDS)
    while True:
        summary = _packet_summaries.get(key)
        if not summary:
            return
        processed = len(summary.get("results") or {})
        expected = int(summary.get("expected") or 0)
        elapsed = asyncio.get_running_loop().time() - started
        if expected <= 0 or processed >= expected or elapsed >= SUMMARY_MAX_WAIT_SECONDS:
            break
        await asyncio.sleep(0.5)
    summary = _packet_summaries.pop(key, None)
    if not summary:
        return
    _summarized_packets.add(key)
    _summary_order.append(key)
    while len(_summary_order) > MAX_BROADCAST_HISTORY:
        expired = _summary_order.popleft()
        _summarized_packets.discard(expired)
        _sent_summaries.pop(expired, None)

    _sent_summaries[key] = summary
    text, buttons = build_admin_summary_page(key, summary, 0)
    try:
        await bot.send_message(
            ADMIN_ID,
            text,
            parse_mode="html",
            link_preview=False,
            buttons=buttons,
        )
    except Exception:
        logger.exception("发送管理员红包汇总失败")

def mark_packet_broadcasted(key: tuple[int, int]) -> bool:
    if key in _broadcasted_packets:
        return False
    _broadcasted_packets.add(key)
    _broadcast_order.append(key)
    while len(_broadcast_order) > MAX_BROADCAST_HISTORY:
        expired = _broadcast_order.popleft()
        _broadcasted_packets.discard(expired)
    return True


def trim_public_relay_caches() -> None:
    if len(_public_username_entity_cache) > PUBLIC_CACHE_MAX_SIZE:
        _public_username_entity_cache.clear()
    if len(_public_entity_cache) > PUBLIC_CACHE_MAX_SIZE:
        for key in list(_public_entity_cache)[: len(_public_entity_cache) - PUBLIC_CACHE_MAX_SIZE]:
            _public_entity_cache.pop(key, None)
    if len(_public_account_username_cooldown_until) > PUBLIC_CACHE_MAX_SIZE:
        now = asyncio.get_running_loop().time()
        for key, until in list(_public_account_username_cooldown_until.items()):
            if until <= now or len(_public_account_username_cooldown_until) > PUBLIC_CACHE_MAX_SIZE:
                _public_account_username_cooldown_until.pop(key, None)


async def broadcast_public_packet(
    source_account_id: int,
    source_event,
) -> None:
    if not PUBLIC_RELAY_ENABLED:
        return
    try:
        trim_public_relay_caches()
        chat = await source_event.get_chat()
        username = getattr(chat, "username", None)
        chat_id = getattr(chat, "id", None)
        message_id = getattr(source_event, "id", None)
        if not username or chat_id is None or message_id is None:
            return
        if not mark_packet_broadcasted((int(chat_id), int(message_id))):
            return
        normalized_username = str(username).lower()

        async def relay(account_db_id: int, worker: Worker, *, allow_new_resolve: bool) -> None:
            client = worker.client
            if not client or not client.is_connected():
                return
            try:
                loop_now = asyncio.get_running_loop().time()
                cooldown_until = _public_resolve_cooldown_until.get(account_db_id, 0)
                if cooldown_until > loop_now:
                    logger.debug(
                        "公开群联动跳过：account=%s public_chat=@%s cooldown_left=%.0fs",
                        account_db_id,
                        username,
                        cooldown_until - loop_now,
                    )
                    return
                account_username_cooldown_until = _public_account_username_cooldown_until.get(
                    (account_db_id, normalized_username),
                    0,
                )
                if account_username_cooldown_until > loop_now:
                    logger.debug(
                        "公开群联动跳过：account=%s public_chat=@%s account_chat_cooldown_left=%.0fs",
                        account_db_id,
                        username,
                        account_username_cooldown_until - loop_now,
                    )
                    return
                persistent_cooldown_left = public_relay_cooldown_left(
                    account_db_id,
                    normalized_username,
                )
                if persistent_cooldown_left > 0:
                    logger.debug(
                        "公开群联动持久冷却跳过：account=%s public_chat=@%s cooldown_left=%ss",
                        account_db_id,
                        username,
                        persistent_cooldown_left,
                    )
                    return
                cache_key = (account_db_id, normalized_username)
                entity = _public_entity_cache.get(cache_key)
                if entity is None:
                    entity = public_relay_cached_peer(
                        account_db_id,
                        normalized_username,
                    )
                if entity is None:
                    if not allow_new_resolve:
                        return
                    if not consume_public_relay_resolve_quota(account_db_id):
                        logger.debug(
                            "公开群联动解析额度已用完：account=%s public_chat=@%s",
                            account_db_id,
                            username,
                        )
                        return
                    entity = await client.get_entity(username)
                    _public_entity_cache[cache_key] = entity
                    save_public_relay_success(account_db_id, normalized_username, entity)
                message = await client.get_messages(entity, ids=message_id)
                if message and message.reply_markup:
                    _public_entity_cache[cache_key] = entity
                    await process_account_message(
                        worker.owner_id,
                        account_db_id,
                        message,
                    )
            except FloodWaitError as exc:
                wait_seconds = int(getattr(exc, "seconds", 0) or 0)
                if wait_seconds <= 0:
                    wait_seconds = 300
                _public_resolve_cooldown_until[account_db_id] = (
                    asyncio.get_running_loop().time() + wait_seconds
                )
                _public_account_username_cooldown_until[(account_db_id, normalized_username)] = (
                    asyncio.get_running_loop().time() + wait_seconds
                )
                save_public_relay_status(
                    account_db_id,
                    normalized_username,
                    status="flood",
                    ttl_seconds=wait_seconds + PUBLIC_RELAY_FLOOD_EXTRA_COOLDOWN_SECONDS,
                    error=str(exc),
                )
                logger.warning(
                    "公开群联动账号进入冷却：account=%s public_chat=@%s wait=%ss message=%s",
                    account_db_id,
                    username,
                    wait_seconds,
                    message_id,
                )
            except ChannelPrivateError as exc:
                _public_account_username_cooldown_until[(account_db_id, normalized_username)] = (
                    asyncio.get_running_loop().time() + PUBLIC_USERNAME_FAIL_COOLDOWN_SECONDS
                )
                save_public_relay_status(
                    account_db_id,
                    normalized_username,
                    status="private",
                    ttl_seconds=PUBLIC_USERNAME_FAIL_COOLDOWN_SECONDS,
                    error=str(exc),
                )
                logger.info(
                    "公开群联动账号无权限访问，进入账号群冷却：account=%s public_chat=@%s cooldown=%ss message=%s error=%s",
                    account_db_id,
                    username,
                    PUBLIC_USERNAME_FAIL_COOLDOWN_SECONDS,
                    message_id,
                    exc,
                )
            except Exception as exc:
                error_text = str(exc)
                if (
                    "Request was unsuccessful" in error_text
                    or "Could not find the input entity" in error_text
                    or "The channel specified is private" in error_text
                    or "lack permission" in error_text
                    or "Invalid channel object" in error_text
                ):
                    _public_account_username_cooldown_until[(account_db_id, normalized_username)] = (
                        asyncio.get_running_loop().time() + PUBLIC_USERNAME_FAIL_COOLDOWN_SECONDS
                    )
                    save_public_relay_status(
                        account_db_id,
                        normalized_username,
                        status="failed",
                        ttl_seconds=PUBLIC_USERNAME_FAIL_COOLDOWN_SECONDS,
                        error=error_text,
                    )
                    logger.info(
                        "公开群联动临时失败，进入账号群冷却：account=%s public_chat=@%s cooldown=%ss message=%s error=%s",
                        account_db_id,
                        username,
                        PUBLIC_USERNAME_FAIL_COOLDOWN_SECONDS,
                        message_id,
                        exc,
                    )
                    return
                logger.warning(
                    "全局联动失败：account=%s public_chat=@%s message=%s error=%s",
                    account_db_id,
                    username,
                    message_id,
                    exc,
                )

        cached_or_recent_targets: list[tuple[int, Worker]] = []
        new_resolve_targets: list[tuple[int, Worker]] = []
        for account_db_id, worker in list(active_workers.items()):
            if account_db_id == source_account_id or worker.task.done():
                continue
            if public_relay_cooldown_left(account_db_id, normalized_username) > 0:
                continue
            if (
                account_recently_seen_chat(account_db_id, int(chat_id))
                or public_relay_has_valid_success(account_db_id, normalized_username)
            ):
                cached_or_recent_targets.append((account_db_id, worker))
            elif len(new_resolve_targets) < PUBLIC_RELAY_NEW_RESOLVE_TARGETS_PER_PACKET:
                new_resolve_targets.append((account_db_id, worker))

        targets = [
            relay(account_db_id, worker, allow_new_resolve=True)
            for account_db_id, worker in cached_or_recent_targets
        ] + [
            relay(account_db_id, worker, allow_new_resolve=True)
            for account_db_id, worker in new_resolve_targets
        ]
        if targets:
            await asyncio.gather(*targets)
    except Exception:
        logger.exception("广播公开群红包失败")


async def start_worker(uid: int, account_db_id: int, session: str) -> None:
    worker = active_workers[account_db_id]
    client = TelegramClient(StringSession(session), API_ID, API_HASH, proxy=PROXY)
    worker.client = client
    try:
        await client.start()
        me = await client.get_me()
        save_account_profile(uid, session, me)
        worker.account_name = (
            f"@{me.username}" if getattr(me, "username", None)
            else f"{getattr(me, 'first_name', '')} ({me.id})"
        )

        async def _process_event(event):
            broadcast_task = None
            if should_prebroadcast_packet(event):
                broadcast_task = create_tracked_task(
                    broadcast_public_packet(account_db_id, event),
                    name="redpacket-prebroadcast",
                    context={
                        "account_db_id": account_db_id,
                        "chat_id": getattr(event, "chat_id", None),
                        "message_id": getattr(event, "id", None),
                    },
                )
                await asyncio.sleep(0)
            result = await process_account_message(uid, account_db_id, event)
            if result.get("currency") and broadcast_task is None:
                create_tracked_task(
                    broadcast_public_packet(account_db_id, event),
                    name="redpacket-broadcast",
                    context={
                        "account_db_id": account_db_id,
                        "chat_id": getattr(event, "chat_id", None),
                        "message_id": getattr(event, "id", None),
                    },
                )
            return result

        @client.on(events.NewMessage)
        @client.on(events.MessageEdited)
        async def handler(event):
            create_tracked_task(
                maybe_notify_join_verification(uid, account_db_id, event),
                name="join-verification-notify",
                context={
                    "account_db_id": account_db_id,
                    "chat_id": getattr(event, "chat_id", None),
                    "message_id": getattr(event, "id", None),
                },
            )
            if not event.reply_markup:
                return
            create_tracked_task(
                _process_event(event),
                name="account-redpacket-message",
                context={
                    "account_db_id": account_db_id,
                    "chat_id": getattr(event, "chat_id", None),
                    "message_id": getattr(event, "id", None),
                },
            )

        await client.run_until_disconnected()
    except asyncio.CancelledError:
        raise
    except Exception:
        logger.exception("用户 %s 的监听任务异常退出", uid)
        try:
            await bot.send_message(uid, "⚠️ 监听任务异常退出，请重新开启。")
        except Exception:
            pass
    finally:
        if client.is_connected():
            await client.disconnect()
        current = active_workers.get(account_db_id)
        if current and current.task is asyncio.current_task():
            active_workers.pop(account_db_id, None)


@bot.on(events.NewMessage(incoming=True, pattern=r"^/(start|panel)$"))
async def home_command(event):
    if not event.is_private:
        return
    log_activity(event.sender_id, "打开机器人", "/start")
    await render_home(event)


@bot.on(events.NewMessage(incoming=True, pattern=r"^/account$"))
async def account_command(event):
    if not event.is_private:
        return
    await remember_user(event)
    log_activity(event.sender_id, "查看账号列表", "/account")
    if not is_authorized(event.sender_id):
        await render_home(event)
        return
    await render_accounts(event)


@bot.on(events.NewMessage(incoming=True, pattern=r"^/login$"))
async def login_command(event):
    if not event.is_private:
        return
    await remember_user(event)
    log_activity(event.sender_id, "开始登录账号", "/login")
    if not is_authorized(event.sender_id):
        await render_home(event)
        return
    await begin_login(event)


@bot.on(events.NewMessage(incoming=True, pattern=r"^/run$"))
async def run_command(event):
    if not is_authorized(event.sender_id):
        await render_home(event)
        return
    rows = db.execute(
        "SELECT id FROM accounts WHERE owner_id=?", (event.sender_id,)
    ).fetchall()
    if not rows:
        await event.respond("⚠️ 暂无已登录账号。")
        return
    results = [
        await start_account_worker(event.sender_id, row["id"]) for row in rows
    ]
    ok = any(result[0] for result in results)
    message = "已尝试开启全部账号。"
    await event.respond(
        f"{'🚀' if ok else '⚠️'} {message}",
        buttons=[[Button.inline("🏠 返回主页", b"home")]],
    )


@bot.on(events.NewMessage(incoming=True, pattern=r"^/stop$"))
async def stop_command(event):
    if not is_authorized(event.sender_id):
        await render_home(event)
        return
    account_ids = [
        account_id
        for account_id, worker in active_workers.items()
        if worker.owner_id == event.sender_id
    ]
    results = [
        await stop_account_worker(event.sender_id, account_id)
        for account_id in account_ids
    ]
    ok = any(result[0] for result in results)
    message = "已停止全部账号。" if ok else "当前没有账号在抢红包。"
    await event.respond(
        f"{'🛑' if ok else 'ℹ️'} {message}",
        buttons=[[Button.inline("🏠 返回主页", b"home")]],
    )


@bot.on(events.NewMessage(incoming=True, pattern=r"^/status$"))
async def status_command(event):
    if not is_authorized(event.sender_id):
        await render_home(event)
        return
    await render_status(event)


@bot.on(events.NewMessage(incoming=True, pattern=r"^/history$"))
async def history_command(event):
    if not is_authorized(event.sender_id):
        await render_home(event)
        return
    await render_history(event)


@bot.on(events.NewMessage(incoming=True, pattern=r"^/admin$"))
async def admin_command(event):
    if event.sender_id != ADMIN_ID:
        await render_home(event)
        return
    await render_admin(event)


@bot.on(events.NewMessage(incoming=True, pattern=r"^/daily$"))
async def daily_command(event):
    if event.sender_id != ADMIN_ID:
        await render_home(event)
        return
    await render_daily_report(event)


@bot.on(events.NewMessage(incoming=True, pattern=r"^/emoji$"))
async def emoji_command(event):
    if event.sender_id != ADMIN_ID:
        await render_home(event)
        return
    await render_emoji_admin(event)


@bot.on(events.NewMessage(incoming=True, pattern=r"^/auth\s+(\d+)$"))
async def auth_command(event):
    if event.sender_id != ADMIN_ID:
        return
    target = int(event.pattern_match.group(1))
    db.execute(
        """
        INSERT INTO users (id, is_auth, updated_at) VALUES (?, 1, ?)
        ON CONFLICT(id) DO UPDATE SET is_auth=1, updated_at=excluded.updated_at
        """,
        (target, datetime.now().isoformat(timespec="seconds")),
    )
    db.commit()
    await event.respond(f"✅ 已授权用户 <code>{target}</code>", parse_mode="html")
    try:
        await bot.send_message(target, "🎉 你已获得授权，发送 /start 打开控制台。")
    except Exception:
        pass


@bot.on(events.NewMessage(incoming=True, pattern=r"^/unauth\s+(\d+)$"))
async def unauth_command(event):
    if event.sender_id != ADMIN_ID:
        return
    target = int(event.pattern_match.group(1))
    if target == ADMIN_ID:
        await event.respond("⚠️ 不能取消管理员自己的授权。")
        return
    for account_id, worker in list(active_workers.items()):
        if worker.owner_id == target:
            await stop_account_worker(target, account_id)
    db.execute("UPDATE users SET is_auth=0 WHERE id=?", (target,))
    db.commit()
    await event.respond(f"🔒 已取消用户 <code>{target}</code> 的授权", parse_mode="html")


@bot.on(events.NewMessage(incoming=True, pattern=r"^/cancel$"))
async def cancel_command(event):
    state = login_states.pop(event.sender_id, None)
    setting_states.pop(event.sender_id, None)
    if state:
        await _disconnect_login_client(state)
    await event.respond(
        "✅ 已取消当前操作。",
        buttons=[[Button.inline("🏠 返回主页", b"home")]],
    )


@bot.on(events.NewMessage(incoming=True))
async def handle_setting_input(event):
    if not event.is_private:
        return
    state = setting_states.get(event.sender_id)
    if not state:
        return
    text = (event.raw_text or "").strip()
    if not text or text.startswith("/"):
        return
    if state.get("kind") == "join_group":
        target = state["target"]
        try:
            _parse_group_link(text)
        except ValueError as exc:
            await event.respond(f"❌ {escape(str(exc))}", parse_mode="html")
            return
        setting_states.pop(event.sender_id, None)
        await event.respond(
            "📥 已收到群链接，开始排队加入。\n"
            "请保持机器人运行，完成后我会发送结果汇总。"
        )
        result_text = await run_join_group_queue(event.sender_id, target, text)
        await event.respond(
            result_text,
            parse_mode="html",
            buttons=[[Button.inline("🏠 返回主页", b"home")]],
        )
        return
    if state.get("kind") in {"allowed_chat_add", "allowed_chat_remove"}:
        account_db_id = int(state["account_id"])
        if not get_account(account_db_id, event.sender_id):
            setting_states.pop(event.sender_id, None)
            await event.respond("❌ 账号不存在。")
            return
        try:
            chat_id = parse_allowed_chat_id(text)
        except ValueError as exc:
            await event.respond(f"❌ {escape(str(exc))}", parse_mode="html")
            return
        setting_states.pop(event.sender_id, None)
        now = datetime.now().isoformat(timespec="seconds")
        if state["kind"] == "allowed_chat_add":
            db.execute(
                """
                INSERT OR REPLACE INTO account_allowed_chats
                    (account_id, chat_id, chat_name, updated_at)
                VALUES (?, ?, ?, ?)
                """,
                (account_db_id, chat_id, str(chat_id), now),
            )
            db.commit()
            log_activity(event.sender_id, "添加只抢指定群", f"account={account_db_id} chat={chat_id}")
            await event.respond(
                f"✅ 已添加允许群：<code>{chat_id}</code>\n后台立即生效。",
                parse_mode="html",
                buttons=[[Button.inline("⬅️ 返回只抢指定群", f"allowed_chats:{account_db_id}".encode())]],
            )
        else:
            db.execute(
                "DELETE FROM account_allowed_chats WHERE account_id=? AND chat_id=?",
                (account_db_id, chat_id),
            )
            db.commit()
            log_activity(event.sender_id, "删除只抢指定群", f"account={account_db_id} chat={chat_id}")
            await event.respond(
                f"✅ 已删除允许群：<code>{chat_id}</code>\n后台立即生效。",
                parse_mode="html",
                buttons=[[Button.inline("⬅️ 返回只抢指定群", f"allowed_chats:{account_db_id}".encode())]],
            )
        return
    target = state["target"]
    targets = rule_targets(event.sender_id, target)
    if not targets:
        setting_states.pop(event.sender_id, None)
        await event.respond("❌ 找不到需要配置的账号。")
        return
    if state.get("kind") == "click_delay":
        try:
            delay_min, delay_max = parse_click_delay_setting(text)
        except ValueError as exc:
            await event.respond(f"❌ {escape(str(exc))}", parse_mode="html")
            return
        delay_text = (
            f"{delay_min:g} 秒"
            if abs(delay_max - delay_min) < 0.001
            else f"随机 {delay_min:g}-{delay_max:g} 秒"
        )
        db.executemany(
            "UPDATE accounts SET click_delay=?, click_delay_max=?, updated_at=? WHERE id=?",
            [
                (
                    delay_min,
                    delay_max,
                    datetime.now().isoformat(timespec="seconds"),
                    account_db_id,
                )
                for account_db_id in targets
            ],
        )
        db.commit()
        setting_states.pop(event.sender_id, None)
        log_activity(
            event.sender_id,
            "修改点击延迟",
            f"账号 {target}：{delay_text}",
        )
        await event.respond(
            f"✅ 点击延迟已修改为 {delay_text}，后台立即生效。",
            buttons=[[
                Button.inline(
                    "⬅️ 返回账号详情",
                    f"detail:{target}".encode(),
                )
            ]],
        )
        return
    pairs = re.findall(
        r"([A-Za-z]+)\s*[:=]?\s*([0-9]+(?:\.[0-9]+)?)",
        text.replace(",", " "),
    )
    if not pairs:
        await event.respond(
            "❌ 格式不正确。\n"
            "请按“币种 金额”输入，例如：\n"
            "<code>CNY 1 USDT 0.5 JIBA 10000</code>",
            parse_mode="html",
        )
        return
    updates: dict[str, Decimal] = {}
    unsupported: list[str] = []
    for raw_currency, raw_value in pairs:
        currency = raw_currency.upper()
        if currency not in SUPPORTED_CURRENCIES:
            unsupported.append(currency)
            continue
        try:
            value = Decimal(raw_value)
        except InvalidOperation:
            await event.respond(f"❌ {currency} 的金额格式无效。")
            return
        updates[currency] = value
    if unsupported:
        await event.respond(
            "❌ 暂不支持这些币种：" + "、".join(sorted(set(unsupported)))
        )
        return
    for account_db_id in targets:
        for currency, value in updates.items():
            if value == 0:
                db.execute(
                    "DELETE FROM account_thresholds "
                    "WHERE account_id=? AND currency=?",
                    (account_db_id, currency),
                )
            else:
                db.execute(
                    """
                    INSERT INTO account_thresholds (account_id, currency, minimum)
                    VALUES (?, ?, ?)
                    ON CONFLICT(account_id, currency)
                    DO UPDATE SET minimum=excluded.minimum
                    """,
                    (account_db_id, currency, str(value)),
                )
    db.commit()
    setting_states.pop(event.sender_id, None)
    changed = "、".join(
        f"{currency}={'不限' if value == 0 else value}"
        for currency, value in updates.items()
    )
    log_activity(event.sender_id, "修改金额阈值", changed)
    await event.respond(
        "✅ 金额阈值修改成功\n"
        f"已更新：{changed}\n"
        "新规则已在后台立即生效。",
        buttons=[
            [
                Button.inline(
                    "⚙️ 返回规则设置",
                    f"rules:{target}".encode(),
                )
            ]
        ],
    )


@bot.on(events.NewMessage(incoming=True))
async def handle_login_input(event):
    if not event.is_private:
        return
    uid = event.sender_id
    state = login_states.get(uid)
    raw_text = event.raw_text
    if not state or not isinstance(raw_text, str):
        return
    text = raw_text.strip()
    if not text or text.startswith("/"):
        return
    if state.get("processing"):
        await event.respond("⏳ 正在处理上一条输入，请稍候。")
        return

    state["processing"] = True
    try:
        if state["step"] == "phone":
            phone = re.sub(r"[\s()-]", "", text)
            if not re.fullmatch(r"\+\d{7,15}", phone):
                await event.respond(
                    "❌ 手机号格式不正确，请输入类似 "
                    "<code>+8613812345678</code> 的格式。",
                    parse_mode="html",
                )
                return
            client = TelegramClient(
                StringSession(), API_ID, API_HASH, proxy=PROXY
            )
            await client.connect()
            request = await client.send_code_request(phone)
            login_states[uid] = {
                "step": "code",
                "client": client,
                "phone": phone,
                "phone_code_hash": request.phone_code_hash,
                "processing": False,
            }
            await event.respond(
                "📨 验证码已发送，请输入验证码。\n"
                "为了避免 Telegram 自动识别，可在数字之间加空格。"
            )
            return

        client = state["client"]
        if state["step"] == "code":
            code = re.sub(r"\s", "", text)
            if not code.isdigit():
                await event.respond("❌ 验证码应只包含数字，请重新输入。")
                return
            try:
                await client.sign_in(
                    state["phone"],
                    code,
                    phone_code_hash=state["phone_code_hash"],
                )
            except SessionPasswordNeededError:
                state["step"] = "2fa"
                await event.respond("🔑 请输入两步验证密码：")
                return
        elif state["step"] == "2fa":
            await client.sign_in(password=text)

        await _save_login(uid, state)
        await client.disconnect()
        login_states.pop(uid, None)
        log_activity(uid, "登录账号成功")
        await event.respond(
            "✅ 登录成功，会话已保存。",
            buttons=[[Button.inline("👤 查看我的账号", b"account")]],
        )
    except Exception as exc:
        logger.exception("用户 %s 登录失败", uid)
        await event.respond(f"❌ 登录失败：{escape(str(exc))}", parse_mode="html")
        failed_state = login_states.pop(uid, state)
        await _disconnect_login_client(failed_state)
    finally:
        current = login_states.get(uid)
        if current:
            current["processing"] = False


@bot.on(events.CallbackQuery)
async def callback(event):
    uid = event.sender_id
    data = event.data
    await remember_user(event)
    log_activity(uid, "点击按钮", data.decode(errors="replace"))
    if data == b"home":
        await render_home(event, edit=True)
    elif not is_authorized(uid):
        await event.answer("🔒 你还没有获得授权", alert=True)
        await render_home(event, edit=True)
        return
    elif data == b"login":
        await begin_login(event, edit=True)
    elif data == b"account":
        await render_accounts(event, edit=True)
    elif data == b"cancel_login":
        state = login_states.pop(uid, None)
        if state:
            await _disconnect_login_client(state)
        await render_accounts(event, edit=True)
    elif data.startswith(b"detail:"):
        account_db_id = int(data.split(b":", 1)[1])
        await render_account_detail(event, account_db_id)
    elif data.startswith(b"claim:"):
        account_db_id = int(data.split(b":", 1)[1])
        if is_running(account_db_id):
            _, message = await stop_account_worker(uid, account_db_id)
        else:
            _, message = await start_account_worker(uid, account_db_id)
        await event.answer(message, alert=True)
        await render_accounts(event, edit=True)
        return
    elif data.startswith(b"notify:"):
        account_db_id = int(data.split(b":", 1)[1])
        if not get_account(account_db_id, uid):
            await event.answer("账号不存在", alert=True)
            return
        enabled = not notifications_enabled(account_db_id)
        db.execute(
            "UPDATE accounts SET notify_enabled=?, updated_at=? WHERE id=?",
            (
                int(enabled),
                datetime.now().isoformat(timespec="seconds"),
                account_db_id,
            ),
        )
        db.commit()
        await event.answer(
            "红包通知已开启" if enabled else "红包通知已关闭",
            alert=True,
        )
        await render_accounts(event, edit=True)
        return
    elif data.startswith(b"rules:"):
        target = data.split(b":", 1)[1].decode()
        await render_rules(event, target)
    elif data.startswith(b"toggle_threshold:"):
        target = data.split(b":", 1)[1].decode()
        targets = rule_targets(uid, target)
        if not targets:
            await event.answer("没有可配置的账号", alert=True)
            return
        current = all(threshold_enabled(account_id) for account_id in targets)
        enabled = not current
        db.executemany(
            "UPDATE accounts SET threshold_enabled=?, updated_at=? WHERE id=?",
            [
                (
                    int(enabled),
                    datetime.now().isoformat(timespec="seconds"),
                    account_id,
                )
                for account_id in targets
            ],
        )
        db.commit()
        log_activity(
            uid,
            "修改金额阈值开关",
            f"target={target} enabled={int(enabled)}",
        )
        await event.answer(
            "金额阈值已开启" if enabled else "金额阈值已关闭",
            alert=True,
        )
        await render_rules(event, target)
        return
    elif data.startswith(b"delay:"):
        account_db_id = int(data.split(b":", 1)[1])
        if not get_account(account_db_id, uid):
            await event.answer("账号不存在", alert=True)
            return
        setting_states[uid] = {
            "kind": "click_delay",
            "target": str(account_db_id),
        }
        await event.edit(
            "⏱ <b>设置点击延迟</b>\n\n"
            "请输入 0–10 秒之间的固定秒数或随机范围，支持小数。\n"
            "固定延迟：<code>0</code>、<code>0.5</code>、<code>2</code>\n"
            "随机延迟：<code>0.5-2</code>、<code>1到3</code>\n\n"
            "设置后，每次点击红包前都会按这个规则等待。",
            buttons=[[
                Button.inline(
                    "⬅️ 返回账号详情",
                    f"detail:{account_db_id}".encode(),
                )
            ]],
            parse_mode="html",
        )
    elif data.startswith(b"blocked_bots:"):
        account_db_id = int(data.split(b":", 1)[1])
        await render_blocked_bots(event, account_db_id)
    elif data.startswith(b"allowed_chats:"):
        account_db_id = int(data.split(b":", 1)[1])
        await render_allowed_chats(event, account_db_id)
    elif data.startswith(b"add_allowed_chat:"):
        account_db_id = int(data.split(b":", 1)[1])
        if not get_account(account_db_id, uid):
            await event.answer("账号不存在", alert=True)
            return
        setting_states[uid] = {
            "kind": "allowed_chat_add",
            "account_id": account_db_id,
        }
        await event.edit(
            "➕ <b>添加只抢指定群</b>\n\n"
            "请发送群 ID，例如：<code>-1001234567890</code>。\n"
            "如果你发送 <code>1001234567890</code>，我会自动转成 <code>-1001234567890</code>。\n\n"
            "发送 /cancel 可以取消。",
            buttons=[[Button.inline("⬅️ 返回只抢指定群", f"allowed_chats:{account_db_id}".encode())]],
            parse_mode="html",
        )
        return
    elif data.startswith(b"remove_allowed_chat:"):
        account_db_id = int(data.split(b":", 1)[1])
        if not get_account(account_db_id, uid):
            await event.answer("账号不存在", alert=True)
            return
        setting_states[uid] = {
            "kind": "allowed_chat_remove",
            "account_id": account_db_id,
        }
        await event.edit(
            "➖ <b>删除只抢指定群</b>\n\n"
            "请发送要删除的群 ID，例如：<code>-1001234567890</code>。\n"
            "发送 /cancel 可以取消。",
            buttons=[[Button.inline("⬅️ 返回只抢指定群", f"allowed_chats:{account_db_id}".encode())]],
            parse_mode="html",
        )
        return
    elif data.startswith(b"clear_allowed_chats:"):
        account_db_id = int(data.split(b":", 1)[1])
        if not get_account(account_db_id, uid):
            await event.answer("账号不存在", alert=True)
            return
        db.execute("DELETE FROM account_allowed_chats WHERE account_id=?", (account_db_id,))
        db.commit()
        log_activity(uid, "清空只抢指定群", f"account={account_db_id}")
        await event.answer("已清空允许群列表", alert=True)
        await render_allowed_chats(event, account_db_id)
        return
    elif data.startswith(b"toggle_allowed_chats:"):
        account_db_id = int(data.split(b":", 1)[1])
        account = get_account(account_db_id, uid)
        if not account:
            await event.answer("账号不存在", alert=True)
            return
        enabled = not bool(account["allowed_chats_enabled"])
        db.execute(
            "UPDATE accounts SET allowed_chats_enabled=?, updated_at=? WHERE id=?",
            (
                int(enabled),
                datetime.now().isoformat(timespec="seconds"),
                account_db_id,
            ),
        )
        db.commit()
        await event.answer(
            "已开启：只抢指定群" if enabled else "已关闭：不限制群",
            alert=True,
        )
        await render_allowed_chats(event, account_db_id)
        return
    elif data.startswith(b"toggle_allowed_chat:"):
        _, raw_account_id, raw_chat_id = data.decode().split(":", 2)
        account_db_id = int(raw_account_id)
        chat_id = int(raw_chat_id)
        if not get_account(account_db_id, uid):
            await event.answer("账号不存在", alert=True)
            return
        existing = db.execute(
            "SELECT 1 FROM account_allowed_chats WHERE account_id=? AND chat_id=?",
            (account_db_id, chat_id),
        ).fetchone()
        if existing:
            db.execute(
                "DELETE FROM account_allowed_chats WHERE account_id=? AND chat_id=?",
                (account_db_id, chat_id),
            )
            message = "已从允许群移除"
        else:
            recent = db.execute(
                "SELECT chat_name FROM account_recent_chats WHERE account_id=? AND chat_id=?",
                (account_db_id, chat_id),
            ).fetchone()
            db.execute(
                """
                INSERT OR REPLACE INTO account_allowed_chats
                    (account_id, chat_id, chat_name, updated_at)
                VALUES (?, ?, ?, ?)
                """,
                (
                    account_db_id,
                    chat_id,
                    str(recent["chat_name"] if recent else chat_id),
                    datetime.now().isoformat(timespec="seconds"),
                ),
            )
            message = "已加入允许群"
        db.commit()
        await event.answer(message, alert=True)
        await render_allowed_chats(event, account_db_id)
        return
    elif data.startswith(b"join_group:"):
        target = data.decode().split(":", 1)[1]
        targets = join_group_targets(uid, target)
        if not targets:
            await event.answer("没有可操作的账号", alert=True)
            return
        if target == "admin_all":
            scope_text = f"管理员全部账号（{len(targets)} 个）"
        elif target == "mine":
            scope_text = f"我的全部账号（{len(targets)} 个）"
        elif target.startswith("account:"):
            scope_text = account_summary_label(int(target.split(":", 1)[1]))
        else:
            scope_text = f"{len(targets)} 个账号"
        setting_states[uid] = {
            "kind": "join_group",
            "target": target,
        }
        await event.edit(
            "📥 <b>加入群</b>\n\n"
            f"操作范围：<b>{escape(scope_text)}</b>\n\n"
            "请发送群用户名或邀请链接：\n"
            "<code>@groupname</code>\n"
            "<code>https://t.me/groupname</code>\n"
            "<code>https://t.me/+xxxx</code>\n\n"
            f"批量执行会排队加入，账号之间随机间隔 "
            f"{JOIN_GROUP_DELAY_MIN:g}–{JOIN_GROUP_DELAY_MAX:g} 秒。\n"
            "遇到等待限制会自动停止；入群验证只提醒，不自动处理。\n\n"
            "发送 /cancel 可取消。",
            buttons=[[Button.inline("⬅️ 返回账号列表", b"account")]],
            parse_mode="html",
        )
    elif data.startswith(b"toggle_bot:"):
        _, raw_account_id, raw_username = data.decode().split(":", 2)
        account_db_id = int(raw_account_id)
        username = raw_username.lower()
        if username not in BLOCKABLE_BOTS or not get_account(account_db_id, uid):
            await event.answer("设置无效", alert=True)
            return
        blocked = username in account_blocked_bots(account_db_id)
        if blocked:
            db.execute(
                "DELETE FROM account_blocked_bots "
                "WHERE account_id=? AND bot_username=?",
                (account_db_id, username),
            )
        else:
            db.execute(
                "INSERT OR IGNORE INTO account_blocked_bots "
                "(account_id, bot_username) VALUES (?, ?)",
                (account_db_id, username),
            )
        db.commit()
        log_activity(
            uid,
            "修改机器人屏蔽",
            f"账号 {account_db_id} @{username}：{'允许' if blocked else '屏蔽'}",
        )
        await event.answer(
            f"@{username} 已{'允许' if blocked else '屏蔽'}",
            alert=True,
        )
        await render_blocked_bots(event, account_db_id)
        return
    elif data.startswith(b"edit_rules:"):
        raw_target = data.split(b":", 1)[1].decode()
        if not rule_targets(uid, raw_target):
            await event.answer("没有可配置的账号", alert=True)
            return
        setting_states[uid] = {"target": raw_target}
        await event.edit(
            "💰 <b>批量修改金额阈值</b>\n\n"
            "请直接发送“币种 金额”，可一次设置多个：\n"
            "<code>CNY 1 USDT 0.5 KKCOIN 50000</code>\n\n"
            "输入 0 表示取消该币种限制，例如：\n"
            "<code>CNY 0 TON 0</code>\n\n"
            "支持：CNY、USDT、KKCOIN、JIBA、TON、TRX\n"
            "发送 /cancel 可取消。",
            buttons=[
                [
                    Button.inline(
                        "⬅️ 返回规则设置",
                        f"rules:{raw_target}".encode(),
                    )
                ]
            ],
            parse_mode="html",
        )
    elif data.startswith(b"sync_rules:"):
        raw_target = data.split(b":", 1)[1].decode()
        source_ids = rule_targets(uid, raw_target)
        if len(source_ids) != 1:
            await event.answer("找不到源账号", alert=True)
            return
        source_id = source_ids[0]
        destination_ids = [
            row["id"]
            for row in db.execute(
                "SELECT id FROM accounts WHERE owner_id=? AND id<>?",
                (uid, source_id),
            ).fetchall()
        ]
        if not destination_ids:
            await event.answer("没有其他账号可以同步", alert=True)
            return
        source_rules = db.execute(
            "SELECT currency, minimum FROM account_thresholds WHERE account_id=?",
            (source_id,),
        ).fetchall()
        source_enabled = int(threshold_enabled(source_id))
        for destination_id in destination_ids:
            db.execute(
                "DELETE FROM account_thresholds WHERE account_id=?",
                (destination_id,),
            )
            db.executemany(
                """
                INSERT INTO account_thresholds (account_id, currency, minimum)
                VALUES (?, ?, ?)
                """,
                [
                    (destination_id, row["currency"], row["minimum"])
                    for row in source_rules
                ],
            )
            db.execute(
                "UPDATE accounts SET threshold_enabled=?, updated_at=? WHERE id=?",
                (
                    source_enabled,
                    datetime.now().isoformat(timespec="seconds"),
                    destination_id,
                ),
            )
        db.commit()
        await event.answer(
            f"同步成功，已应用到 {len(destination_ids)} 个其他账号",
            alert=True,
        )
        await render_rules(event, raw_target)
        return
    elif data.startswith(b"count_rule:"):
        target = data.split(b":", 1)[1].decode()
        targets = rule_targets(uid, target)
        if not targets:
            await event.answer("没有可配置的账号", alert=True)
            return
        current = all(
            bool(get_account(account_id, uid)["skip_count_gt_amount"])
            for account_id in targets
        )
        enabled = not current
        db.executemany(
            "UPDATE accounts SET skip_count_gt_amount=? WHERE id=?",
            [(int(enabled), account_id) for account_id in targets],
        )
        db.commit()
        await event.answer(
            (
                "修改成功：红包个数大于金额时不抢"
                if enabled
                else "修改成功：已关闭红包个数限制"
            ),
            alert=True,
        )
        if target == "all":
            await render_rules(event, target)
        else:
            await render_account_detail(event, int(target))
        return
    elif data.startswith(b"sync_count_rule:"):
        source_id = int(data.split(b":", 1)[1])
        source = get_account(source_id, uid)
        if not source:
            await event.answer("找不到源账号", alert=True)
            return
        destination_ids = [
            row["id"]
            for row in db.execute(
                "SELECT id FROM accounts WHERE owner_id=? AND id<>?",
                (uid, source_id),
            ).fetchall()
        ]
        if not destination_ids:
            await event.answer("没有其他账号可以同步", alert=True)
            return
        db.executemany(
            "UPDATE accounts SET skip_count_gt_amount=? WHERE id=?",
            [
                (source["skip_count_gt_amount"], destination_id)
                for destination_id in destination_ids
            ],
        )
        db.commit()
        status = "开启" if source["skip_count_gt_amount"] else "关闭"
        await event.answer(
            f"同步成功，已为 {len(destination_ids)} 个其他账号{status}该规则",
            alert=True,
        )
        await render_account_detail(event, source_id)
        return
    elif data == b"emoji_admin":
        if uid != ADMIN_ID:
            await event.answer("无权限", alert=True)
            return
        await render_emoji_admin(event, edit=True)
        return
    elif data.startswith(b"emoji_record:"):
        if uid != ADMIN_ID:
            await event.answer("无权限", alert=True)
            return
        document_id = int(data.decode().split(":", 1)[1])
        await render_emoji_record(event, document_id)
        return
    elif data.startswith(b"emoji_label:"):
        if uid != ADMIN_ID:
            await event.answer("无权限", alert=True)
            return
        _, raw_document_id, label = data.decode().split(":", 2)
        try:
            normalized = label_emoji_document(int(raw_document_id), label)
        except Exception as exc:
            await event.answer(f"标记失败：{exc}", alert=True)
            return
        await event.answer(f"已标记为 {normalized}，下次自动生效", alert=True)
        await render_emoji_admin(event, edit=True)
        return
    elif data.startswith(b"summary_page:"):
        if uid != ADMIN_ID:
            await event.answer("无权限", alert=True)
            return
        try:
            _, raw_chat_id, raw_message_id, raw_page = data.decode().split(":", 3)
            key = (int(raw_chat_id), int(raw_message_id))
            page = int(raw_page)
        except Exception:
            await event.answer("分页参数无效", alert=True)
            return
        summary = _sent_summaries.get(key)
        if not summary:
            await event.answer("这条汇总已过期", alert=True)
            return
        text, buttons = build_admin_summary_page(key, summary, page)
        try:
            await event.edit(
                text,
                buttons=buttons,
                parse_mode="html",
                link_preview=False,
            )
        except MessageNotModifiedError:
            pass
        return
    elif data == b"status":
        await render_status(event, edit=True)
    elif data == b"history":
        await render_history(event, edit=True)
    elif data == b"admin" and uid == ADMIN_ID:
        await render_admin(event, edit=True)
    elif data == b"users" and uid == ADMIN_ID:
        await render_users(event)
    elif data == b"activity_logs" and uid == ADMIN_ID:
        rows = db.execute(
            """
            SELECT created_at, user_id, action, detail
            FROM activity_logs ORDER BY id DESC LIMIT 30
            """
        ).fetchall()
        lines = ["📋 <b>最近操作记录（30 条）</b>", ""]
        for row in rows:
            lines.append(
                f"🕒 {escape(row['created_at'])}\n"
                f"👤 <code>{row['user_id']}</code>｜{escape(row['action'])}\n"
                f"📝 {escape(row['detail'] or '-')}"
            )
        if not rows:
            lines.append("暂无操作记录。")
        await event.edit(
            "\n\n".join(lines),
            buttons=[[Button.inline("⬅️ 返回用户列表", b"users")]],
            parse_mode="html",
        )
    elif data == b"daily_report" and uid == ADMIN_ID:
        await render_daily_report(event, edit=True)
    await event.answer()


async def install_bot_commands() -> None:
    commands = [
        BotCommand("start", "🏠 开始"),
        BotCommand("account", "👤 查看我的账号"),
    ]
    await bot(
        SetBotCommandsRequest(
            scope=BotCommandScopeDefault(),
            lang_code="zh",
            commands=commands,
        )
    )
    await bot(
        SetBotCommandsRequest(
            scope=BotCommandScopeDefault(),
            lang_code="",
            commands=commands,
        )
    )


async def restore_enabled_accounts() -> None:
    rows = db.execute(
        "SELECT id, owner_id FROM accounts WHERE claim_enabled=1 ORDER BY id"
    ).fetchall()
    for row in rows:
        ok, message = await start_account_worker(row["owner_id"], row["id"])
        if ok:
            logger.info(
                "已自动恢复抢红包任务：owner=%s account=%s",
                row["owner_id"],
                row["id"],
            )
        else:
            logger.warning(
                "恢复抢红包任务失败：owner=%s account=%s reason=%s",
                row["owner_id"],
                row["id"],
                message,
            )


def run() -> None:
    if sys.platform == "win32":
        try:
            import ctypes

            ctypes.windll.kernel32.SetConsoleCP(65001)
            ctypes.windll.kernel32.SetConsoleOutputCP(65001)
        except Exception:
            pass
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure:
            reconfigure(encoding="utf-8", errors="replace")
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    logging.getLogger("telethon").setLevel(logging.WARNING)
    install_telethon_update_error_monitor()
    bot.start(bot_token=BOT_TOKEN)
    bot.loop.run_until_complete(install_bot_commands())
    bot.loop.run_until_complete(restore_enabled_accounts())
    bot.loop.create_task(daily_report_scheduler())
    logger.info("管理机器人已启动，命令菜单已安装")
    bot.run_until_disconnected()
