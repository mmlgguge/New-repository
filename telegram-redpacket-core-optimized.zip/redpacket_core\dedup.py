from collections import deque
from typing import Hashable


class MessageAttemptTracker:
    """限制每条红包消息只尝试一次，并控制内存占用。"""

    def __init__(self, max_entries: int = 5000) -> None:
        self.max_entries = max_entries
        self._attempted: set[Hashable] = set()
        self._order: deque[Hashable] = deque()

    def has_attempted(self, key: Hashable) -> bool:
        return key in self._attempted

    def mark_attempted(self, key: Hashable) -> None:
        if key in self._attempted:
            return
        self._attempted.add(key)
        self._order.append(key)
        while len(self._order) > self.max_entries:
            expired = self._order.popleft()
            self._attempted.discard(expired)

    def remove_attempt(self, key: Hashable) -> None:
        """【新增】如果点击因瞬时网络或频率故障失败，允许清除标记以便下次编辑时重试"""
        if key in self._attempted:
            self._attempted.discard(key)
            # 队列中的残留元素在滚动淘汰时会被安全 discard，无需主动清洗 deque（保障运行效率）