import unittest
import asyncio
from unittest import mock
import json
import os
import tempfile
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace

from redpacket_core.adapter import GenericRedPacketAdapter
from redpacket_core.clicker import (
    find_button_index,
    has_button_keyword,
    has_locked_button,
    normalize_button_text,
)
from redpacket_core.dedup import MessageAttemptTracker
from redpacket_core.models import RedPacket
from redpacket_core.rules import evaluate_threshold
from redpacket_core.sample_capture import capture_message_sample
from redpacket_core import listener
from redpacket_core import clicker


PARSER_CONFIG = {
    "currency_patterns": [
        r"(?i)(?:币种|currency)\s*[:：]?\s*([A-Z][A-Z0-9_-]{1,15})",
        r"(?i)([A-Z][A-Z0-9_-]{1,15})\s*(?:红包|red\s*packet)",
        r"(?i)(?:总金额|金额|amount|total)\s*[:：]?\s*[0-9][0-9,]*(?:\.[0-9]+)?\s*([A-Z][A-Z0-9_-]{1,15})",
    ],
    "amount_patterns": [
        r"(?i)(?:总金额|金额|amount|total)\s*[:：]?\s*([0-9][0-9,]*(?:\.[0-9]+)?)",
        r"(?i)([0-9][0-9,]*(?:\.[0-9]+)?)\s*([A-Z][A-Z0-9_-]{1,15})",
    ],
    "count_patterns": [r"(?i)(?:数量|份数|count)\s*[:：]?\s*(\d+)"],
}


class AdapterTests(unittest.TestCase):
    def setUp(self):
        self.adapter = GenericRedPacketAdapter(PARSER_CONFIG)

    def test_parse_chinese_packet(self):
        packet = self.adapter.parse("红包来了\n币种：USDT\n总金额：12.5\n数量：20")
        self.assertEqual(packet, RedPacket("USDT", Decimal("12.5"), 20))

    def test_parse_amount_currency_pair(self):
        packet = self.adapter.parse("JIBA 红包\n总金额 20,000\n数量 8")
        self.assertEqual(packet, RedPacket("JIBA", Decimal("20000"), 8))

    def test_non_packet_returns_none(self):
        self.assertIsNone(self.adapter.parse("这是一条普通消息"))

    def test_parse_real_cny_format(self):
        packet = self.adapter.parse(
            "🧧 迪巴拉 发送了一个红包\n💵 总金额: 1.0 CNY 💰剩余: 2/2"
        )
        self.assertEqual(packet, RedPacket("CNY", Decimal("1.0"), None))


class RuleTests(unittest.TestCase):
    def test_below_threshold_is_skipped(self):
        decision = evaluate_threshold(
            RedPacket("USDT", Decimal("0.5")),
            {"USDT": Decimal("1")},
        )
        self.assertFalse(decision.should_click)

    def test_equal_threshold_is_allowed(self):
        decision = evaluate_threshold(
            RedPacket("USDT", Decimal("1")),
            {"USDT": Decimal("1")},
        )
        self.assertTrue(decision.should_click)

    def test_unconfigured_currency_is_allowed(self):
        decision = evaluate_threshold(
            RedPacket("JIBA", Decimal("1")),
            {"USDT": Decimal("1")},
        )
        self.assertTrue(decision.should_click)


class SampleCaptureTests(unittest.TestCase):
    def test_capture_text_and_buttons(self):
        event = SimpleNamespace(
            id=123,
            raw_text="币种：USDT\n总金额：5",
            buttons=[[SimpleNamespace(text="领取红包")]],
        )
        chat = SimpleNamespace(id=-1001, username="test_group", title="测试群")
        sender = SimpleNamespace(id=99, username="packet_bot", title=None)

        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "samples.jsonl"
            capture_message_sample(str(path), event, chat, sender, recognized=True)
            record = json.loads(path.read_text(encoding="utf-8"))

        self.assertEqual(record["text"], event.raw_text)
        self.assertEqual(record["buttons"], [["领取红包"]])
        self.assertTrue(record["recognized_by_generic_parser"])


class ButtonTests(unittest.TestCase):
    def tearDown(self):
        clicker.clear_button_text_cache()

    def test_locked_button_is_not_claim_button(self):
        event = SimpleNamespace(
            buttons=[[SimpleNamespace(text="🔒 解锁红包")]]
        )
        self.assertTrue(has_locked_button(event, ("解锁红包", "Unlock")))
        self.assertIsNone(
            find_button_index(
                event,
                ("领取红包", "抢红包", "会员红包", "Claim", "Open"),
            )
        )

    def test_claim_button_can_be_found_after_unlock(self):
        event = SimpleNamespace(
            buttons=[[SimpleNamespace(text="🧧 领‍取‌红‍包")]]
        )
        self.assertFalse(has_locked_button(event, ("解锁红包", "Unlock")))
        self.assertEqual(
            find_button_index(
                event,
                ("领取红包", "抢红包", "会员红包", "Claim", "Open"),
            ),
            0,
        )

    def test_hidden_characters_are_removed(self):
        self.assertEqual(normalize_button_text("🧧 领‍取‌红‍包"), "领取红包")

    def test_unlock_advisory_is_locked_not_claimable(self):
        event = SimpleNamespace(
            buttons=[[SimpleNamespace(text="🧧解锁后领取，管理叫解锁是⚠️诈骗")]]
        )
        self.assertTrue(
            has_locked_button(event, ("解锁后领取", "管理叫解锁"))
        )
        self.assertIsNone(
            find_button_index(
                event,
                ("领取红包", "抢红包", "会员红包", "Claim", "Open"),
            )
        )

    def test_member_packet_is_claimable(self):
        event = SimpleNamespace(
            buttons=[[SimpleNamespace(text="🧧会员红包")]]
        )
        self.assertEqual(
            find_button_index(
                event,
                ("领取红包", "抢红包", "会员红包", "Claim", "Open"),
            ),
            0,
        )

    def test_visit_packet_message_is_detected_as_notice(self):
        event = SimpleNamespace(
            buttons=[[SimpleNamespace(text="访问红包消息")]]
        )
        self.assertTrue(
            has_button_keyword(event, ("访问红包消息", "前往红包消息"))
        )


    def test_button_text_is_normalized_once_per_event(self):
        button_text = "馃Ё 棰嗏€嶅彇鈥岀孩鈥嶅寘"
        keyword = clicker.normalize_button_text(button_text)
        event = SimpleNamespace(
            buttons=[[SimpleNamespace(text=button_text)]]
        )
        original = clicker.normalize_button_text
        with mock.patch("redpacket_core.clicker.normalize_button_text") as normalize:
            normalize.side_effect = original

            self.assertTrue(has_button_keyword(event, (keyword,)))
            self.assertEqual(find_button_index(event, (keyword,)), 0)

        self.assertEqual(normalize.call_count, 2)


class TaskTests(unittest.IsolatedAsyncioTestCase):
    async def test_create_tracked_task_returns_immediately_and_logs_result(self):
        from redpacket_core.tasks import create_tracked_task

        started = asyncio.Event()
        finish = asyncio.Event()
        results = []

        async def worker():
            started.set()
            await finish.wait()
            return {"reason": "ok"}

        task = create_tracked_task(worker(), name="unit-task", on_done=results.append)

        await asyncio.wait_for(started.wait(), timeout=1)
        self.assertFalse(task.done())
        self.assertEqual(results, [])

        finish.set()
        await asyncio.wait_for(task, timeout=1)
        self.assertEqual(results, [{"reason": "ok"}])


class DedupTests(unittest.TestCase):
    def test_same_message_is_only_marked_once(self):
        tracker = MessageAttemptTracker()
        key = (-100123, 17334)
        self.assertFalse(tracker.has_attempted(key))
        tracker.mark_attempted(key)
        self.assertTrue(tracker.has_attempted(key))
        tracker.mark_attempted(key)
        self.assertEqual(len(tracker._attempted), 1)

    def test_old_entries_are_evicted(self):
        tracker = MessageAttemptTracker(max_entries=2)
        tracker.mark_attempted((1, 1))
        tracker.mark_attempted((1, 2))
        tracker.mark_attempted((1, 3))
        self.assertFalse(tracker.has_attempted((1, 1)))
        self.assertTrue(tracker.has_attempted((1, 3)))


class FakeEvent:
    def __init__(
        self,
        text,
        button_text,
        message_id=1,
        click_errors=None,
        click_response=None,
    ):
        self.id = message_id
        self.chat_id = -100123
        self.raw_text = text
        self.buttons = [[SimpleNamespace(text=button_text)]]
        self.reply_markup = True
        self.message = SimpleNamespace(message_link=None)
        self.clicked = []
        self.click_errors = list(click_errors or [])
        self.click_response = click_response

    async def get_chat(self):
        return SimpleNamespace(id=self.chat_id, username="test_group", title="测试群")

    async def get_sender(self):
        return SimpleNamespace(id=99, username="packet_bot", title=None)

    async def click(self, index):
        self.clicked.append(index)
        if self.click_errors:
            raise self.click_errors.pop(0)
        return self.click_response


class ListenerTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.config_path = Path(self.directory.name) / "config.json"
        self.previous_config_path = os.environ.get("APP_CONFIG_PATH")
        os.environ["APP_CONFIG_PATH"] = str(self.config_path)
        listener._config_cache = None
        listener._attempts = MessageAttemptTracker()

    def tearDown(self):
        if self.previous_config_path is None:
            os.environ.pop("APP_CONFIG_PATH", None)
        else:
            os.environ["APP_CONFIG_PATH"] = self.previous_config_path
        listener._config_cache = None
        self.directory.cleanup()

    def write_config(self, **overrides):
        config = {
            "enabled": True,
            "dry_run": False,
            "capture_samples": False,
            "allowed_chats": [],
            "allowed_senders": [],
            "button_text_keywords": ["领取红包"],
            "locked_button_keywords": ["解锁红包", "等待解锁"],
            "currency_thresholds": {"CNY": "1"},
            "parser": PARSER_CONFIG,
        }
        config.update(overrides)
        self.config_path.write_text(
            json.dumps(config, ensure_ascii=False), encoding="utf-8"
        )

    async def test_claim_button_is_clicked(self):
        self.write_config()
        event = FakeEvent("总金额: 3.0 CNY", "🧧 领‍取‌红‍包")
        result = await listener.handle_message(event)
        self.assertTrue(result["success"])
        self.assertTrue(result["clicked"])
        self.assertEqual(event.clicked, [0])

    async def test_below_threshold_is_not_clicked(self):
        self.write_config(currency_thresholds={"CNY": "5"})
        event = FakeEvent("总金额: 3.0 CNY", "领取红包")
        result = await listener.handle_message(event)
        self.assertFalse(result["success"])
        self.assertEqual(event.clicked, [])

    async def test_locked_packet_is_not_clicked(self):
        self.write_config()
        event = FakeEvent("总金额: 3.0 CNY", "🔒 解锁红包")
        result = await listener.handle_message(event)
        self.assertFalse(result["success"])
        self.assertIn("尚未解锁", result["reason"])
        self.assertEqual(event.clicked, [])

    async def test_same_message_can_be_clicked_by_two_accounts(self):
        self.write_config()
        first = FakeEvent("总金额: 3.0 CNY", "领取红包", message_id=99)
        second = FakeEvent("总金额: 3.0 CNY", "领取红包", message_id=99)

        first_result = await listener.handle_message(first, attempt_scope=1)
        second_result = await listener.handle_message(second, attempt_scope=2)

        self.assertTrue(first_result["clicked"])
        self.assertTrue(second_result["clicked"])
        self.assertEqual(first.clicked, [0])
        self.assertEqual(second.clicked, [0])

    async def test_network_error_is_retried_once(self):
        self.write_config()
        event = FakeEvent(
            "总金额: 3.0 CNY",
            "领取红包",
            click_errors=[TimeoutError("temporary timeout")],
        )
        with mock.patch(
            "redpacket_core.listener.asyncio.sleep",
            new=mock.AsyncMock(),
        ), mock.patch(
            "redpacket_core.listener.random.uniform",
            return_value=0.5,
        ):
            result = await listener.handle_message(event, attempt_scope=1)

        self.assertTrue(result["clicked"])
        self.assertEqual(event.clicked, [0, 0])

    async def test_business_error_is_not_retried(self):
        self.write_config()
        event = FakeEvent(
            "总金额: 3.0 CNY",
            "领取红包",
            click_errors=[ValueError("business failure")],
        )
        result = await listener.handle_message(event, attempt_scope=1)

        self.assertFalse(result["success"])
        self.assertEqual(event.clicked, [0])

    async def test_callback_failure_is_reported_as_failure(self):
        self.write_config()
        event = FakeEvent(
            "总金额: 3.0 CNY",
            "领取红包",
            click_response=SimpleNamespace(
                message="❌ 今日发言次数不足，当前发言: 0"
            ),
        )
        result = await listener.handle_message(event, attempt_scope=1)

        self.assertFalse(result["success"])
        self.assertEqual(
            result["reason"],
            "❌ 今日发言次数不足，当前发言: 0",
        )

    async def test_callback_success_text_is_preserved(self):
        self.write_config()
        event = FakeEvent(
            "总金额: 3.0 CNY",
            "领取红包",
            click_response=SimpleNamespace(
                message="🎉 恭喜！抢到了 0.17 CNY"
            ),
        )
        result = await listener.handle_message(event, attempt_scope=1)

        self.assertTrue(result["success"])
        self.assertEqual(result["reason"], "🎉 恭喜！抢到了 0.17 CNY")

    async def test_account_threshold_override_is_applied(self):
        self.write_config(currency_thresholds={})
        event = FakeEvent("总金额: 3.0 CNY", "领取红包")
        result = await listener.handle_message(
            event,
            attempt_scope=1,
            thresholds_override={"CNY": Decimal("5")},
        )

        self.assertFalse(result["success"])
        self.assertEqual(event.clicked, [])

    async def test_count_greater_than_amount_rule_skips_packet(self):
        parser = {
            "currency_patterns": [r"币种：([A-Z]+)"],
            "amount_patterns": [r"总金额：([0-9.]+)"],
            "count_patterns": [r"数量：(\d+)"],
        }
        self.write_config(parser=parser, currency_thresholds={})
        event = FakeEvent(
            "币种：CNY\n总金额：3\n数量：5",
            "领取红包",
        )
        result = await listener.handle_message(
            event,
            attempt_scope=1,
            thresholds_override={},
            skip_count_gt_amount=True,
        )

        self.assertFalse(result["success"])
        self.assertIn("包数 5 大于总金额 3", result["reason"])
        self.assertEqual(event.clicked, [])


if __name__ == "__main__":
    unittest.main()
