import re
from decimal import Decimal, InvalidOperation
from typing import Optional

from .models import RedPacket


CURRENCY_ALIASES = {
    "KK": "KKCOIN",
    "KKB": "KKCOIN",
}


LABELED_AMOUNT_PATTERNS = (
    re.compile(
        r"(?i)(?:随机金额|总金额|金额|amount|total)\s*"
        r"(?:\([^)]*\))?\s*[:：]?\s*"
        r"([0-9][0-9,]*(?:\.[0-9]+)?)\s*([A-Za-z0-9_-]{1,15})"
    ),
)

COUNT_FALLBACK_PATTERNS = (
    re.compile(r"(?:剩余|还剩)\s*[:：]?\s*(\d+)\s*/\s*(\d+)", re.IGNORECASE),
    re.compile(r"(?:数量|份数|个数|count)\s*[:：]?\s*(\d+)", re.IGNORECASE),
)


def normalize_currency(currency: str) -> str:
    normalized = currency.strip().upper()
    return CURRENCY_ALIASES.get(normalized, normalized)


class GenericRedPacketAdapter:
    """用配置中的正则表达式识别红包；后续可替换为目标机器人的专用适配器。"""

    def __init__(self, parser_config: dict[str, list[str]]) -> None:
        self.currency_patterns = self._compile(parser_config.get("currency_patterns", []))
        self.amount_patterns = self._compile(parser_config.get("amount_patterns", []))
        self.count_patterns = self._compile(parser_config.get("count_patterns", []))

    @staticmethod
    def _compile(patterns: list[str]) -> list[re.Pattern[str]]:
        return [re.compile(pattern) for pattern in patterns]

    @staticmethod
    def _first_match(patterns: list[re.Pattern[str]], text: str) -> Optional[re.Match[str]]:
        for pattern in patterns:
            match = pattern.search(text)
            if match:
                return match
        return None

    def parse(self, text: str) -> Optional[RedPacket]:
        if not text:
            return None

        currency_match = self._first_match(self.currency_patterns, text)
        amount_match = self._first_match(self.amount_patterns, text)
        labeled_amount_match = self._first_match(LABELED_AMOUNT_PATTERNS, text)
        if currency_match and amount_match:
            currency = normalize_currency(currency_match.group(1))
            amount_text = amount_match.group(1).replace(",", "")

            # “10 USDT”型规则可同时从金额正则的第二组得到币种。
            if amount_match.lastindex and amount_match.lastindex >= 2:
                amount_currency = amount_match.group(2)
                if amount_currency:
                    currency = normalize_currency(amount_currency)
        elif labeled_amount_match:
            amount_text = labeled_amount_match.group(1).replace(",", "")
            currency = normalize_currency(labeled_amount_match.group(2))
        else:
            return None

        try:
            amount = Decimal(amount_text)
        except InvalidOperation:
            return None

        count_match = self._first_match(self.count_patterns, text)
        fallback_count_match = self._first_match(COUNT_FALLBACK_PATTERNS, text)
        count = int(count_match.group(1)) if count_match else None
        if fallback_count_match:
            count = int(fallback_count_match.group(fallback_count_match.lastindex or 1))
        return RedPacket(currency=currency, amount=amount, count=count)
