from decimal import Decimal

from .models import RedPacket, RuleDecision


def evaluate_threshold(
    packet: RedPacket,
    thresholds: dict[str, Decimal],
) -> RuleDecision:
    currency = packet.currency.upper()
    threshold = thresholds.get(currency)

    if threshold is None:
        return RuleDecision(
            should_click=True,
            reason=f"{currency} 未设置金额限制，允许点击",
        )

    if packet.amount < threshold:
        return RuleDecision(
            should_click=False,
            reason=f"{packet.amount} {currency} 低于阈值 {threshold} {currency}",
            threshold=threshold,
        )

    return RuleDecision(
        should_click=True,
        reason=f"{packet.amount} {currency} 达到阈值 {threshold} {currency}",
        threshold=threshold,
    )
