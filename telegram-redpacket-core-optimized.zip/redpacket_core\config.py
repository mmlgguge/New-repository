import json
import os
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class AppConfig:
    enabled: bool
    dry_run: bool
    capture_samples: bool
    capture_only_with_buttons: bool
    sample_path: str
    allowed_chats: set[str]
    allowed_senders: set[str]
    button_text_keywords: tuple[str, ...]
    locked_button_keywords: tuple[str, ...]
    currency_thresholds: dict[str, Decimal]
    parser: dict[str, list[str]]


def _normalize_identifiers(values: list[Any]) -> set[str]:
    return {str(value).strip().lower().lstrip("@") for value in values if str(value).strip()}


def load_config(path: str | Path) -> AppConfig:
    config_path = Path(path)
    raw = json.loads(config_path.read_text(encoding="utf-8"))

    thresholds: dict[str, Decimal] = {}
    for currency, amount in raw.get("currency_thresholds", {}).items():
        try:
            value = Decimal(str(amount).replace(",", ""))
        except InvalidOperation as exc:
            raise ValueError(f"币种 {currency} 的金额阈值无效：{amount}") from exc
        if value < 0:
            raise ValueError(f"币种 {currency} 的金额阈值不能小于 0")
        if value > 0:
            thresholds[str(currency).strip().upper()] = value

    button_keywords = raw.get("button_text_keywords") or [
        "领取红包",
        "抢红包",
        "会员红包",
        "Claim",
        "Open",
    ]

    return AppConfig(
        enabled=bool(raw.get("enabled", False)),
        dry_run=bool(raw.get("dry_run", True)),
        capture_samples=bool(raw.get("capture_samples", True)),
        capture_only_with_buttons=bool(raw.get("capture_only_with_buttons", True)),
        sample_path=str(raw.get("sample_path", "data/message_samples.jsonl")),
        allowed_chats=_normalize_identifiers(raw.get("allowed_chats", [])),
        allowed_senders=_normalize_identifiers(raw.get("allowed_senders", [])),
        button_text_keywords=tuple(button_keywords),
        locked_button_keywords=tuple(
            raw.get("locked_button_keywords", ["解锁红包", "等待解锁", "Unlock"])
        ),
        currency_thresholds=thresholds,
        parser=raw.get("parser", {}),
    )


def config_path_from_env() -> Path:
    return Path(os.getenv("APP_CONFIG_PATH", "config.json"))
