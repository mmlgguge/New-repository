import asyncio
import logging
import time
from collections.abc import Awaitable, Callable
from typing import Any

logger = logging.getLogger(__name__)

_background_tasks: set[asyncio.Task[Any]] = set()


def create_tracked_task(
    awaitable: Awaitable[Any],
    *,
    name: str,
    context: dict[str, Any] | None = None,
    on_done: Callable[[Any], None] | None = None,
) -> asyncio.Task[Any]:
    started = time.perf_counter()
    task = asyncio.create_task(awaitable, name=name)
    _background_tasks.add(task)

    def _finalize(done: asyncio.Task[Any]) -> None:
        _background_tasks.discard(done)
        elapsed_ms = (time.perf_counter() - started) * 1000
        task_context = context or {}
        try:
            result = done.result()
        except asyncio.CancelledError:
            logger.info(
                "background_task_cancelled name=%s elapsed_ms=%.3f context=%s",
                name,
                elapsed_ms,
                task_context,
            )
            return
        except Exception:
            logger.exception(
                "background_task_failed name=%s elapsed_ms=%.3f context=%s",
                name,
                elapsed_ms,
                task_context,
            )
            return
        if on_done:
            try:
                on_done(result)
            except Exception:
                logger.exception(
                    "background_task_callback_failed name=%s context=%s",
                    name,
                    task_context,
                )
        logger.debug(
            "background_task_done name=%s elapsed_ms=%.3f context=%s",
            name,
            elapsed_ms,
            task_context,
        )

    task.add_done_callback(_finalize)
    return task


def active_task_count() -> int:
    return len(_background_tasks)
